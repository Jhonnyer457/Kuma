# Entrega 004 — v0.2.2
Diagnostico. Sube este ZIP a deliveries/inbox/.
