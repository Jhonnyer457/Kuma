package ani.dantotsu.settings

import android.app.NotificationManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.TextInputLayout
import ani.dantotsu.settings.extensionprefs.NovelSourcePreferencesFragment
import ani.dantotsu.parsers.novel.ConfigurableNovelSource
import ani.dantotsu.util.customAlertDialog
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import ani.dantotsu.R
import ani.dantotsu.connections.crashlytics.CrashlyticsInterface
import ani.dantotsu.databinding.FragmentNovelExtensionsBinding
import ani.dantotsu.others.LanguageMapper
import ani.dantotsu.parsers.NovelSources
import ani.dantotsu.parsers.novel.NovelExtension
import com.bumptech.glide.Glide
import ani.dantotsu.parsers.novel.NovelExtensionManager
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.snackString
import ani.dantotsu.util.Logger
import eu.kanade.tachiyomi.data.notification.Notifications
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import rx.android.schedulers.AndroidSchedulers
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.util.Locale

class InstalledNovelExtensionsFragment : BaseInstalledExtensionsFragment(), SearchQueryHandler {
    private var _binding: FragmentNovelExtensionsBinding? = null
    private val binding get() = _binding!!
    private lateinit var extensionsRecyclerView: RecyclerView
    private val skipIcons: Boolean = PrefManager.getVal(PrefName.SkipExtensionIcons)
    private val novelExtensionManager: NovelExtensionManager = Injekt.get()
    private val extensionsAdapter = NovelExtensionsAdapter(
        { ext ->
            val name = ext.name
            val changeUIVisibility: (Boolean) -> Unit = { show ->
                val activity = activity as? ExtensionsActivity
                if (activity != null && !activity.isFinishing && !activity.isDestroyed) {
                    activity.findViewById<ViewPager2>(R.id.viewPager).isVisible = show
                    activity.findViewById<TabLayout>(R.id.tabLayout).isVisible = show
                    activity.findViewById<TextInputLayout>(R.id.searchView).isVisible = show
                    activity.findViewById<ImageView>(R.id.languageselect).isVisible = show
                    activity.findViewById<TextView>(R.id.extensions).text =
                        if (show) activity.getString(R.string.extensions) else name
                    activity.findViewById<FrameLayout>(R.id.fragmentExtensionsContainer).isGone = show
                }
            }

            when (ext) {
                is NovelExtension.Installed -> {
                    val configurable = ext.sources.filterIsInstance<ConfigurableNovelSource>()
                    val hasPrefMethod = ext.sources.any { src ->
                        src.javaClass.methods.any { it.name == "setupPreferenceScreen" }
                    }
                    if (configurable.isNotEmpty() || hasPrefMethod) {
                        changeUIVisibility(false)
                        val fragment = NovelSourcePreferencesFragment().getInstance(ext.pkgName) {
                            changeUIVisibility(true)
                        }
                        parentFragmentManager.beginTransaction()
                            .setCustomAnimations(R.anim.slide_up, R.anim.slide_down)
                            .replace(R.id.fragmentExtensionsContainer, fragment)
                            .addToBackStack(null)
                            .commit()
                    } else {
                        showExtensionInfoDialog(ext)
                    }
                }
                is NovelExtension.JsPlugin -> {
                    showExtensionInfoDialog(ext)
                }
                else -> {}
            }
        },
        { ext ->
            if (isAdded) {
                when (ext) {
                    is NovelExtension.Installed -> {
                        novelExtensionManager.uninstallExtension(ext.pkgName)
                        snackString("Extension uninstalled")
                    }
                    is NovelExtension.JsPlugin -> {
                        novelExtensionManager.uninstallLnReaderPlugin(ext.pkgName)
                        snackString("Extension uninstalled")
                    }
                    else -> {}
                }
            }
        },
        { ext ->
            if (isAdded) {
                val context = requireContext()
                val notificationManager =
                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                when (ext) {
                    is NovelExtension.Installed -> {
                        if (ext.hasUpdate) {
                            subscribeExtensionUpdate(requireContext(), novelExtensionManager.updateExtension(ext), R.drawable.ic_check)
                        } else {
                            snackString("No update available")
                        }
                    }
                    is NovelExtension.JsPlugin -> {
                        if (ext.hasUpdate) {
                            lifecycleScope.launch {
                                val success = novelExtensionManager.updateLnReaderPlugin(ext.pkgName)
                                if (success) {
                                    snackString("Extension updated")
                                } else {
                                    snackString("Update failed")
                                }
                            }
                        } else {
                            snackString("No update available")
                        }
                    }
                    else -> snackString("No update available")
                }
            }
        }, skipIcons
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNovelExtensionsBinding.inflate(inflater, container, false)

        extensionsRecyclerView = binding.allNovelExtensionsRecyclerView
        setupExtensionsRecyclerView(extensionsRecyclerView, extensionsAdapter) {
            extensionsAdapter.updatePref()
        }


        lifecycleScope.launch {
            novelExtensionManager.allInstalledExtensionsFlow.collect { extensions ->
                extensionsAdapter.updateData(sortToNovelSourcesList(extensions))
            }
        }
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            novelExtensionManager.findAvailableExtensions()
        }
        return binding.root
    }

    private fun sortToNovelSourcesList(inpt: List<NovelExtension>): List<NovelExtension> {
        val sourcesMap = inpt.associateBy { it.name }
        val orderedSources = NovelSources.pinnedNovelSources.mapNotNull { name ->
            sourcesMap[name]
        }
        return orderedSources + inpt.filter { !NovelSources.pinnedNovelSources.contains(it.name) }
    }

    private fun showExtensionInfoDialog(ext: NovelExtension) {
        requireContext().customAlertDialog().apply {
            setTitle(ext.name)
            val msg = buildString {
                append("Package: ${ext.pkgName}\n")
                append("Version: ${ext.versionName}\n")
                if (ext is NovelExtension.Installed) {
                    ext.repository?.let { append("Repository: $it\n") }
                    append("Sources: ${ext.sources.size}")
                }
            }
            setMessage(msg)
            setPosButton(R.string.ok)
            show()
        }
    }


    override fun onDestroyView() {
        super.onDestroyView();_binding = null
    }

    override fun updateContentBasedOnQuery(query: String?) {
        lifecycleScope.launch {
            val allInstalled = novelExtensionManager.allInstalledExtensionsFlow.first()
            extensionsAdapter.filter(
                query ?: "",
                sortToNovelSourcesList(allInstalled)
            )
        }
    }

    override fun notifyDataChanged() { // do nothing
    }

    private class NovelExtensionsAdapter(
        private val onSettingsClicked: (NovelExtension) -> Unit,
        private val onUninstallClicked: (NovelExtension) -> Unit,
        private val onUpdateClicked: (NovelExtension) -> Unit,
        val skipIcons: Boolean
    ) : ListAdapter<NovelExtension, NovelExtensionsAdapter.ViewHolder>(
        DIFF_CALLBACK_INSTALLED
    ) {

        fun updateData(newExtensions: List<NovelExtension>) {
            submitList(newExtensions)
        }

        fun updatePref() {
            val map = currentList.map { it.name }
            PrefManager.setVal(PrefName.NovelSourcesOrder, map)
            NovelSources.pinnedNovelSources = map
            NovelSources.performReorderNovelSources()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_extension, parent, false)
            Logger.log("onCreateViewHolder: $view")
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val extension = getItem(position)
            holder.extensionNameTextView.text = extension.name

            when (extension) {
                is NovelExtension.Installed -> {
                    val lang = LanguageMapper.getLanguageName(extension.lang)
                    val repo = extension.repoName ?: extension.repository?.let { ani.dantotsu.parsers.ExtensionRepoMetaHelper.getRepoBadgeName(it) } ?: ani.dantotsu.parsers.ExtensionRepoMetaHelper.getInstalledRepo(extension.pkgName)?.let { ani.dantotsu.parsers.ExtensionRepoMetaHelper.getRepoBadgeName(it) }
                    val repoBadge = if (!repo.isNullOrBlank()) "@$repo" else ""
                    holder.extensionVersionTextView.text = listOf(lang, extension.versionName, repoBadge).filter { it.isNotBlank() }.joinToString(" ")
                    if (!skipIcons) {
                        holder.extensionIconImageView.setImageDrawable(extension.icon)
                    }
                    holder.updateView.isVisible = extension.hasUpdate
                }
                is NovelExtension.JsPlugin -> {
                    val lang = LanguageMapper.getLanguageName(extension.plugin.lang)
                    val repo = ani.dantotsu.parsers.ExtensionRepoMetaHelper.getInstalledRepo(extension.pkgName)?.let { ani.dantotsu.parsers.ExtensionRepoMetaHelper.getRepoBadgeName(it) }
                    val repoBadge = if (!repo.isNullOrBlank()) "@$repo" else ""
                    holder.extensionVersionTextView.text = listOf(lang, extension.versionName, repoBadge).filter { it.isNotBlank() }.joinToString(" ")
                    if (!skipIcons) {
                        Glide.with(holder.itemView.context)
                            .load(extension.iconUrl)
                            .into(holder.extensionIconImageView)
                    }
                    holder.updateView.isVisible = extension.hasUpdate
                }
                else -> {}
            }

            holder.deleteView.setOnClickListener {
                onUninstallClicked(extension)
            }
            holder.updateView.setOnClickListener {
                onUpdateClicked(extension)
            }
            holder.settingsImageView.setOnClickListener {
                onSettingsClicked(extension)
            }
        }

        fun filter(query: String, currentList: List<NovelExtension>) {
            val filteredList = ArrayList<NovelExtension>()
            for (extension in currentList) {
                if (extension.name.lowercase(Locale.ROOT).contains(query.lowercase(Locale.ROOT))) {
                    filteredList.add(extension)
                }
            }
            if (filteredList != currentList)
                submitList(filteredList)
        }

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val extensionNameTextView: TextView = view.findViewById(R.id.extensionNameTextView)
            val extensionVersionTextView: TextView =
                view.findViewById(R.id.extensionVersionTextView)
            val settingsImageView: ImageView = view.findViewById(R.id.settingsImageView)
            val extensionIconImageView: ImageView = view.findViewById(R.id.extensionIconImageView)
            val deleteView: ImageView = view.findViewById(R.id.deleteTextView)
            val updateView: ImageView = view.findViewById(R.id.updateTextView)
        }

        companion object {
            val DIFF_CALLBACK_INSTALLED =
                object : DiffUtil.ItemCallback<NovelExtension>() {
                    override fun areItemsTheSame(
                        oldItem: NovelExtension,
                        newItem: NovelExtension
                    ): Boolean {
                        return oldItem.pkgName == newItem.pkgName
                    }

                    override fun areContentsTheSame(
                        oldItem: NovelExtension,
                        newItem: NovelExtension
                    ): Boolean {
                        return oldItem == newItem
                    }
                }
        }
    }
}