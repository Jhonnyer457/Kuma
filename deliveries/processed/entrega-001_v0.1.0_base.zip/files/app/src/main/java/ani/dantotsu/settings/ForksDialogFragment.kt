package ani.dantotsu.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import ani.dantotsu.BottomSheetDialogFragment
import ani.dantotsu.R
import ani.dantotsu.databinding.BottomSheetDevelopersBinding

class ForksDialogFragment : BottomSheetDialogFragment() {
    private var _binding: BottomSheetDevelopersBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetDevelopersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.devsProgressBar.isVisible = false
        binding.devsTitle.setText(R.string.forks)
        binding.devsRecyclerView.isVisible = true
        binding.devsRecyclerView.adapter = DevelopersAdapter(
            arrayOf(
                Developer(
                    "Awery",
                    "https://avatars.githubusercontent.com/u/92123190?v=4",
                    "MrBoomDeveloper",
                    "https://github.com/MrBoomDeveloper/Awery"
                ),
                Developer(
                    "Dartotsu",
                    "https://avatars.githubusercontent.com/u/99584765?s=48&v=4",
                    "aayush262",
                    "https://github.com/aayush2622/Dartotsu"
                )
            )
        )
        binding.devsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
    }

    override fun onDestroyView() {
        _binding?.devsRecyclerView?.adapter = null
        _binding = null
        super.onDestroyView()
    }
}
