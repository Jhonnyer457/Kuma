package ani.dantotsu.media.manga.mangareader

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.KeyEvent.ACTION_DOWN
import android.view.KeyEvent.KEYCODE_DPAD_DOWN
import android.view.KeyEvent.KEYCODE_DPAD_UP
import android.view.KeyEvent.KEYCODE_PAGE_DOWN
import android.view.KeyEvent.KEYCODE_PAGE_UP
import android.view.KeyEvent.KEYCODE_VOLUME_DOWN
import android.view.KeyEvent.KEYCODE_VOLUME_UP
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.AdapterView
import android.widget.CheckBox
import androidx.activity.addCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.math.MathUtils.clamp
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.slider.Slider
import ani.dantotsu.GesturesListener
import ani.dantotsu.NoPaddingArrayAdapter
import ani.dantotsu.R
import ani.dantotsu.connections.anilist.Anilist
import ani.dantotsu.connections.crashlytics.CrashlyticsInterface
import ani.dantotsu.connections.discord.Discord
import ani.dantotsu.connections.discord.RPCManager
import ani.dantotsu.connections.discord.RPC
import ani.dantotsu.connections.updateProgress
import ani.dantotsu.currContext
import ani.dantotsu.databinding.ActivityMangaReaderBinding
import ani.dantotsu.dp
import ani.dantotsu.hideSystemBarsExtendView
import ani.dantotsu.isOnline
import ani.dantotsu.logError
import ani.dantotsu.media.Media
import ani.dantotsu.media.MediaDetailsViewModel
import ani.dantotsu.media.MediaNameAdapter
import ani.dantotsu.media.MediaSingleton
import ani.dantotsu.media.manga.MangaCache
import ani.dantotsu.media.manga.MangaChapter
import ani.dantotsu.media.emptyMedia
import ani.dantotsu.notifications.subscription.SubscriptionHelper
import ani.dantotsu.others.ImageViewDialog
import ani.dantotsu.parsers.HMangaSources
import ani.dantotsu.parsers.MangaImage
import ani.dantotsu.parsers.MangaSources
import ani.dantotsu.px
import ani.dantotsu.setSafeOnClickListener
import ani.dantotsu.download.DownloadsManager
import ani.dantotsu.download.manga.MangaDownloaderService
import ani.dantotsu.download.manga.MangaServiceDataSingleton
import ani.dantotsu.media.MediaType
import ani.dantotsu.parsers.OfflineMangaParser
import ani.dantotsu.parsers.MangaParser
import ani.dantotsu.parsers.DynamicMangaParser
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import ani.dantotsu.settings.CurrentReaderSettings
import ani.dantotsu.settings.CurrentReaderSettings.Companion.applyWebtoon
import ani.dantotsu.settings.CurrentReaderSettings.Directions.BOTTOM_TO_TOP
import ani.dantotsu.settings.CurrentReaderSettings.Directions.LEFT_TO_RIGHT
import ani.dantotsu.settings.CurrentReaderSettings.Directions.RIGHT_TO_LEFT
import ani.dantotsu.settings.CurrentReaderSettings.Directions.TOP_TO_BOTTOM
import ani.dantotsu.settings.CurrentReaderSettings.DualPageModes.Automatic
import ani.dantotsu.settings.CurrentReaderSettings.DualPageModes.Force
import ani.dantotsu.settings.CurrentReaderSettings.DualPageModes.No
import ani.dantotsu.settings.CurrentReaderSettings.Layouts.CONTINUOUS_PAGED
import ani.dantotsu.settings.CurrentReaderSettings.Layouts.PAGED
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.showSystemBarsRetractView
import ani.dantotsu.snackString
import ani.dantotsu.themes.ThemeManager
import ani.dantotsu.tryWith
import ani.dantotsu.util.customAlertDialog
import com.alexvasilkov.gestures.views.GestureFrameLayout
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView
import eu.kanade.tachiyomi.extension.manga.MangaExtensionManager
import ani.dantotsu.media.manga.mangareader.BaseImageAdapter.Companion.loadBitmap
import ani.dantotsu.media.manga.mangareader.webgpu.WebGpuManager
import ani.dantotsu.media.manga.mangareader.webgpu.WebGpuReaderView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min
import kotlin.properties.Delegates

class MangaReaderActivity : AppCompatActivity() {
    private val mangaCache = Injekt.get<MangaCache>()
    private val pageSliderHandler = Handler(Looper.getMainLooper())
    private var pageSliderRunnable: Runnable? = null

    private lateinit var binding: ActivityMangaReaderBinding
    private val model: MediaDetailsViewModel by viewModels()
    private val scope = lifecycleScope

    var defaultSettings = CurrentReaderSettings()
    val autoScrollHelper = MangaReaderAutoScroll()

    private lateinit var media: Media
    lateinit var chapter: MangaChapter
    lateinit var chapters: MutableMap<String, MangaChapter>
    lateinit var chaptersArr: List<String>
    lateinit var chaptersTitleArr: ArrayList<String>
    var currentChapterIndex = 0

    var webGpuReaderView: WebGpuReaderView? = null
        private set

    private var isContVisible = false
    private var showProgressDialog = true

    private var maxChapterPage = 0L
    private var currentChapterPage = 0L

    private var notchHeight: Int? = null

    private var imageAdapter: BaseImageAdapter? = null

    var sliding = false
    var isAnimating = false

    private val directionRLBT
        get() = defaultSettings.direction == RIGHT_TO_LEFT
                || defaultSettings.direction == BOTTOM_TO_TOP
    private val directionPagedBT
        get() = defaultSettings.layout == CurrentReaderSettings.Layouts.PAGED
                && defaultSettings.direction == CurrentReaderSettings.Directions.BOTTOM_TO_TOP

    override fun onAttachedToWindow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && !PrefManager.getVal<Boolean>(PrefName.ShowSystemBars)) {
            val displayCutout = window.decorView.rootWindowInsets.displayCutout
            if (displayCutout != null) {
                if (displayCutout.boundingRects.size > 0) {
                    notchHeight = min(
                        displayCutout.boundingRects[0].width(),
                        displayCutout.boundingRects[0].height()
                    )
                    checkNotch()
                }
            }
        }
        super.onAttachedToWindow()
    }

    private fun checkNotch() {
        binding.mangaReaderTopLayout.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            topMargin = notchHeight ?: return@updateLayoutParams
        }
    }

    private fun hideSystemBars() {
        if (PrefManager.getVal(PrefName.ShowSystemBars))
            showSystemBarsRetractView()
        else
            hideSystemBarsExtendView()
    }

    override fun onPause() {
        super.onPause()
        if (autoScrollHelper.isRunning) {
            autoScrollHelper.stop()
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        if (defaultSettings.autoScroll && ::binding.isInitialized && defaultSettings.layout != PAGED) {
            autoScrollHelper.speed = defaultSettings.autoScrollSpeed
            autoScrollHelper.attach(binding.mangaReaderRecycler, defaultSettings.direction)
            autoScrollHelper.stop()
            binding.mangaReaderAutoScrollPlayBar.isVisible = true
            binding.autoScrollPlayPause.setImageResource(R.drawable.ic_round_play_arrow_24)
        }
    }

    override fun onDestroy() {
        webGpuReaderView?.destroy()
        webGpuReaderView = null
        autoScrollHelper.destroy()
        mangaCache.clear()
        goneHandler.removeCallbacksAndMessages(null)
        pageSliderHandler.removeCallbacksAndMessages(null)
        RPCManager.clearPresence(this)
        ani.dantotsu.widgets.continue_widget.ContinueWidget.updateReadingState(this, null, null, null, isExiting = true)
        if (::binding.isInitialized) {
            try {
                binding.mangaReaderSwipy.isEnabled = true
                for (i in 0 until binding.mangaReaderRecycler.childCount) {
                    val child = binding.mangaReaderRecycler.getChildAt(i)
                    val subsamplingView = child.findViewById<SubsamplingScaleImageView>(R.id.imgProgImageNoGestures)
                    subsamplingView?.recycle()
                    child.setTag(R.id.imgProgImageNoGestures, null)
                }
                binding.mangaReaderRecycler.adapter = null
                binding.mangaReaderRecycler.recycledViewPool.clear()
                binding.mangaReaderPager.adapter = null
            } catch (_: Exception) {}
        }
        imageAdapter = null
        try {
            Glide.get(this).clearMemory()
        } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeManager(this).applyTheme()
        binding = ActivityMangaReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.mangaReaderBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        defaultSettings = loadReaderSettings("reader_settings") ?: defaultSettings

        setupOnBackPressed()

        controllerDuration = (PrefManager.getVal<Float>(PrefName.AnimationSpeed) * 200).toLong()
        hideSystemBars()

        setupPageSlider()

        if (!initializeMediaAndSettings()) return
        if (!initializeChapters()) return

        setupChapterSelector()
        setupToolbarAndControls()
        observeMangaChapter()

        scope.launch(Dispatchers.IO) {
            model.loadMangaChapterImages(
                chapter,
                media.selected!!
            )
        }
    }

    private fun shouldAutoSaveChapterZero(chapterStr: String): Boolean =
        chapterStr == "0.0" &&
                PrefManager.getVal<Boolean>(PrefName.ChapterZeroReader) &&
                !showProgressDialog &&
                !PrefManager.getVal<Boolean>(PrefName.Incognito) &&
                PrefManager.getCustomVal("${media.id}_save_progress", true) &&
                (!media.isAdult || PrefManager.getVal<Boolean>(PrefName.UpdateForHReader))

    private fun setupOnBackPressed() {
        onBackPressedDispatcher.addCallback(this) {
            if (!::media.isInitialized || media.manga == null) {
                finish()
                return@addCallback
            }
            val selectedChapter = media.manga?.selectedChapter
            val chapterNum = selectedChapter?.number?.let { MediaNameAdapter.findChapterNumber(it) }
            val chapterStr = (chapterNum?.minus(1L) ?: 0).toString()

            if (shouldAutoSaveChapterZero(chapterStr)) {
                updateProgress(media, chapterStr)
                finish()
            } else {
                progress { finish() }
            }
        }
    }

    private fun pageSliderHide() {
        pageSliderRunnable?.let {
            pageSliderHandler.removeCallbacks(it)
            pageSliderHandler.postDelayed(it, 3000)
        }
    }

    private fun handleSliderPageChange(value: Int) {
        sliding = true
        if (webGpuReaderView != null && binding.mangaReaderWebGpuContainer.isVisible) {
            webGpuReaderView?.scrollToPage(value)
        } else if (defaultSettings.layout != PAGED) {
            val pos = imageAdapter?.findPositionForPage(chapter, value)
            if (pos != null && pos >= 0) {
                binding.mangaReaderRecycler.scrollToPosition(pos)
            } else {
                val divisor = dualPage { 2 } ?: 1
                binding.mangaReaderRecycler.scrollToPosition(
                    ((value - 1) / divisor).coerceAtLeast(0)
                )
            }
        } else {
            val divisor = dualPage { 2 } ?: 1
            if (defaultSettings.direction == CurrentReaderSettings.Directions.BOTTOM_TO_TOP) {
                binding.mangaReaderPager.currentItem =
                    (maxChapterPage.toInt() - value) / divisor
            } else {
                binding.mangaReaderPager.currentItem =
                    (value - 1) / divisor
            }
        }
        pageSliderHide()
    }

    private fun setupPageSlider() {
        val sliderRunnable = Runnable {
            sliding = false
            handleController(false)
        }
        this.pageSliderRunnable = sliderRunnable

        binding.mangaReaderSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                handleSliderPageChange(value.toInt())
            }
        }
    }

    private fun initializeMediaAndSettings(): Boolean {
        val currentMedia = model.getMedia().value
        media = if (currentMedia == null || currentMedia.manga == null) {
            try {
                MediaSingleton.media ?: return false
            } catch (e: Exception) {
                logError(e)
                return false
            } finally {
                MediaSingleton.media = null
            }
        } else currentMedia
        model.setMedia(media)

        @Suppress("UNCHECKED_CAST")
        val list = (PrefManager.getNullableCustomVal(
            "continueMangaList",
            listOf<Int>(),
            List::class.java
        ) as List<Int>).toMutableList()
        if (list.contains(media.id)) list.remove(media.id)
        list.add(media.id)
        PrefManager.setCustomVal("continueMangaList", list)

        if (PrefManager.getVal(PrefName.AutoDetectWebtoon) && media.countryOfOrigin != "JP") {
            applyWebtoon(defaultSettings)
        }
        defaultSettings = loadReaderSettings("${media.id}_current_settings") ?: defaultSettings
        return true
    }

    private fun initializeChapters(): Boolean {
        val mangaChapters = media.manga?.chapters ?: return false
        val selectedKey = media.manga?.selectedChapter?.uniqueNumber() ?: return false
        val initialChapter = mangaChapters[selectedKey] ?: return false

        chapters = mangaChapters
        chapter = initialChapter

        initMangaReadSources()

        binding.mangaReaderTitle.text = media.userPreferredName
        chaptersArr = chapters.keys.toList()
        currentChapterIndex = chaptersArr.indexOf(selectedKey)

        chaptersTitleArr = arrayListOf()
        chapters.forEach {
            val ch = it.value
            val hasTitle = !ch.title.isNullOrEmpty() && ch.title != "null"
            val prefix = if (hasTitle) "" else "Chapter "
            val suffix = if (hasTitle) " : " + ch.title else ""
            chaptersTitleArr.add("$prefix${ch.number}$suffix")
        }

        showProgressDialog = if (PrefManager.getVal(PrefName.AskIndividualReader)) {
            PrefManager.getCustomVal("${media.id}_progressDialog", true)
        } else false

        return true
    }

    private fun initMangaReadSources() {
        model.mangaReadSources = if (media.isAdult) HMangaSources else MangaSources
        binding.mangaReaderSource.isVisible = PrefManager.getVal(PrefName.ShowSource)
        if (model.mangaReadSources!!.names.isEmpty()) {
            try {
                val mangaSources = MangaSources
                val scope = lifecycleScope
                scope.launch(Dispatchers.IO) {
                    mangaSources.init(
                        Injekt.get<MangaExtensionManager>().installedExtensionsFlow
                    )
                }
                model.mangaReadSources = mangaSources
            } catch (e: Exception) {
                Injekt.get<CrashlyticsInterface>().logException(e)
                logError(e)
            }
        }
        if (media.selected!!.sourceIndex >= model.mangaReadSources!!.names.size) {
            media.selected!!.sourceIndex = 0
        }
        binding.mangaReaderSource.text =
            model.mangaReadSources!!.names[media.selected!!.sourceIndex]
    }

    private fun changeChapter(index: Int) {
        mangaCache.clear()
        PrefManager.setCustomVal(
            "${media.id}_${chaptersArr[currentChapterIndex]}",
            currentChapterPage
        )
        val targetChapter = chapters[chaptersArr[index]] ?: return
        ChapterLoaderDialog.newInstance(targetChapter).show(supportFragmentManager, "dialog")
    }

    private fun setupChapterSelector() {
        binding.mangaReaderChapterSelect.adapter =
            NoPaddingArrayAdapter(this, R.layout.item_dropdown, chaptersTitleArr)
        binding.mangaReaderChapterSelect.setSelection(currentChapterIndex)
        binding.mangaReaderChapterSelect.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    p0: AdapterView<*>?,
                    p1: View?,
                    position: Int,
                    p3: Long
                ) {
                    if (position != currentChapterIndex) {
                        onChapterSelectedFromDropdown(position)
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>) {}
            }
    }

    private fun onChapterSelectedFromDropdown(position: Int) {
        if (defaultSettings.layout != PAGED) {
            val selectedChap = chapters[chaptersArr.getOrNull(position)]
            val pos = selectedChap?.let { imageAdapter?.findPositionForPage(it, 1) }
            if (pos != null && pos >= 0) {
                binding.mangaReaderRecycler.scrollToPosition(pos)
                return
            }
        }
        val currentNum = MediaNameAdapter.findChapterNumber(chapter.number)
        val targetChap = chapters[chaptersArr.getOrNull(position)]
        val targetNum = targetChap?.number?.let { MediaNameAdapter.findChapterNumber(it) }
        val isForward = if (targetNum != null && currentNum != null && targetNum != currentNum) {
            targetNum > currentNum
        } else {
            position > currentChapterIndex
        }
        if (isForward) {
            progress(true) { changeChapter(position) }
        } else {
            changeChapter(position)
        }
    }

    private fun setupToolbarAndControls() {
        binding.mangaReaderSettings.setSafeOnClickListener {
            ReaderSettingsDialogFragment.newInstance().show(supportFragmentManager, "settings")
        }

        binding.mangaReaderTranslate.setSafeOnClickListener {
            handlePageTranslation()
        }

        binding.autoScrollPlayPause.setOnClickListener {
            val isRunning = autoScrollHelper.toggle()
            binding.autoScrollPlayPause.setImageResource(
                if (isRunning) R.drawable.ic_round_pause_24 else R.drawable.ic_round_play_arrow_24
            )
        }

        binding.autoScrollSpeedUp.setOnClickListener {
            val newSpeed = (autoScrollHelper.speed + 0.5f).coerceAtMost(10f)
            updateAutoScrollSpeed(newSpeed)
            snackString("${newSpeed}x")
        }

        binding.autoScrollSpeedDown.setOnClickListener {
            val newSpeed = (autoScrollHelper.speed - 0.5f).coerceAtLeast(0.5f)
            updateAutoScrollSpeed(newSpeed)
            snackString("${newSpeed}x")
        }

        binding.mangaReaderNextChap.setOnClickListener {
            binding.mangaReaderNextChapter.performClick()
        }
        binding.mangaReaderNextChapter.setOnClickListener {
            if (chaptersArr.size > currentChapterIndex + 1) {
                progress(true) {
                    changeChapter(currentChapterIndex + 1)
                }
            } else {
                snackString(getString(R.string.next_chapter_not_found))
            }
        }

        binding.mangaReaderPrevChap.setOnClickListener {
            binding.mangaReaderPreviousChapter.performClick()
        }
        binding.mangaReaderPreviousChapter.setOnClickListener {
            if (currentChapterIndex > 0) {
                changeChapter(currentChapterIndex - 1)
            } else {
                snackString(getString(R.string.first_chapter))
            }
        }
    }

    private fun handlePageTranslation() {
        if (!::chapter.isInitialized) return
        val chapImages = if (directionPagedBT) {
            chapter.images().reversed()
        } else {
            chapter.images()
        }
        val pageIndex = (currentChapterPage.toInt() - 1).coerceIn(0, (chapImages.size - 1).coerceAtLeast(0))
        val currentImage = chapImages.getOrNull(pageIndex)
        if (currentImage != null) {
            snackString(getString(R.string.translating_page))
            scope.launch(Dispatchers.IO) {
                val loadedBitmap = loadBitmap(currentImage.url, emptyList<BitmapTransformation>())
                if (loadedBitmap != null) {
                    val softwareBitmap = if (loadedBitmap.config == Bitmap.Config.HARDWARE) {
                        loadedBitmap.copy(Bitmap.Config.ARGB_8888, false)
                    } else {
                        loadedBitmap
                    }
                    withContext(Dispatchers.Main) {
                        ani.dantotsu.media.manga.mangareader.ocr.OcrTranslationBottomSheet.newInstance(softwareBitmap)
                            .show(supportFragmentManager, "ocr_translate")
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        snackString(getString(R.string.error_loading_data, "page image"))
                    }
                }
            }
        } else {
            snackString(getString(R.string.error_loading_data, "current page"))
        }
    }

    private fun observeMangaChapter() {
        model.getMangaChapter().observe(this) { chap ->
            if (chap != null) {
                chapter = chap
                media.manga!!.selectedChapter = chapter
                PrefManager.setCustomVal("${media.id}_current_chp", chap.number)
                val cleanChapNum = MediaNameAdapter.findChapterNumber(chap.number)?.let {
                    if (it % 1 == 0f) it.toInt().toString() else it.toString()
                }
                cleanChapNum?.let { PrefManager.setCustomVal("${media.id}_current_chp_num", it) }
                currentChapterIndex = chaptersArr.indexOf(chap.uniqueNumber())
                binding.mangaReaderChapterSelect.setSelection(currentChapterIndex)
                binding.mangaReaderNextChap.text =
                    chaptersTitleArr.getOrNull(currentChapterIndex + 1) ?: ""
                binding.mangaReaderPrevChap.text =
                    chaptersTitleArr.getOrNull(currentChapterIndex - 1) ?: ""
                applySettings()
                checkSmartDownloadManga(chap)
                updateDiscordPresence(chap)
            }
        }
    }

    private fun updateDiscordPresence(chap: MangaChapter) {
        val context = this
        val offline: Boolean = PrefManager.getVal(PrefName.OfflineMode)
        val incognito: Boolean = PrefManager.getVal(PrefName.Incognito)
        val rpcenabled: Boolean = PrefManager.getVal(PrefName.rpcEnabled)
        if (RPCManager.shouldSuppressForAdultMedia(media.isAdult)) {
            RPCManager.clearPresence(context)
        } else if (isOnline(context) && !offline && Discord.token != null && !incognito && rpcenabled) {
            lifecycleScope.launch {
                val buttons = mutableListOf<RPC.Link>()
                buttons.add(RPC.Link("View Manga", "https://anilist.co/manga/${media.id}/"))
                media.idMAL?.let {
                    buttons.add(RPC.Link("View on MyAnimeList", "https://myanimelist.net/manga/$it"))
                }
                val rpcData = RPC.Companion.RPCData(
                    applicationId = Discord.application_Id,
                    type = RPC.Type.WATCHING,
                    activityName = media.userPreferredName,
                    details = chap.title?.takeIf { it.isNotEmpty() }
                        ?: getString(R.string.chapter_num, chap.number),
                    state = "Chapter : ${chap.number}/${media.manga?.totalChapters ?: "??"}",
                    largeImage = media.cover?.let { cover ->
                        RPC.Link(
                            media.userPreferredName,
                            cover
                        )
                    },
                    buttons = buttons
                )
                RPCManager.setPresence(context, rpcData)
            }
        }
    }

    private val snapHelper = PagerSnapHelper()

    fun <T> dualPage(callback: () -> T): T? {
        return when (defaultSettings.dualPageMode) {
            No -> null
            Automatic -> {
                val orientation = resources.configuration.orientation
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) callback.invoke()
                else null
            }

            Force -> callback.invoke()
        }
    }

    private fun applyReaderWindowSettings() {
        hideSystemBars()

        //true colors
        SubsamplingScaleImageView.setPreferredBitmapConfig(
            if (defaultSettings.trueColors) Bitmap.Config.ARGB_8888
            else Bitmap.Config.RGB_565
        )

        //keep screen On
        if (defaultSettings.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        binding.mangaReaderPager.unregisterOnPageChangeCallback(pageChangeCallback)
    }

    private fun resolveOrderedChapterImages(): List<ani.dantotsu.parsers.MangaImage> {
        return if (directionPagedBT) chapter.images().reversed() else chapter.images()
    }

    private fun saveChapterMaxPage(totalCount: Long) {
        maxChapterPage = totalCount
        PrefManager.setCustomVal("${media.id}_${chapter.number}_max", maxChapterPage)
        val cleanChapNum = MediaNameAdapter.findChapterNumber(chapter.number)?.let {
            if (it % 1 == 0f) it.toInt().toString() else it.toString()
        }
        cleanChapNum?.let { PrefManager.setCustomVal("${media.id}_${it}_max", maxChapterPage) }
    }

    private fun setupImageAdapter() {
        val nextChapter = if (defaultSettings.layout != PAGED) {
            chaptersArr.getOrNull(currentChapterIndex + 1)?.let { chapters[it] }
        } else null

        val prevChapter = if (defaultSettings.layout != PAGED) {
            chaptersArr.getOrNull(currentChapterIndex - 1)?.let { chapters[it] }
        } else null

        imageAdapter =
            dualPage { DualPageAdapter(this, chapter, nextChapter, prevChapter) } ?: ImageAdapter(this, chapter, nextChapter, prevChapter)

        if (defaultSettings.layout != PAGED) {
            nextChapter?.let { preloadChapterAndAppend(it) }
            prevChapter?.let { preloadChapterAndPrepend(it) }
        }
    }

    private fun updatePageIndicators(totalCount: Long) {
        if (totalCount > 1) {
            binding.mangaReaderSlider.visibility = View.VISIBLE
            binding.mangaReaderSlider.updateRangeAndValue(
                to = maxChapterPage.toFloat(),
                currentVal = currentChapterPage.toFloat(),
                from = 1f
            )
        } else {
            binding.mangaReaderSlider.visibility = View.GONE
        }
        binding.mangaReaderPageNumber.text =
            if (defaultSettings.hidePageNumbers) "" else "${currentChapterPage}/$maxChapterPage"

        ani.dantotsu.widgets.continue_widget.ContinueWidget.updateReadingState(
            this,
            media.userPreferredName,
            media.cover,
            "Chapter ${chapter.number} (${currentChapterPage}/$maxChapterPage)",
            isExiting = false
        )
    }

    private fun setupChapterImagesAndAdapter(): List<ani.dantotsu.parsers.MangaImage>? {
        currentChapterPage = PrefManager.getCustomVal("${media.id}_${chapter.number}", 1L)
        val chapImages = resolveOrderedChapterImages()

        maxChapterPage = 0
        if (chapImages.isNotEmpty()) {
            saveChapterMaxPage(chapImages.size.toLong())
            setupImageAdapter()
            updatePageIndicators(chapImages.size.toLong())
        }
        return chapImages
    }

    private fun setupAutoScrollSettings() {
        if (defaultSettings.autoScroll && defaultSettings.layout != PAGED) {
            autoScrollHelper.speed = defaultSettings.autoScrollSpeed
            autoScrollHelper.attach(binding.mangaReaderRecycler, defaultSettings.direction)
            autoScrollHelper.stop()
            binding.mangaReaderAutoScrollPlayBar.isVisible = true
            binding.autoScrollPlayPause.setImageResource(R.drawable.ic_round_play_arrow_24)
        } else {
            autoScrollHelper.stop()
            binding.mangaReaderAutoScrollPlayBar.isVisible = false
        }
    }

    private fun setupVerticalSwipeNavigation() {
        binding.mangaReaderSwipy.vertical = true
        binding.mangaReaderNextChap.text =
            chaptersTitleArr.getOrNull(currentChapterIndex + 1) ?: ""
        binding.mangaReaderPrevChap.text =
            chaptersTitleArr.getOrNull(currentChapterIndex - 1) ?: ""

        val isTopToBottom = defaultSettings.direction == TOP_TO_BOTTOM
        val bottomIdx = if (isTopToBottom) currentChapterIndex + 1 else currentChapterIndex - 1
        val topIdx = if (isTopToBottom) currentChapterIndex - 1 else currentChapterIndex + 1

        binding.BottomSwipeText.text = chaptersTitleArr.getOrNull(bottomIdx) ?: getString(R.string.no_chapter)
        binding.TopSwipeText.text = chaptersTitleArr.getOrNull(topIdx) ?: getString(R.string.no_chapter)

        binding.mangaReaderSwipy.onTopSwiped = {
            if (isTopToBottom) binding.mangaReaderPreviousChapter.performClick()
            else binding.mangaReaderNextChapter.performClick()
        }
        binding.mangaReaderSwipy.onBottomSwiped = {
            if (isTopToBottom) binding.mangaReaderNextChapter.performClick()
            else binding.mangaReaderPreviousChapter.performClick()
        }
        binding.mangaReaderSwipy.topBeingSwiped = { value ->
            binding.TopSwipeContainer.apply {
                alpha = value
                translationY = -height.dp * (1 - min(value, 1f))
            }
        }
        binding.mangaReaderSwipy.bottomBeingSwiped = { value ->
            binding.BottomSwipeContainer.apply {
                alpha = value
                translationY = height.dp * (1 - min(value, 1f))
            }
        }
    }

    private fun setupHorizontalSwipeNavigation() {
        binding.mangaReaderSwipy.vertical = false
        binding.mangaReaderNextChap.text =
            chaptersTitleArr.getOrNull(currentChapterIndex + 1) ?: ""
        binding.mangaReaderPrevChap.text =
            chaptersTitleArr.getOrNull(currentChapterIndex - 1) ?: ""

        val isRightToLeft = defaultSettings.direction == RIGHT_TO_LEFT
        val leftIdx = if (isRightToLeft) currentChapterIndex + 1 else currentChapterIndex - 1
        val rightIdx = if (isRightToLeft) currentChapterIndex - 1 else currentChapterIndex + 1

        binding.LeftSwipeText.text = chaptersTitleArr.getOrNull(leftIdx) ?: getString(R.string.no_chapter)
        binding.RightSwipeText.text = chaptersTitleArr.getOrNull(rightIdx) ?: getString(R.string.no_chapter)

        binding.mangaReaderSwipy.onLeftSwiped = {
            if (isRightToLeft) binding.mangaReaderNextChapter.performClick()
            else binding.mangaReaderPreviousChapter.performClick()
        }
        binding.mangaReaderSwipy.onRightSwiped = {
            if (isRightToLeft) binding.mangaReaderPreviousChapter.performClick()
            else binding.mangaReaderNextChapter.performClick()
        }
        binding.mangaReaderSwipy.leftBeingSwiped = { value ->
            binding.LeftSwipeContainer.apply {
                alpha = value
                translationX = -width.dp * (1 - min(value, 1f))
            }
        }
        binding.mangaReaderSwipy.rightBeingSwiped = { value ->
            binding.RightSwipeContainer.apply {
                alpha = value
                translationX = width.dp * (1 - min(value, 1f))
            }
        }
    }

    private fun setupSwipeNavigation() {
        if (defaultSettings.direction == TOP_TO_BOTTOM || defaultSettings.direction == BOTTOM_TO_TOP) {
            setupVerticalSwipeNavigation()
        } else {
            setupHorizontalSwipeNavigation()
        }
    }

    private fun setupWebGpuRenderer(currentPage: Int) {
        binding.mangaReaderRecyclerContainer.visibility = View.GONE
        binding.mangaReaderPager.visibility = View.GONE
        binding.mangaReaderWebGpuContainer.visibility = View.VISIBLE
        binding.mangaReaderSwipy.isEnabled = false

        val isContinuous = defaultSettings.layout != PAGED
        val isVertical = defaultSettings.direction == TOP_TO_BOTTOM || defaultSettings.direction == BOTTOM_TO_TOP
        val isReversed = directionRLBT

        val currentGpu = webGpuReaderView
        if (currentGpu == null || currentGpu.isContinuous != isContinuous || currentGpu.isVertical != isVertical || currentGpu.isReversed != isReversed) {
            currentGpu?.destroy()
            binding.mangaReaderWebGpuContainer.removeAllViews()
            val newGpu = WebGpuReaderView(this, isContinuous = isContinuous, isVertical = isVertical, isReversed = isReversed)
            binding.mangaReaderWebGpuContainer.addView(
                newGpu.viewer,
                android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            webGpuReaderView = newGpu
        }
        binding.mangaReaderSwipy.child = webGpuReaderView?.viewer
        webGpuReaderView?.bind(chapter, currentPage)

        onVolumeUp = {
            webGpuReaderView?.scrollUp()
        }
        onVolumeDown = {
            webGpuReaderView?.scrollDown()
        }
        onVolumeUpLong = {
            if (webGpuReaderView?.currentPosition == 0) {
                if (isVertical) {
                    binding.mangaReaderSwipy.onTopSwiped.invoke()
                } else {
                    if (isReversed) binding.mangaReaderSwipy.onRightSwiped.invoke() else binding.mangaReaderSwipy.onLeftSwiped.invoke()
                }
                true
            } else false
        }
        onVolumeDownLong = {
            val lastIndex = (maxChapterPage - 1).toInt()
            if (webGpuReaderView?.currentPosition?.let { it >= lastIndex } == true) {
                if (isVertical) {
                    binding.mangaReaderSwipy.onBottomSwiped.invoke()
                } else {
                    if (isReversed) binding.mangaReaderSwipy.onLeftSwiped.invoke() else binding.mangaReaderSwipy.onRightSwiped.invoke()
                }
                true
            } else false
        }
    }

    private fun handleRecyclerLongClick(
        e: MotionEvent,
        chapImages: List<ani.dantotsu.parsers.MangaImage>?
    ): Boolean {
        val child = binding.mangaReaderRecycler.findChildViewUnder(e.x, e.y) ?: return false
        val frameLayout = child as? GestureFrameLayout ?: return false
        val pos = binding.mangaReaderRecycler.getChildAdapterPosition(child)
        val callback: (ImageViewDialog) -> Unit = { dialog ->
            lifecycleScope.launch {
                imageAdapter?.loadImage(pos, frameLayout)
            }
            binding.mangaReaderRecycler.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            dialog.dismiss()
        }
        return dualPage {
            val page = chapter.dualPages().getOrNull(pos) ?: return@dualPage false
            val nextPage = page.second
            if (defaultSettings.direction != LEFT_TO_RIGHT && nextPage != null)
                onImageLongClicked(pos * 2, nextPage, page.first, callback)
            else
                onImageLongClicked(pos * 2, page.first, nextPage, callback)
        } ?: onImageLongClicked(
            pos,
            chapImages?.getOrNull(pos) ?: return false,
            null,
            callback
        )
    }

    private fun createRecyclerGestureDetector(chapImages: List<ani.dantotsu.parsers.MangaImage>?): GestureDetectorCompat {
        return GestureDetectorCompat(this, object : GesturesListener() {
            override fun onLongPress(e: MotionEvent) {
                if (handleRecyclerLongClick(e, chapImages)) {
                    binding.mangaReaderRecycler.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                }
                super.onLongPress(e)
            }

            override fun onSingleClick(event: MotionEvent) {
                handleController()
            }
        })
    }

    private fun checkRecyclerEdgeScroll(v: RecyclerView) {
        val isVertical = defaultSettings.direction == TOP_TO_BOTTOM || defaultSettings.direction == BOTTOM_TO_TOP
        val atVerticalEdge = isVertical && (!v.canScrollVertically(-1) || !v.canScrollVertically(1))
        val atHorizontalEdge = !isVertical && (!v.canScrollHorizontally(-1) || !v.canScrollHorizontally(1))

        if (atVerticalEdge || atHorizontalEdge) {
            handleController(true)
        } else if (isContVisible) {
            handleController(false)
        }
    }

    private fun handleReaderItemScroll(item: ReaderItem?) {
        when (item) {
            is ReaderItem.Page -> {
                onChapterScrolledTo(item.chapter, item.pageNumber, item.totalPages)
                if (item.totalPages - item.pageNumber <= 5) {
                    chaptersArr.getOrNull(currentChapterIndex + 1)?.let { chapters[it] }?.let {
                        preloadChapterAndAppend(it)
                    }
                }
                if (item.pageNumber <= 5) {
                    chaptersArr.getOrNull(currentChapterIndex - 1)?.let { chapters[it] }?.let {
                        preloadChapterAndPrepend(it)
                    }
                }
            }
            is ReaderItem.DualPage -> {
                onChapterScrolledTo(item.chapter, item.pageNumber, item.totalPages)
                if (item.totalPages - item.pageNumber <= 3) {
                    chaptersArr.getOrNull(currentChapterIndex + 1)?.let { chapters[it] }?.let {
                        preloadChapterAndAppend(it)
                    }
                }
                if (item.pageNumber <= 3) {
                    chaptersArr.getOrNull(currentChapterIndex - 1)?.let { chapters[it] }?.let {
                        preloadChapterAndPrepend(it)
                    }
                }
            }
            is ReaderItem.Transition -> {
                item.toChapter?.let { toChap ->
                    if (!item.isPrevious) preloadChapterAndAppend(toChap)
                    else preloadChapterAndPrepend(toChap)
                }
            }
            null -> {}
        }
    }

    private fun resolveRecyclerVisiblePosition(manager: PreloadLinearLayoutManager): Int {
        return if (directionRLBT) {
            manager.findFirstVisibleItemPosition()
        } else {
            manager.findLastVisibleItemPosition()
        }.takeIf { it != RecyclerView.NO_POSITION } ?: manager.findFirstVisibleItemPosition()
    }

    private fun createRecyclerScrollListener(manager: PreloadLinearLayoutManager): RecyclerView.OnScrollListener {
        return object : RecyclerView.OnScrollListener() {
            override fun onScrolled(v: RecyclerView, dx: Int, dy: Int) {
                checkRecyclerEdgeScroll(v)
                val visiblePos = resolveRecyclerVisiblePosition(manager)
                if (visiblePos != RecyclerView.NO_POSITION) {
                    handleReaderItemScroll(imageAdapter?.getItem(visiblePos))
                }
                super.onScrolled(v, dx, dy)
            }
        }
    }

    private fun handleRecyclerVolumeUpLong(isVertical: Boolean): Boolean {
        return if (isVertical) {
            if (!binding.mangaReaderRecycler.canScrollVertically(-1)) {
                binding.mangaReaderSwipy.onTopSwiped.invoke()
                true
            } else false
        } else {
            if (!binding.mangaReaderRecycler.canScrollHorizontally(-1)) {
                binding.mangaReaderSwipy.onLeftSwiped.invoke()
                true
            } else false
        }
    }

    private fun handleRecyclerVolumeDownLong(isVertical: Boolean): Boolean {
        return if (isVertical) {
            if (!binding.mangaReaderRecycler.canScrollVertically(1)) {
                binding.mangaReaderSwipy.onBottomSwiped.invoke()
                true
            } else false
        } else {
            if (!binding.mangaReaderRecycler.canScrollHorizontally(1)) {
                binding.mangaReaderSwipy.onRightSwiped.invoke()
                true
            } else false
        }
    }

    private fun setupRecyclerVolumeKeys() {
        val isVertical = defaultSettings.direction == TOP_TO_BOTTOM || defaultSettings.direction == BOTTOM_TO_TOP
        onVolumeUp = {
            val dy = if (isVertical) -500 else 0
            val dx = if (isVertical) 0 else -500
            binding.mangaReaderRecycler.smoothScrollBy(dx, dy)
        }
        onVolumeUpLong = { handleRecyclerVolumeUpLong(isVertical) }
        onVolumeDown = {
            val dy = if (isVertical) 500 else 0
            val dx = if (isVertical) 0 else 500
            binding.mangaReaderRecycler.smoothScrollBy(dx, dy)
        }
        onVolumeDownLong = { handleRecyclerVolumeDownLong(isVertical) }
    }

    private fun resolveRecyclerInitialPosition(currentPage: Int): Int {
        return imageAdapter?.findPositionForPage(chapter, currentPage)?.takeIf { it >= 0 }
            ?: ((currentPage / (dualPage { 2 } ?: 1)) - 1).coerceAtLeast(0)
    }

    private fun setupRecyclerReader(chapImages: List<ani.dantotsu.parsers.MangaImage>?, currentPage: Int) {
        binding.mangaReaderRecyclerContainer.visibility = View.VISIBLE
        binding.mangaReaderRecyclerContainer.controller.settings.isRotationEnabled =
            defaultSettings.rotation

        val detector = createRecyclerGestureDetector(chapImages)
        val isVertical = defaultSettings.direction == TOP_TO_BOTTOM || defaultSettings.direction == BOTTOM_TO_TOP

        val manager = PreloadLinearLayoutManager(
            this,
            if (isVertical) RecyclerView.VERTICAL else RecyclerView.HORIZONTAL,
            directionRLBT
        )
        manager.preloadItemCount = 2

        binding.mangaReaderPager.visibility = View.GONE

        binding.mangaReaderRecycler.apply {
            clearOnScrollListeners()
            binding.mangaReaderSwipy.child = this
            adapter = imageAdapter
            layoutManager = manager
            setOnTouchListener { _, event ->
                if (event != null)
                    tryWith { detector.onTouchEvent(event) } ?: false
                else false
            }

            manager.setStackFromEnd(defaultSettings.direction == BOTTOM_TO_TOP)
            addOnScrollListener(createRecyclerScrollListener(manager))

            if (isVertical)
                updatePadding(0, 128f.px, 0, 128f.px)
            else
                updatePadding(128f.px, 0, 128f.px, 0)

            snapHelper.attachToRecyclerView(
                if (defaultSettings.layout == CONTINUOUS_PAGED) this
                else null
            )

            setupRecyclerVolumeKeys()
            scrollToPosition(resolveRecyclerInitialPosition(currentPage))
        }
    }

    private fun handlePagedVolumeUpLong(): Boolean {
        if (binding.mangaReaderPager.currentItem != 0) return false
        val isHorizontal = defaultSettings.direction == LEFT_TO_RIGHT || defaultSettings.direction == RIGHT_TO_LEFT
        if (isHorizontal) {
            if (binding.mangaReaderPager.layoutDirection == View.LAYOUT_DIRECTION_RTL) {
                binding.mangaReaderSwipy.onRightSwiped.invoke()
            } else {
                binding.mangaReaderSwipy.onLeftSwiped.invoke()
            }
        } else {
            binding.mangaReaderSwipy.onTopSwiped.invoke()
        }
        return true
    }

    private fun handlePagedVolumeDownLong(): Boolean {
        val lastPage = (maxChapterPage / (dualPage { 2 } ?: 1)).toInt() - 1
        if (binding.mangaReaderPager.currentItem < lastPage) return false
        val isHorizontal = defaultSettings.direction == LEFT_TO_RIGHT || defaultSettings.direction == RIGHT_TO_LEFT
        if (isHorizontal) {
            if (binding.mangaReaderPager.layoutDirection == View.LAYOUT_DIRECTION_RTL) {
                binding.mangaReaderSwipy.onLeftSwiped.invoke()
            } else {
                binding.mangaReaderSwipy.onRightSwiped.invoke()
            }
        } else {
            binding.mangaReaderSwipy.onBottomSwiped.invoke()
        }
        return true
    }

    private fun setupPagedVolumeKeys() {
        onVolumeUp = {
            binding.mangaReaderPager.currentItem -= 1
        }
        onVolumeUpLong = {
            handlePagedVolumeUpLong()
        }
        onVolumeDown = {
            binding.mangaReaderPager.currentItem += 1
        }
        onVolumeDownLong = {
            handlePagedVolumeDownLong()
        }
    }

    private fun setupPagedReader(currentPage: Int) {
        binding.mangaReaderRecyclerContainer.visibility = View.GONE
        binding.mangaReaderPager.apply {
            binding.mangaReaderSwipy.child = this
            visibility = View.VISIBLE
            adapter = imageAdapter
            layoutDirection =
                if (directionRLBT) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            orientation =
                if (defaultSettings.direction == LEFT_TO_RIGHT || defaultSettings.direction == RIGHT_TO_LEFT)
                    ViewPager2.ORIENTATION_HORIZONTAL
                else ViewPager2.ORIENTATION_VERTICAL
            registerOnPageChangeCallback(pageChangeCallback)
            offscreenPageLimit = 2

            val pageDiv = dualPage { 2 } ?: 1
            setCurrentItem(currentPage / pageDiv - 1, false)
        }
        setupPagedVolumeKeys()
    }

    @SuppressLint("ClickableViewAccessibility")
    fun applySettings() {
        saveReaderSettings("${media.id}_current_settings", defaultSettings)
        applyReaderWindowSettings()

        val chapImages = setupChapterImagesAndAdapter()
        setupAutoScrollSettings()
        setupSwipeNavigation()

        val currentPage = if (directionPagedBT) {
            maxChapterPage - currentChapterPage + 1
        } else {
            currentChapterPage
        }.toInt()

        if (defaultSettings.webGpuRenderer && WebGpuManager.isSupported(this)) {
            setupWebGpuRenderer(currentPage)
        } else {
            binding.mangaReaderSwipy.isEnabled = true
            if (webGpuReaderView != null) {
                webGpuReaderView?.destroy()
                webGpuReaderView = null
                binding.mangaReaderWebGpuContainer.removeAllViews()
            }
            binding.mangaReaderWebGpuContainer.visibility = View.GONE

            if (defaultSettings.layout != PAGED) {
                setupRecyclerReader(chapImages, currentPage)
            } else {
                setupPagedReader(currentPage)
            }
        }
    }

    private var onVolumeUp: (() -> Unit)? = null
    private var onVolumeDown: (() -> Unit)? = null
    private var onVolumeUpLong: (() -> Boolean)? = null
    private var onVolumeDownLong: (() -> Boolean)? = null
    private var volumeLongPressHandled = false
    
    private fun handleVolumeKeyEvent(
        event: KeyEvent,
        onShortPress: (() -> Unit)?,
        onLongPress: (() -> Boolean)?
    ): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) {
                volumeLongPressHandled = false
                onShortPress?.invoke()
            } else if (event.repeatCount >= 8 && !volumeLongPressHandled) {
                if (onLongPress?.invoke() == true) {
                    volumeLongPressHandled = true
                } else {
                    onShortPress?.invoke()
                }
            } else if (!volumeLongPressHandled) {
                onShortPress?.invoke()
            }
            return true
        } else if (event.action == KeyEvent.ACTION_UP) {
            return true
        }
        return false
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        return when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                if (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP && !defaultSettings.volumeButtons)
                    return false
                handleVolumeKeyEvent(event, onVolumeUp, onVolumeUpLong)
            }
            KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && !defaultSettings.volumeButtons)
                    return false
                handleVolumeKeyEvent(event, onVolumeDown, onVolumeDownLong)
            }
            else -> {
                super.dispatchKeyEvent(event)
            }
        }
    }

    private val pageChangeCallback = object : ViewPager2.OnPageChangeCallback() {
        override fun onPageSelected(position: Int) {
            updatePageNumber(position.toLong() * (dualPage { 2 } ?: 1) + 1)
            handleController(position == 0 || position + 1 >= maxChapterPage)
            super.onPageSelected(position)
        }
    }

    private val overshoot = OvershootInterpolator(1.4f)
    private var controllerDuration by Delegates.notNull<Long>()
    private val goneHandler = Handler(Looper.getMainLooper())
    private val goneRunnable = Runnable {
        if (!isContVisible && ::binding.isInitialized) {
            binding.mangaReaderCont.visibility = View.GONE
            isAnimating = false
        }
    }
    fun gone() {
        goneHandler.removeCallbacks(goneRunnable)
        goneHandler.postDelayed(goneRunnable, controllerDuration)
    }

    enum class PressPos {
        LEFT, RIGHT, CENTER
    }

    private fun determinePressPosition(x: Int, y: Int, screenWidth: Int): PressPos {
        val isRtl = defaultSettings.direction == RIGHT_TO_LEFT
        return if (screenWidth / 5 in x + 1..<y) {
            if (isRtl) PressPos.RIGHT else PressPos.LEFT
        } else if (x > screenWidth - screenWidth / 5 && y > screenWidth / 5) {
            if (isRtl) PressPos.LEFT else PressPos.RIGHT
        } else {
            PressPos.CENTER
        }
    }

    private fun navigatePaged(pressLocation: PressPos): Boolean {
        if (pressLocation == PressPos.LEFT && binding.mangaReaderPager.currentItem > 0) {
            if (imageAdapter?.isZoomed() == true) {
                imageAdapter?.setZoom(1f)
            }
            binding.mangaReaderPager.currentItem -= 1
            return true
        } else if (pressLocation == PressPos.RIGHT && binding.mangaReaderPager.currentItem < maxChapterPage - 1) {
            if (imageAdapter?.isZoomed() == true) {
                imageAdapter?.setZoom(1f)
            }
            binding.mangaReaderPager.currentItem += 1
            return true
        }
        return false
    }

    private fun handlePagedNavigation(event: MotionEvent?): Boolean {
        if (event == null || defaultSettings.layout != PAGED) return false
        if (event.action != MotionEvent.ACTION_UP) return true

        val x = event.rawX.toInt()
        val y = event.rawY.toInt()
        val screenWidth = Resources.getSystem().displayMetrics.widthPixels
        val pressLocation = determinePressPosition(x, y, screenWidth)
        return navigatePaged(pressLocation)
    }

    private fun updateScrollBar() {
        if (defaultSettings.hideScrollBar) {
            binding.mangaReaderSliderContainer.visibility = View.GONE
            return
        }

        if (defaultSettings.horizontalScrollBar) {
            binding.mangaReaderSliderContainer.updateLayoutParams {
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                width = ViewGroup.LayoutParams.WRAP_CONTENT
            }
            binding.mangaReaderSlider.apply {
                updateLayoutParams<ViewGroup.MarginLayoutParams> {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                }
                rotation = 0f
            }
        } else {
            binding.mangaReaderSliderContainer.updateLayoutParams {
                height = ViewGroup.LayoutParams.MATCH_PARENT
                width = 48f.px
            }
            binding.mangaReaderSlider.apply {
                updateLayoutParams {
                    width = binding.mangaReaderSliderContainer.height - 16f.px
                }
                rotation = 90f
            }
        }
        binding.mangaReaderSliderContainer.visibility = View.VISIBLE
        binding.mangaReaderSlider.layoutDirection =
            if (directionRLBT) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    private fun animateControllerVisibility(shouldShow: Boolean?) {
        shouldShow?.apply { isContVisible = !this }
        if (isContVisible) {
            isContVisible = false
            if (!isAnimating) {
                isAnimating = true
                ObjectAnimator.ofFloat(binding.mangaReaderCont, "alpha", 1f, 0f)
                    .setDuration(controllerDuration).start()
                ObjectAnimator.ofFloat(
                    binding.mangaReaderBottomLayout,
                    "translationY",
                    0f,
                    128f
                ).apply {
                    interpolator = overshoot
                    duration = controllerDuration
                    start()
                }
                ObjectAnimator.ofFloat(binding.mangaReaderTopLayout, "translationY", 0f, -128f)
                    .apply {
                        interpolator = overshoot
                        duration = controllerDuration
                        start()
                    }
            }
            gone()
        } else {
            isContVisible = true
            binding.mangaReaderCont.visibility = View.VISIBLE
            ObjectAnimator.ofFloat(binding.mangaReaderCont, "alpha", 0f, 1f)
                .setDuration(controllerDuration).start()
            ObjectAnimator.ofFloat(binding.mangaReaderTopLayout, "translationY", -128f, 0f)
                .apply {
                    interpolator = overshoot
                    duration = controllerDuration
                    start()
                }
            ObjectAnimator.ofFloat(binding.mangaReaderBottomLayout, "translationY", 128f, 0f)
                .apply {
                    interpolator = overshoot
                    duration = controllerDuration
                    start()
                }
        }
    }

    fun handleController(shouldShow: Boolean? = null, event: MotionEvent? = null) {
        if (!sliding) {
            if (handlePagedNavigation(event)) return

            if (!PrefManager.getVal<Boolean>(PrefName.ShowSystemBars)) {
                hideSystemBars()
                checkNotch()
            }
            updateScrollBar()
            animateControllerVisibility(shouldShow)
        }
    }

    private val loading = AtomicBoolean(false)
    private val pagePersistLock = Any()
    private var pagePersistSeq = 0L
    fun updatePageNumber(pageNumber: Long) {
        var page = pageNumber
        if (directionPagedBT) {
            page = maxChapterPage - pageNumber + 1
        }
        if (maxChapterPage > 0) {
            page = clamp(page, 1L, maxChapterPage)
        }
        if (currentChapterPage != page) {
            currentChapterPage = page
            triggerEInkFlash()
            val chapNum = chapter.number
            val seq = synchronized(pagePersistLock) { ++pagePersistSeq }
            scope.launch(Dispatchers.IO) {
                // Drop stale writes so rapid page turns persist in order (last-writer-wins)
                if (seq != synchronized(pagePersistLock) { pagePersistSeq }) return@launch
                PrefManager.setCustomVal("${media.id}_$chapNum", page)
                val cleanChapNum = MediaNameAdapter.findChapterNumber(chapNum)?.let {
                    if (it % 1 == 0f) it.toInt().toString() else it.toString()
                }
                cleanChapNum?.let { PrefManager.setCustomVal("${media.id}_$it", page) }
            }
            binding.mangaReaderPageNumber.text =
                if (defaultSettings.hidePageNumbers) "" else "${currentChapterPage}/$maxChapterPage"
            if (!sliding) {
                binding.mangaReaderSlider.updateRangeAndValue(
                    to = maxChapterPage.toFloat(),
                    currentVal = currentChapterPage.toFloat(),
                    from = 1f
                )
            }
        }
        if (maxChapterPage - currentChapterPage <= 1 && loading.compareAndSet(false, true))
            scope.launch(Dispatchers.IO) {
                try {
                    model.loadMangaChapterImages(
                        chapters[chaptersArr.getOrNull(currentChapterIndex + 1) ?: return@launch]!!,
                        media.selected!!,
                        false
                    )
                } finally {
                    loading.set(false)
                }
            }
    }

    private fun progress(runnable: Runnable) {
        progress(false, runnable)
    }

    private fun resolveSelectedChapterNumber(): String {
        val selectedChap = media.manga?.selectedChapter?.number
            ?: if (::chapter.isInitialized) chapter.number else null
        return selectedChap?.let { MediaNameAdapter.findChapterNumber(it)?.toString() }
            ?: selectedChap ?: ""
    }

    private fun showProgressUpdateDialog(runnable: Runnable) {
        val dialogView = layoutInflater.inflate(R.layout.item_custom_dialog, null)
        val checkbox = dialogView.findViewById<CheckBox>(R.id.dialog_checkbox)
        checkbox.text = getString(R.string.dont_ask_again, media.userPreferredName)
        checkbox.setOnCheckedChangeListener { _, isChecked ->
            PrefManager.setCustomVal("${media.id}_progressDialog", !isChecked)
            showProgressDialog = !isChecked
        }
        customAlertDialog().apply {
            setTitle(R.string.title_update_progress)
            setCustomView(dialogView)
            setCancelable(false)
            setPosButton(R.string.yes) {
                PrefManager.setCustomVal("${media.id}_save_progress", true)
                val chapNumStr = resolveSelectedChapterNumber()
                if (chapNumStr.isNotEmpty()) {
                    updateProgress(media, chapNumStr)
                }
                runnable.run()
            }
            setNegButton(R.string.no) {
                PrefManager.setCustomVal("${media.id}_save_progress", false)
                runnable.run()
            }
            setOnCancelListener { hideSystemBars() }
            show()
        }
    }

    private fun updateProgressSilently(incognito: Boolean, runnable: Runnable) {
        if (!incognito && PrefManager.getCustomVal("${media.id}_save_progress", true) &&
            (!media.isAdult || PrefManager.getVal<Boolean>(PrefName.UpdateForHReader))
        ) {
            val chapNumStr = resolveSelectedChapterNumber()
            if (chapNumStr.isNotEmpty()) {
                updateProgress(media, chapNumStr)
            }
        }
        runnable.run()
    }

    private fun progress(forceComplete: Boolean, runnable: Runnable) {
        val chapterCompleted = forceComplete || (maxChapterPage > 0 && maxChapterPage - currentChapterPage <= 1)
        if (chapterCompleted) {
            maybeHandleSubscriptionAfterChapterCompletion()
        }
        if (chapterCompleted && Anilist.userid != null) {
            showProgressDialog = if (PrefManager.getVal(PrefName.AskIndividualReader)) {
                PrefManager.getCustomVal("${media.id}_progressDialog", true)
            } else false
            val incognito: Boolean = PrefManager.getVal(PrefName.Incognito)
            if (showProgressDialog && !incognito) {
                showProgressUpdateDialog(runnable)
            } else {
                updateProgressSilently(incognito, runnable)
            }
        } else {
            runnable.run()
        }
    }

    private var lastSubscriptionPromptChapter: String? = null

    private fun maybeHandleSubscriptionAfterChapterCompletion() {
        if (isFinishing || isDestroyed) return
        val chapterKey = chapter.uniqueNumber()
        if (lastSubscriptionPromptChapter == chapterKey) return
        lastSubscriptionPromptChapter = chapterKey

        if (!PrefManager.getVal<Boolean>(PrefName.SubscriptionPromptAtEnd)) return

        val isCompleted = isCompletedForSubscriptionPrompt()
        val alreadySubscribed = SubscriptionHelper.getSubscriptions().containsKey(media.id)
        if (isCompleted) {
            if (alreadySubscribed) {
                SubscriptionHelper.saveSubscription(media, false)
                snackString(getString(R.string.unsubscribed_notification))
            }
            return
        }
        if (alreadySubscribed) return
        if (PrefManager.getCustomVal("${media.id}_subscription_declined", false)) return
        val caughtUp = chaptersArr.getOrNull(currentChapterIndex + 1) == null
        if (!caughtUp) return

        customAlertDialog().apply {
            setTitle(getString(R.string.subscribe_prompt_title))
            setMessage(getString(R.string.subscribe_prompt_manga_message, media.userPreferredName))
            setPosButton(R.string.yes) {
                SubscriptionHelper.saveSubscription(media, true)
                snackString(getString(R.string.subscribed_notification, getString(R.string.manga)))
            }
            setNegButton(R.string.no) {
                PrefManager.setCustomVal("${media.id}_subscription_declined", true)
            }
            show()
        }
    }

    private fun isMangaCompleted(): Boolean {
        if (media.userStatus == "COMPLETED") return true
        val totalChapters = media.manga?.totalChapters ?: return false
        val chapterNumber = MediaNameAdapter.findChapterNumber(chapter.number) ?: return false
        return chapterNumber >= totalChapters
    }

    private fun isCompletedForSubscriptionPrompt(): Boolean {
        val isNovel = media.format?.contains("NOVEL", ignoreCase = true) == true
        return if (isNovel) {
            media.status == "FINISHED"
        } else {
            isMangaCompleted()
        }
    }


    @Suppress("UNCHECKED_CAST")
    private fun <T> loadReaderSettings(
        fileName: String,
        context: Context? = null,
        toast: Boolean = true
    ): T? {
        val a = context ?: currContext()
        try {
            if (a?.fileList() != null)
                if (fileName in a.fileList()) {
                    val fileIS: FileInputStream = a.openFileInput(fileName)
                    val objIS = ObjectInputStream(fileIS)
                    val data = objIS.readObject() as T
                    objIS.close()
                    fileIS.close()
                    return data
                }
        } catch (e: Exception) {
            if (toast) snackString(a?.getString(R.string.error_loading_data, fileName))
            //try to delete the file
            try {
                a?.deleteFile(fileName)
            } catch (e: Exception) {
                Injekt.get<CrashlyticsInterface>().log("Failed to delete file $fileName")
                Injekt.get<CrashlyticsInterface>().logException(e)
            }
            e.printStackTrace()
        }
        return null
    }

    private fun saveReaderSettings(fileName: String, data: Any?, context: Context? = null) {
        tryWith {
            val a = context ?: currContext()
            if (a != null) {
                val fos: FileOutputStream = a.openFileOutput(fileName, Context.MODE_PRIVATE)
                val os = ObjectOutputStream(fos)
                os.writeObject(data)
                os.close()
                fos.close()
            }
        }
    }

    fun getTransformation(mangaImage: MangaImage): BitmapTransformation? {
        return model.loadTransformation(mangaImage, media.selected!!.sourceIndex)
    }

    fun onImageLongClicked(
        pos: Int,
        img1: MangaImage,
        img2: MangaImage?,
        callback: ((ImageViewDialog) -> Unit)? = null
    ): Boolean {
        if (!defaultSettings.longClickImage) return false
        val title = "(Page ${pos + 1}${if (img2 != null) "-${pos + 2}" else ""}) ${
            chaptersTitleArr.getOrNull(currentChapterIndex)?.replace(" : ", " - ") ?: ""
        } [${media.userPreferredName}]"

        ImageViewDialog.newInstance(title, img1.url, true, img2?.url).apply {
            val transforms1 = mutableListOf<BitmapTransformation>()
            val parserTransformation1 = getTransformation(img1)
            if (parserTransformation1 != null) transforms1.add(parserTransformation1)
            val transforms2 = mutableListOf<BitmapTransformation>()
            if (img2 != null) {
                val parserTransformation2 = getTransformation(img2)
                if (parserTransformation2 != null) transforms2.add(parserTransformation2)
            }
            val threshold = defaultSettings.cropBorderThreshold
            if (defaultSettings.cropBorders) {
                transforms1.add(RemoveBordersTransformation(true, threshold))
                transforms1.add(RemoveBordersTransformation(false, threshold))
                if (img2 != null) {
                    transforms2.add(RemoveBordersTransformation(true, threshold))
                    transforms2.add(RemoveBordersTransformation(false, threshold))
                }
            }
            trans1 = transforms1.ifEmpty { null }
            trans2 = transforms2.ifEmpty { null }
            onReloadPressed = callback
            show(supportFragmentManager, "image")
        }
        return true
    }

    fun saveCurrentSettings() {
        if (::media.isInitialized) {
            saveReaderSettings("${media.id}_current_settings", defaultSettings)
        }
    }

    fun applySidePadding(paddingPercent: Int) {
        defaultSettings.continuousSidePadding = paddingPercent
        saveCurrentSettings()
        if (defaultSettings.layout != PAGED) {
            val screenWidth = Resources.getSystem().displayMetrics.widthPixels
            val paddingPx = (paddingPercent / 100f * (screenWidth / 2f)).toInt()
            if (defaultSettings.direction == TOP_TO_BOTTOM || defaultSettings.direction == BOTTOM_TO_TOP) {
                binding.mangaReaderRecycler.updatePadding(left = paddingPx, right = paddingPx)
            } else {
                binding.mangaReaderRecycler.updatePadding(top = paddingPx, bottom = paddingPx)
            }
        }
    }

    fun applyOneHandZoom(enabled: Boolean) {
        defaultSettings.oneHandZoom = enabled
        saveCurrentSettings()
    }

    fun applyBackgroundColor(colorIndex: Int) {
        defaultSettings.backgroundColor = colorIndex
        saveCurrentSettings()
        val color = when (colorIndex) {
            1 -> Color.BLACK
            2 -> Color.parseColor("#222222")
            3 -> Color.WHITE
            else -> ContextCompat.getColor(this, R.color.nav_bg)
        }
        binding.root.setBackgroundColor(color)
        binding.mangaReaderRecycler.setBackgroundColor(color)
        binding.mangaReaderPager.setBackgroundColor(color)
        webGpuReaderView?.updateBackgroundColor(color)
    }

    fun applyOrientationLock(orientationIndex: Int) {
        defaultSettings.defaultRotation = orientationIndex
        saveCurrentSettings()
        requestedOrientation = when (orientationIndex) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    fun updatePreloadAmount(amount: Int) {
        defaultSettings.preloadAmount = amount
        saveCurrentSettings()
        val layoutManager = binding.mangaReaderRecycler.layoutManager as? PreloadLinearLayoutManager
        layoutManager?.preloadItemCount = amount
    }

    fun updateAutoScrollState(enabled: Boolean) {
        defaultSettings.autoScroll = enabled
        saveCurrentSettings()
        if (::binding.isInitialized) {
            binding.mangaReaderAutoScrollPlayBar.isVisible = enabled && defaultSettings.layout != PAGED
            if (enabled && defaultSettings.layout != PAGED) {
                autoScrollHelper.speed = defaultSettings.autoScrollSpeed
                autoScrollHelper.attach(binding.mangaReaderRecycler, defaultSettings.direction)
                autoScrollHelper.stop()
                binding.autoScrollPlayPause.setImageResource(R.drawable.ic_round_play_arrow_24)
            } else {
                autoScrollHelper.stop()
                binding.autoScrollPlayPause.setImageResource(R.drawable.ic_round_play_arrow_24)
            }
        }
    }

    fun updateAutoScrollSpeed(speed: Float) {
        defaultSettings.autoScrollSpeed = speed
        saveCurrentSettings()
        autoScrollHelper.speed = speed
    }

    fun getChapterDisplayTitle(chap: MangaChapter?): String {
        if (chap == null) return ""
        val index = chaptersArr.indexOf(chap.uniqueNumber())
        if (index != -1) {
            val title = chaptersTitleArr.getOrNull(index)
            if (!title.isNullOrEmpty()) return title
        }
        val t = chap.title
        return if (!t.isNullOrEmpty() && t != "null") {
            "Chapter ${chap.number} : $t"
        } else {
            "Chapter ${chap.number}"
        }
    }

    fun getFinishedChapterTitle(): String {
        return getChapterDisplayTitle(if (::chapter.isInitialized) chapter else null)
    }

    fun getNextChapterTitle(): String? {
        val nextIndex = currentChapterIndex + 1
        return chaptersArr.getOrNull(nextIndex)?.let { chapters[it] }?.let { getChapterDisplayTitle(it) }
    }

    private val loadingChapters = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    internal fun preloadChapterAndAppend(targetChapter: MangaChapter) {
        val chapterKey = targetChapter.uniqueNumber()
        if (loadingChapters.contains(chapterKey)) return

        val targetIndex = chaptersArr.indexOf(chapterKey)
        val afterNextIndex = targetIndex + 1
        val afterNextChapter = chaptersArr.getOrNull(afterNextIndex)?.let { chapters[it] }

        if (targetChapter.images().isNotEmpty()) {
            imageAdapter?.appendChapter(targetChapter, afterNextChapter)
            return
        }

        loadingChapters.add(chapterKey)
        scope.launch(Dispatchers.IO) {
            try {
                model.loadMangaChapterImages(targetChapter, media.selected!!, false)
                withContext(Dispatchers.Main) {
                    if (targetChapter.images().isNotEmpty()) {
                        imageAdapter?.appendChapter(targetChapter, afterNextChapter)
                    }
                }
            } catch (e: Exception) {
                logError(e)
            } finally {
                loadingChapters.remove(chapterKey)
            }
        }
    }

    internal fun preloadChapterAndPrepend(targetChapter: MangaChapter) {
        val chapterKey = targetChapter.uniqueNumber()
        if (loadingChapters.contains(chapterKey)) return

        val targetIndex = chaptersArr.indexOf(chapterKey)
        val beforePrevIndex = targetIndex - 1
        val beforePrevChapter = chaptersArr.getOrNull(beforePrevIndex)?.let { chapters[it] }

        val applyPrepend = {
            val layoutManager = binding.mangaReaderRecycler.layoutManager as? LinearLayoutManager
            val firstVisiblePos = layoutManager?.findFirstVisibleItemPosition() ?: RecyclerView.NO_POSITION
            val firstView = if (firstVisiblePos != RecyclerView.NO_POSITION) layoutManager?.findViewByPosition(firstVisiblePos) else null
            val offset = if (defaultSettings.direction == LEFT_TO_RIGHT || defaultSettings.direction == RIGHT_TO_LEFT) {
                firstView?.left ?: 0
            } else {
                firstView?.top ?: 0
            }

            val insertedCount = imageAdapter?.prependChapter(targetChapter, beforePrevChapter) ?: 0
            if (insertedCount > 0 && firstVisiblePos != RecyclerView.NO_POSITION && layoutManager != null) {
                layoutManager.scrollToPositionWithOffset(firstVisiblePos + insertedCount, offset)
            }
        }

        if (targetChapter.images().isNotEmpty()) {
            applyPrepend()
            return
        }

        loadingChapters.add(chapterKey)
        scope.launch(Dispatchers.IO) {
            try {
                model.loadMangaChapterImages(targetChapter, media.selected!!, false)
                withContext(Dispatchers.Main) {
                    if (targetChapter.images().isNotEmpty()) {
                        applyPrepend()
                    }
                }
            } catch (e: Exception) {
                logError(e)
            } finally {
                loadingChapters.remove(chapterKey)
            }
        }
    }

    private fun isMovingForward(
        oldChapNum: Float?,
        newChapNum: Float?,
        oldIdx: Int,
        newIdx: Int
    ): Boolean =
        if (oldChapNum != null && newChapNum != null && oldChapNum != newChapNum) {
            newChapNum > oldChapNum
        } else {
            newIdx > oldIdx
        }

    private fun handlePreviousChapterProgressOnScroll(
        oldChapter: MangaChapter,
        oldChapNum: Float?,
        newChapter: MangaChapter,
        newChapNum: Float?
    ) {
        val oldIdx = chaptersArr.indexOf(oldChapter.uniqueNumber())
        val newIdx = chaptersArr.indexOf(newChapter.uniqueNumber())
        if (!isMovingForward(oldChapNum, newChapNum, oldIdx, newIdx)) return

        PrefManager.setCustomVal("${media.id}_${oldChapter.number}", maxChapterPage)
        val cleanOldChapNum = oldChapNum?.let {
            if (it % 1 == 0f) it.toInt().toString() else it.toString()
        }
        cleanOldChapNum?.let { PrefManager.setCustomVal("${media.id}_$it", maxChapterPage) }

        val incognito: Boolean = PrefManager.getVal(PrefName.Incognito)
        if (!incognito && PrefManager.getCustomVal("${media.id}_save_progress", true) &&
            (!media.isAdult || PrefManager.getVal<Boolean>(PrefName.UpdateForHReader))
        ) {
            val oldChapNumStr = cleanOldChapNum ?: oldChapter.number
            if (oldChapNumStr.isNotEmpty()) {
                updateProgress(media, oldChapNumStr)
            }
        }
    }

    private fun updateChapterUiAndSlider(cleanChapNum: String?, totalPages: Int, pageNum: Int) {
        if (binding.mangaReaderChapterSelect.selectedItemPosition != currentChapterIndex && currentChapterIndex >= 0) {
            binding.mangaReaderChapterSelect.setSelection(currentChapterIndex)
        }

        binding.mangaReaderNextChap.text =
            chaptersTitleArr.getOrNull(currentChapterIndex + 1) ?: ""
        binding.mangaReaderPrevChap.text =
            chaptersTitleArr.getOrNull(currentChapterIndex - 1) ?: ""

        maxChapterPage = totalPages.toLong()
        PrefManager.setCustomVal("${media.id}_${chapter.number}_max", maxChapterPage)
        cleanChapNum?.let { PrefManager.setCustomVal("${media.id}_${it}_max", maxChapterPage) }

        if (totalPages > 1) {
            binding.mangaReaderSlider.visibility = View.VISIBLE
            binding.mangaReaderSlider.updateRangeAndValue(
                to = maxChapterPage.toFloat(),
                currentVal = pageNum.toFloat(),
                from = 1f
            )
        } else {
            binding.mangaReaderSlider.visibility = View.GONE
        }
    }

    internal fun onChapterScrolledTo(newChapter: MangaChapter, pageNum: Int, totalPages: Int) {
        if (newChapter.uniqueNumber() != chapter.uniqueNumber()) {
            val oldChapter = chapter
            val oldChapNum = MediaNameAdapter.findChapterNumber(oldChapter.number)
            val newChapNum = MediaNameAdapter.findChapterNumber(newChapter.number)

            handlePreviousChapterProgressOnScroll(oldChapter, oldChapNum, newChapter, newChapNum)

            chapter = newChapter
            media.manga?.selectedChapter = chapter
            currentChapterIndex = chaptersArr.indexOf(chapter.uniqueNumber())
            PrefManager.setCustomVal("${media.id}_current_chp", chapter.number)
            val cleanChapNum = MediaNameAdapter.findChapterNumber(chapter.number)?.let {
                if (it % 1 == 0f) it.toInt().toString() else it.toString()
            }
            cleanChapNum?.let { PrefManager.setCustomVal("${media.id}_current_chp_num", it) }

            updateChapterUiAndSlider(cleanChapNum, totalPages, pageNum)
        }

        updatePageNumber(pageNum.toLong())
    }

    fun loadNextChapter() {
        binding.mangaReaderNextChapter.performClick()
    }

    fun loadPreviousChapter() {
        binding.mangaReaderPreviousChapter.performClick()
    }

    fun triggerEInkFlash() {
        if (!defaultSettings.eInkFlash) return
        binding.mangaReaderEInkOverlay.apply {
            visibility = View.VISIBLE
            alpha = 1f
            postDelayed({
                animate().alpha(0f).setDuration(120).withEndAction {
                    visibility = View.GONE
                }.start()
            }, 80)
        }
    }

    private fun isChapterAlreadyQueued(chapter: MangaChapter): Boolean {
        val title = media.mainName()
        return MangaServiceDataSingleton.downloadQueue.any {
            it.title == title && (it.chapter == chapter.number || it.chapter == chapter.title)
        } || MangaServiceDataSingleton.currentTasks.any {
            it.title == title && (it.chapter == chapter.number || it.chapter == chapter.title)
        }
    }

    private fun enqueueSmartDownload(nextChapter: MangaChapter) {
        scope.launch(Dispatchers.IO) {
            try {
                var parser = model.mangaReadSources?.get(media.selected?.sourceIndex ?: 0) as? DynamicMangaParser
                if (parser == null) {
                    parser = model.mangaReadSources?.list?.mapNotNull { it.get?.value as? DynamicMangaParser }?.firstOrNull()
                }
                val images = parser?.imageList(nextChapter.sChapter) ?: return@launch
                if (images.isNotEmpty()) {
                    val downloadTask = MangaDownloaderService.DownloadTask(
                        title = media.mainName(),
                        chapter = nextChapter.number,
                        scanlator = nextChapter.scanlator ?: "Unknown",
                        imageData = images,
                        sourceMedia = media,
                        retries = 25,
                        simultaneousDownloads = 2
                    )
                    MangaServiceDataSingleton.downloadQueue.offer(downloadTask)
                    val intent = Intent(this@MangaReaderActivity, MangaDownloaderService::class.java)
                    withContext(Dispatchers.Main) {
                        ContextCompat.startForegroundService(this@MangaReaderActivity, intent)
                    }
                    MangaServiceDataSingleton.isServiceRunning = true
                }
            } catch (e: Exception) {
                ani.dantotsu.util.Logger.log("SmartDownloadManga error: ${e.message}")
            }
        }
    }

    private fun checkSmartDownloadManga(currentChapter: MangaChapter) {
        if (!PrefManager.getVal<Boolean>(PrefName.SmartDownloadManga)) return
        val downloadsManager = Injekt.get<DownloadsManager>()
        val isCurrentDownloaded = downloadsManager.queryDownload(media.mainName(), currentChapter.number, MediaType.MANGA) ||
                model.mangaReadSources?.isDownloadedSource(media.selected?.sourceIndex ?: -1) == true
        if (!isCurrentDownloaded) return

        val nextIndex = currentChapterIndex + 1
        if (nextIndex !in chaptersArr.indices) return
        val nextChapterKey = chaptersArr[nextIndex]
        val nextChapter = chapters[nextChapterKey] ?: media.manga?.chapters?.get(nextChapterKey) ?: return

        if (downloadsManager.queryDownload(media.mainName(), nextChapter.number, MediaType.MANGA)) return
        if (isChapterAlreadyQueued(nextChapter)) return

        enqueueSmartDownload(nextChapter)
    }

    private fun Slider.updateRangeAndValue(to: Float, currentVal: Float, from: Float = 1f) {
        val safeTo = if (to >= from) to else from + 0.01f
        val safeVal = currentVal.coerceIn(from, safeTo)

        if (this.valueFrom > from) {
            this.valueFrom = from
        }

        if (safeTo < this.value) {
            this.value = safeVal
            this.valueTo = safeTo
        } else {
            this.valueTo = safeTo
            this.value = safeVal
        }

        if (this.valueFrom != from) {
            this.valueFrom = from
        }
    }
}
