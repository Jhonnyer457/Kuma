package ani.dantotsu.media

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isGone
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ConcatAdapter
import androidx.recyclerview.widget.GridLayoutManager
import ani.dantotsu.EmptyAdapter
import ani.dantotsu.R
import ani.dantotsu.Refresh
import ani.dantotsu.databinding.ActivityStudioBinding
import ani.dantotsu.initActivity
import ani.dantotsu.navBarHeight
import ani.dantotsu.others.getSerialized
import ani.dantotsu.px
import ani.dantotsu.statusBarHeight
import ani.dantotsu.themes.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StudioActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStudioBinding
    private val scope = lifecycleScope
    private val model: OtherDetailsViewModel by viewModels()
    private var studio: Studio? = null
    private var loaded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ThemeManager(this).applyTheme()
        binding = ActivityStudioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initActivity(this)
        this.window.statusBarColor = ContextCompat.getColor(this, R.color.nav_bg)

        val screenWidth = resources.displayMetrics.run { widthPixels / density }

        binding.root.updateLayoutParams<ViewGroup.MarginLayoutParams> { topMargin += statusBarHeight }
        binding.studioRecycler.updatePadding(bottom = 64f.px + navBarHeight)
        binding.studioTitle.isSelected = true

        studio = intent.getSerialized("studio")
        binding.studioTitle.text = studio?.name

        binding.studioClose.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        setupStudioFav()
        model.getStudio().observe(this) {
            if (it != null) {
                studio = it
                loaded = true
                binding.studioProgressBar.visibility = View.GONE
                binding.studioRecycler.visibility = View.VISIBLE

                setupStudioRecycler(studio!!, screenWidth)
            }
        }
        val live = Refresh.activity.getOrPut(this.hashCode()) { MutableLiveData(true) }
        live.observe(this) {
            if (it) {
                scope.launch {
                    if (studio != null)
                        withContext(Dispatchers.IO) { model.loadStudio(studio!!) }
                    live.postValue(false)
                }
            }
        }
    }

    override fun onDestroy() {
        if (Refresh.activity.containsKey(this.hashCode())) {
            Refresh.activity.remove(this.hashCode())
        }
        super.onDestroy()
    }

    override fun onResume() {
        if (::binding.isInitialized) {
            binding.studioProgressBar.isGone = loaded
        }
        super.onResume()
    }
    private fun setupStudioFav() {
        var isFav = false
        binding.studioFav.visibility = if (ani.dantotsu.connections.anilist.Anilist.token != null) View.VISIBLE else View.GONE
        scope.launch(Dispatchers.IO) {
            val studioId = studio?.id?.toIntOrNull() ?: return@launch
            isFav = ani.dantotsu.connections.anilist.Anilist.query.isUserFav(
                ani.dantotsu.connections.anilist.AnilistMutations.FavType.STUDIO,
                studioId
            )
            withContext(Dispatchers.Main) {
                binding.studioFavIcon.setColorFilter(
                    if (isFav) ContextCompat.getColor(this@StudioActivity, R.color.yt_red)
                    else ContextCompat.getColor(this@StudioActivity, R.color.bg_opp)
                )
            }
        }
        binding.studioFav.setOnClickListener {
            val studioId = studio?.id?.toIntOrNull() ?: return@setOnClickListener
            scope.launch(Dispatchers.IO) {
                val success = ani.dantotsu.connections.anilist.Anilist.mutation.toggleFav(
                    ani.dantotsu.connections.anilist.AnilistMutations.FavType.STUDIO,
                    studioId
                )
                withContext(Dispatchers.Main) {
                    if (success) {
                        isFav = !isFav
                        binding.studioFavIcon.setColorFilter(
                            if (isFav) ContextCompat.getColor(this@StudioActivity, R.color.yt_red)
                            else ContextCompat.getColor(this@StudioActivity, R.color.bg_opp)
                        )
                        ani.dantotsu.snackString(if (isFav) "Added to favorites" else "Removed from favorites")
                    }
                }
            }
        }

    }

    private fun setupStudioRecycler(studio: Studio, screenWidth: Float) {
                val titlePosition = arrayListOf<Int>()
                val concatAdapter = ConcatAdapter()
                val map = studio.yearMedia ?: return
                val keys = map.keys.toTypedArray()
                var pos = 0

                val gridSize = (screenWidth / 124f).toInt()
                val gridLayoutManager = GridLayoutManager(this, gridSize)
                gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        return when (position in titlePosition) {
                            true -> gridSize
                            else -> 1
                        }
                    }
                }
                for (i in keys.indices) {
                    val medias = map[keys[i]]!!
                    val empty = if (medias.size >= 4) medias.size % 4 else 4 - medias.size
                    titlePosition.add(pos)
                    pos += empty + medias.size + 1

                    concatAdapter.addAdapter(TitleAdapter("${keys[i]} (${medias.size})"))
                    concatAdapter.addAdapter(MediaAdaptor(0, medias, this, true))
                    concatAdapter.addAdapter(EmptyAdapter(empty))
                }

                binding.studioRecycler.adapter = concatAdapter
                binding.studioRecycler.layoutManager = gridLayoutManager
    }

}
