package tachiyomi.domain.source.manga.model

import eu.kanade.tachiyomi.source.MangaSource
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.SMangaUpdate
import rx.Observable

@Suppress("OverridingDeprecatedMember")
class StubMangaSource(private val sourceData: MangaSourceData) : MangaSource {

    override val id: Long = sourceData.id

    override val name: String = sourceData.name.ifBlank { id.toString() }

    override val lang: String = sourceData.lang

    override val supportsLatest: Boolean = false

    override suspend fun getPopularManga(page: Int): MangasPage {
        throw SourceNotInstalledException()
    }

    override suspend fun getLatestUpdates(page: Int): MangasPage {
        throw SourceNotInstalledException()
    }

    override suspend fun getSearchManga(page: Int, query: String, filters: FilterList): MangasPage {
        throw SourceNotInstalledException()
    }

    override suspend fun getMangaUpdate(
        manga: SManga,
        chapters: List<SChapter>,
        fetchDetails: Boolean,
        fetchChapters: Boolean,
    ): SMangaUpdate {
        throw SourceNotInstalledException()
    }

    override suspend fun getMangaDetails(manga: SManga): SManga {
        throw SourceNotInstalledException()
    }

    @Deprecated("Use the 1.x API instead", replaceWith = ReplaceWith("getMangaDetails"))
    override fun fetchMangaDetails(manga: SManga): Observable<SManga> {
        return Observable.error(SourceNotInstalledException())
    }

    override suspend fun getChapterList(manga: SManga): List<SChapter> {
        throw SourceNotInstalledException()
    }

    @Deprecated("Use the 1.x API instead", replaceWith = ReplaceWith("getChapterList"))
    override fun fetchChapterList(manga: SManga): Observable<List<SChapter>> {
        return Observable.error(SourceNotInstalledException())
    }

    override suspend fun getPageList(chapter: SChapter): List<Page> {
        throw SourceNotInstalledException()
    }

    @Deprecated("Use the 1.x API instead", replaceWith = ReplaceWith("getPageList"))
    override fun fetchPageList(chapter: SChapter): Observable<List<Page>> {
        return Observable.error(SourceNotInstalledException())
    }

    override fun toString(): String {
        return if (sourceData.isMissingInfo.not()) "$name (${lang.uppercase()})" else id.toString()
    }
}

class SourceNotInstalledException : Exception()
