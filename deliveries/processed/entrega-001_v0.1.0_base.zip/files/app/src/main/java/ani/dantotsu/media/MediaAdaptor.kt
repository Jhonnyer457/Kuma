package ani.dantotsu.media

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import ani.dantotsu.R
import ani.dantotsu.blurImage
import ani.dantotsu.databinding.ItemMediaCompactBinding
import ani.dantotsu.databinding.ItemMediaLargeBinding
import ani.dantotsu.databinding.ItemMediaPageBinding
import ani.dantotsu.databinding.ItemMediaPageSmallBinding
import ani.dantotsu.loadImage
import ani.dantotsu.setAnimation
import ani.dantotsu.setSafeOnClickListener
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.connections.mapping.IdMapper
import com.flaviofaria.kenburnsview.RandomTransitionGenerator
import java.io.Serializable


class MediaAdaptor(
    var type: Int,
    val mediaList: MutableList<Media>?,
    private val activity: FragmentActivity,
    private val matchParent: Boolean = false,
    private val viewPager: ViewPager2? = null,
    private val fav: Boolean = false,
    private val isOtherUser: Boolean = false,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (type) {
            0 -> MediaViewHolder(
                ItemMediaCompactBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )

            1 -> MediaLargeViewHolder(
                ItemMediaLargeBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )

            2 -> MediaPageViewHolder(
                ItemMediaPageBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )

            3 -> MediaPageSmallViewHolder(
                ItemMediaPageSmallBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )

            else -> throw IllegalArgumentException()
        }

    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (type) {
            0 -> bindCompactViewHolder(holder as MediaViewHolder, position)
            1 -> bindLargeViewHolder(holder as MediaLargeViewHolder, position)
            2 -> bindPageViewHolder(holder as MediaPageViewHolder, position)
            3 -> bindPageSmallViewHolder(holder as MediaPageSmallViewHolder, position)
        }
    }

    private fun bindCompactViewHolder(holder: MediaViewHolder, position: Int) {
        val b = holder.binding
        setAnimation(activity, b.root)
        val media = mediaList?.getOrNull(position) ?: return
        val density = activity.resources.displayMetrics.density
        if (media.id < 0) {
            bindCompactSkeleton(b, density)
        } else {
            bindCompactContent(b, media, density)
        }
        b.itemCompactProgressContainer.visibility = if (fav) View.GONE else View.VISIBLE
    }

    private fun bindCompactSkeleton(b: ItemMediaCompactBinding, density: Float) {
        b.itemCompactTitle.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            width = (108 * density).toInt()
            height = (12 * density).toInt()
            bottomMargin = (4 * density).toInt()
            topMargin = (4 * density).toInt()
        }
        b.itemCompactTitle.background = ContextCompat.getDrawable(b.root.context, R.drawable.skeleton_text_placeholder)
        b.itemCompactTitle.text = ""

        b.itemCompactProgressContainer.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            width = (54 * density).toInt()
            height = (8 * density).toInt()
            topMargin = (2 * density).toInt()
        }
        b.itemCompactProgressContainer.background = ContextCompat.getDrawable(b.root.context, R.drawable.skeleton_stats_placeholder)
        b.itemCompactUserProgress.text = ""
        b.itemCompactTotal.text = ""
        b.itemCompactScoreBG.isVisible = false
        b.itemCompactOngoing.isVisible = false
        b.itemCompactType.isVisible = false
        b.itemCompactImage.setImageResource(R.drawable.skeleton_cover_placeholder)
        b.itemCompactUnreadBadge.isVisible = false
    }

    private fun bindCompactContent(b: ItemMediaCompactBinding, media: Media, density: Float) {
        b.itemCompactTitle.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            width = (108 * density).toInt()
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            bottomMargin = 0
            topMargin = 0
        }
        b.itemCompactTitle.background = null

        b.itemCompactProgressContainer.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            width = ViewGroup.LayoutParams.MATCH_PARENT
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            topMargin = 0
        }
        b.itemCompactProgressContainer.background = null
        b.itemCompactScoreBG.isVisible = true
        b.itemCompactImage.loadImage(media.cover)
        b.itemCompactOngoing.isVisible =
            media.status == b.root.context.getString(R.string.status_releasing)
        b.itemCompactTitle.text = media.userPreferredName
        b.itemCompactScore.text = formatScore(media)
        b.itemCompactScoreBG.background = ContextCompat.getDrawable(
            b.root.context,
            getScoreBackgroundRes(media)
        )
        b.itemCompactUserProgress.text = (media.userProgress ?: "~").toString()
        bindCompactRelation(b, media)
        bindCompactMediaTotal(b, media)
        bindCompactUnreadBadge(b, media)
    }

    private fun bindCompactRelation(b: ItemMediaCompactBinding, media: Media) {
        if (media.relation != null) {
            b.itemCompactRelation.text = "${media.relation}  "
            b.itemCompactType.visibility = View.VISIBLE

            if (media.relation!!.contains("\n")) {
                b.itemCompactRelation.apply {
                    isSingleLine = false
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.START

                    includeFontPadding = false
                    setLineSpacing(0f, 0.9f)
                }
            } else {
                b.itemCompactRelation.isSingleLine = true
                b.itemCompactRelation.maxLines = 1
            }
        } else {
            b.itemCompactType.visibility = View.GONE
        }
    }

    private fun bindCompactMediaTotal(b: ItemMediaCompactBinding, media: Media) {
        if (media.anime != null) {
            if (media.relation != null) {
                b.itemCompactTypeImage.setImageDrawable(
                    AppCompatResources.getDrawable(
                        activity,
                        R.drawable.ic_round_movie_filter_24
                    )
                )
            }
            b.itemCompactTotal.text = " | " + formatAnimeEpisodesForCompact(media)
        } else if (media.manga != null) {
            if (media.relation != null) {
                b.itemCompactTypeImage.setImageDrawable(
                    AppCompatResources.getDrawable(
                        activity,
                        R.drawable.ic_round_import_contacts_24
                    )
                )
            }
            b.itemCompactTotal.text = " | " + formatMangaChapters(media)
        }
    }

    private fun bindLargeViewHolder(holder: MediaLargeViewHolder, position: Int) {
        val b = holder.binding
        setAnimation(activity, b.root)
        val media = mediaList?.getOrNull(position) ?: return
        b.itemCompactImage.loadImage(media.cover)
        blurImage(b.itemCompactBanner, media.banner ?: media.cover)
        b.itemCompactOngoing.isVisible =
            media.status == b.root.context.getString(R.string.status_releasing)
        b.itemCompactTitle.text = media.userPreferredName
        b.itemCompactScore.text = formatScore(media)
        b.itemCompactScoreBG.background = ContextCompat.getDrawable(
            b.root.context,
            getScoreBackgroundRes(media)
        )
        bindMediaTotals(b.root.context, media, b.itemTotal, b.itemCompactTotal)
        handleInfiniteScroll(position)
    }

    private fun bindPageViewHolder(holder: MediaPageViewHolder, position: Int) {
        val b = holder.binding
        val media = mediaList?.getOrNull(position) ?: return
        b.itemCompactImage.loadImage(media.cover)
        setupBannerTransition(b.itemCompactBanner, b.itemCompactBannerNoKen, media.cover, media.banner)
        b.itemCompactOngoing.isVisible =
            media.status == b.root.context.getString(R.string.status_releasing)
        b.itemCompactTitle.text = media.userPreferredName
        bindCarouselLogo(media, b.itemCompactTitle, b.itemCompactLogo)
        b.itemCompactScore.text = formatScore(media)
        b.itemCompactScoreBG.background = ContextCompat.getDrawable(
            b.root.context,
            getScoreBackgroundRes(media)
        )
        bindMediaTotals(b.root.context, media, b.itemTotal, b.itemCompactTotal)
        handleInfiniteScroll(position)
    }

    private fun bindPageSmallViewHolder(holder: MediaPageSmallViewHolder, position: Int) {
        val b = holder.binding
        val media = mediaList?.getOrNull(position) ?: return
        b.itemCompactImage.loadImage(media.cover)
        setupBannerTransition(b.itemCompactBanner, b.itemCompactBannerNoKen, media.cover, media.banner)
        b.itemCompactOngoing.isVisible =
            media.status == b.root.context.getString(R.string.status_releasing)
        b.itemCompactTitle.text = media.userPreferredName
        bindCarouselLogo(
            media,
            b.itemCompactTitle,
            b.itemCompactLogo,
            b.itemCompactSynopsis,
            b.itemCompactLogoContainer
        )
        b.itemCompactScore.text = formatScore(media)
        b.itemCompactScoreBG.background = ContextCompat.getDrawable(
            b.root.context,
            getScoreBackgroundRes(media)
        )
        bindGenresAndStatus(b, media)
        bindMediaTotals(b.root.context, media, b.itemTotal, b.itemCompactTotal)
        handleInfiniteScroll(position)
    }

    private fun bindGenresAndStatus(b: ItemMediaPageSmallBinding, media: Media) {
        if (media.genres.isNotEmpty()) {
            b.itemCompactGenres.text = media.genres.joinToString(" • ")
        } else if (media.tags.isNotEmpty()) {
            b.itemCompactGenres.text = media.tags.take(3).joinToString(" • ")
        } else {
            b.itemCompactGenres.text = ""
        }
        b.itemCompactStatus.text = media.status ?: ""
    }

    private fun formatScore(media: Media): String {
        val score = if (media.userScore == 0) media.meanScore ?: 0 else media.userScore
        return (score / 10.0).toString()
    }

    private fun getScoreBackgroundRes(media: Media): Int {
        return if (media.userScore != 0) R.drawable.item_user_score else R.drawable.item_score
    }

    private fun formatAnimeEpisodesForCompact(media: Media): String {
        val anime = media.anime ?: return (media.manga?.totalChapters ?: "~").toString()
        val total = (anime.totalEpisodes ?: "~").toString()
        return if (anime.nextAiringEpisode != null) {
            "${anime.nextAiringEpisode} | $total"
        } else {
            total
        }
    }

    private fun formatAnimeEpisodes(media: Media): String {
        val anime = media.anime ?: return "??"
        val total = (anime.totalEpisodes ?: "??").toString()
        return if (anime.nextAiringEpisode != null) {
            "${anime.nextAiringEpisode} / $total"
        } else {
            total
        }
    }

    private fun formatMangaChapters(media: Media): String {
        val manga = media.manga ?: return "??"
        val totalCh = manga.totalChapters ?: IdMapper.getCachedChapters(media.id)
        if (manga.totalChapters == null && totalCh != null) {
            manga.totalChapters = totalCh
        }
        return (totalCh ?: "??").toString()
    }

    private fun bindMediaTotals(
        context: Context,
        media: Media,
        totalLabel: android.widget.TextView,
        totalCount: android.widget.TextView
    ) {
        if (media.anime != null) {
            val isPlural = (media.anime.totalEpisodes ?: 0) != 1
            totalLabel.text = " " + context.getString(
                if (isPlural) R.string.episode_plural else R.string.episode_singular
            )
            totalCount.text = formatAnimeEpisodes(media)
        } else if (media.manga != null) {
            val isPlural = (media.manga.totalChapters ?: 0) != 1
            totalLabel.text = " " + context.getString(
                if (isPlural) R.string.chapter_plural else R.string.chapter_singular
            )
            totalCount.text = formatMangaChapters(media)
        }
    }

    private fun setupBannerTransition(
        banner: com.flaviofaria.kenburnsview.KenBurnsView,
        bannerNoKen: ImageView,
        cover: String?,
        bannerUrl: String?
    ) {
        val bannerAnimations: Boolean = PrefManager.getVal(PrefName.BannerAnimations)
        if (bannerAnimations) {
            val speed = PrefManager.getVal<Float>(PrefName.AnimationSpeed)
            banner.setTransitionGenerator(
                RandomTransitionGenerator(
                    (10000 + 15000 * speed).toLong(),
                    AccelerateDecelerateInterpolator()
                )
            )
        }
        blurImage(
            if (bannerAnimations) banner else bannerNoKen,
            bannerUrl ?: cover
        )
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun handleInfiniteScroll(position: Int) {
        if (mediaList != null && position == mediaList.size - 2 && viewPager != null) {
            viewPager.post {
                val start = mediaList.size
                mediaList.addAll(mediaList)
                val count = mediaList.size - start
                notifyItemRangeInserted(start, count)
            }
        }
    }

    private fun bindCompactUnreadBadge(
        b: ItemMediaCompactBinding,
        media: Media
    ) {
        if (media.cameFromContinue && PrefManager.getVal<Boolean>(PrefName.ShowUnreadCount)) {
            val total = if (media.anime != null) {
                media.anime.nextAiringEpisode ?: media.anime.totalEpisodes
            } else if (media.manga != null) {
                media.manga.totalChapters ?: IdMapper.getCachedChapters(media.id)
            } else null
            val progress = media.userProgress ?: 0
            if (total != null && total > progress) {
                val diff = total - progress
                b.itemCompactUnreadText.text = if (diff > 99) "99+" else diff.toString()
                b.itemCompactUnreadBadge.isVisible = true
            } else {
                b.itemCompactUnreadBadge.isVisible = false
            }
        } else {
            b.itemCompactUnreadBadge.isVisible = false
        }
    }

    private fun bindCarouselLogo(
        media: Media,
        titleView: android.widget.TextView,
        logoView: ImageView,
        synopsisView: android.widget.TextView? = null,
        logoContainer: View? = null
    ) {
        val clearLogoEnabled: Boolean = PrefManager.getVal(PrefName.CarouselClearLogo)
        if (!clearLogoEnabled) {
            showCarouselTitle(titleView, logoView, synopsisView, logoContainer)
            return
        }

        val currentId = media.id
        logoView.tag = currentId

        if (!media.clearLogo.isNullOrBlank()) {
            showCarouselLogo(media, media.clearLogo!!, titleView, logoView, synopsisView, logoContainer)
        } else {
            showCarouselTitle(titleView, logoView, synopsisView, logoContainer)
            activity.lifecycleScope.launch(Dispatchers.Main) {
                val logo = CarouselLogoResolver.resolve(media)
                if (logoView.tag == currentId) {
                    if (!logo.isNullOrBlank()) {
                        media.clearLogo = logo
                        showCarouselLogo(media, logo, titleView, logoView, synopsisView, logoContainer)
                    } else {
                        showCarouselTitle(titleView, logoView, synopsisView, logoContainer)
                    }
                }
            }
        }
    }

    private fun showCarouselLogo(
        media: Media,
        url: String,
        titleView: android.widget.TextView,
        logoView: ImageView,
        synopsisView: android.widget.TextView?,
        logoContainer: View?
    ) {
        logoView.loadImage(url)
        logoView.visibility = View.VISIBLE
        logoContainer?.visibility = View.VISIBLE
        titleView.visibility = View.GONE
        if (synopsisView != null) {
            val cleanDesc = media.description?.let { sanitizeDescription(it) }
            if (!cleanDesc.isNullOrBlank()) {
                synopsisView.text = cleanDesc
                synopsisView.visibility = View.VISIBLE
                setupSynopsisLayoutListener(synopsisView, cleanDesc)
            } else {
                synopsisView.visibility = View.GONE
            }
        }
    }

    private fun showCarouselTitle(
        titleView: android.widget.TextView,
        logoView: ImageView,
        synopsisView: android.widget.TextView?,
        logoContainer: View?
    ) {
        titleView.visibility = View.VISIBLE
        logoView.visibility = View.GONE
        logoContainer?.visibility = View.GONE
        removeSynopsisLayoutListener(synopsisView)
    }

    private fun removeSynopsisLayoutListener(synopsisView: android.widget.TextView?) {
        if (synopsisView == null) return
        val oldListener = synopsisView.getTag(R.id.itemCompactSynopsis) as? View.OnLayoutChangeListener
        if (oldListener != null) {
            synopsisView.removeOnLayoutChangeListener(oldListener)
            synopsisView.setTag(R.id.itemCompactSynopsis, null)
        }
        synopsisView.visibility = View.GONE
    }

    private fun setupSynopsisLayoutListener(synopsisView: android.widget.TextView, cleanDesc: String) {
        val oldListener = synopsisView.getTag(R.id.itemCompactSynopsis) as? View.OnLayoutChangeListener
        if (oldListener != null) {
            synopsisView.removeOnLayoutChangeListener(oldListener)
        }
        val newListener = View.OnLayoutChangeListener { v, _, top, _, bottom, _, _, _, _ ->
            val availableHeight = bottom - top - v.paddingTop - v.paddingBottom
            val lh = synopsisView.lineHeight
            if (lh > 0) {
                val maxL = (availableHeight / lh).coerceIn(1, 3)
                if (synopsisView.maxLines != maxL) {
                    synopsisView.maxLines = maxL
                }
                synopsisView.alpha = 0.72f
            } else {
                synopsisView.alpha = 0f
            }
            v.post {
                truncateSynopsisIfNeeded(synopsisView, cleanDesc)
            }
        }
        synopsisView.setTag(R.id.itemCompactSynopsis, newListener)
        synopsisView.addOnLayoutChangeListener(newListener)
    }

    private fun truncateSynopsisIfNeeded(synopsisView: android.widget.TextView, cleanDesc: String) {
        if (synopsisView.text.endsWith("...")) return
        val layout = synopsisView.layout ?: return
        val lineCount = layout.lineCount
        if (lineCount <= 0) return
        val lastLine = (lineCount - 1).coerceAtMost(synopsisView.maxLines - 1)
        val lineEnd = layout.getLineEnd(lastLine)
        if (lineEnd !in 1 until cleanDesc.length) return
        val ellipsisCount = layout.getEllipsisCount(lastLine)
        if (ellipsisCount != 0) return
        val currentText = synopsisView.text.toString()
        val visible = if (lineEnd <= currentText.length) currentText.substring(0, lineEnd).trimEnd() else currentText.trimEnd()
        val lastSpace = visible.lastIndexOf(' ')
        val truncated = if (lastSpace > visible.length - 12 && lastSpace > 0) {
            visible.substring(0, lastSpace).trimEnd() + "..."
        } else if (visible.length > 3) {
            visible.dropLast(3).trimEnd() + "..."
        } else {
            visible + "..."
        }
        synopsisView.text = truncated
    }

    private fun sanitizeDescription(desc: String): String {
        return desc
            .replace(Regex("<[^>]*>"), " ")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#039;", "'")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    override fun getItemCount() = mediaList!!.size

    override fun getItemViewType(position: Int): Int {
        return type
    }

    fun randomOptionClick() {
        val media = if (!mediaList.isNullOrEmpty()) {
            mediaList.random()
        } else {
            null
        }
        media?.let {
            val index = mediaList?.indexOf(it) ?: -1
            clicked(index, null)
        }
    }

    inner class MediaViewHolder(val binding: ItemMediaCompactBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            if (matchParent) itemView.updateLayoutParams { width = -1 }
            itemView.setSafeOnClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                val pos = bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setSafeOnClickListener
                val media = currentAdapter.mediaList?.getOrNull(pos)
                if (media == null || media.id < 0) return@setSafeOnClickListener
                currentAdapter.clicked(
                    pos,
                    binding.itemCompactImage,
                    resizeBitmap(getBitmapFromImageView(binding.itemCompactImage), 100)
                )
            }
            itemView.setOnLongClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                currentAdapter.longClicked(bindingAdapterPosition)
            }
        }
    }

    inner class MediaLargeViewHolder(val binding: ItemMediaLargeBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            itemView.setSafeOnClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                val pos = bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setSafeOnClickListener
                val media = currentAdapter.mediaList?.getOrNull(pos)
                if (media == null || media.id < 0) return@setSafeOnClickListener
                currentAdapter.clicked(
                    pos,
                    binding.itemCompactImage,
                    resizeBitmap(getBitmapFromImageView(binding.itemCompactImage), 100)
                )
            }
            itemView.setOnLongClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                currentAdapter.longClicked(bindingAdapterPosition)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    inner class MediaPageViewHolder(val binding: ItemMediaPageBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.itemCompactImage.setSafeOnClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                val pos = bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setSafeOnClickListener
                val media = currentAdapter.mediaList?.getOrNull(pos)
                if (media == null || media.id < 0) return@setSafeOnClickListener
                currentAdapter.clicked(
                    pos,
                    binding.itemCompactImage,
                    resizeBitmap(getBitmapFromImageView(binding.itemCompactImage), 100)
                )
            }
            itemView.setOnTouchListener { _, _ -> true }
            binding.itemCompactImage.setOnLongClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                currentAdapter.longClicked(bindingAdapterPosition)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    inner class MediaPageSmallViewHolder(val binding: ItemMediaPageSmallBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.itemCompactImage.setSafeOnClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                val pos = bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setSafeOnClickListener
                val media = currentAdapter.mediaList?.getOrNull(pos)
                if (media == null || media.id < 0) return@setSafeOnClickListener
                currentAdapter.clicked(
                    pos,
                    binding.itemCompactImage,
                    resizeBitmap(getBitmapFromImageView(binding.itemCompactImage), 100)
                )
            }
            binding.itemCompactTitleContainer.setSafeOnClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                val pos = bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setSafeOnClickListener
                val media = currentAdapter.mediaList?.getOrNull(pos)
                if (media == null || media.id < 0) return@setSafeOnClickListener
                currentAdapter.clicked(
                    pos,
                    binding.itemCompactImage,
                    resizeBitmap(getBitmapFromImageView(binding.itemCompactImage), 100)
                )
            }
            itemView.setOnTouchListener { _, _ -> true }
            binding.itemCompactImage.setOnLongClickListener {
                val currentAdapter = bindingAdapter as? MediaAdaptor ?: this@MediaAdaptor
                currentAdapter.longClicked(bindingAdapterPosition)
            }
        }
    }

    fun clicked(position: Int, itemCompactImage: ImageView?, bitmap: Bitmap? = null) {
        if ((mediaList?.size ?: 0) > position && position != -1) {
            val media = mediaList?.get(position) ?: return
            if (media.id < 0) return
            if (bitmap != null) MediaSingleton.bitmap = bitmap
            ContextCompat.startActivity(
                activity,
                Intent(activity, MediaDetailsActivity::class.java).putExtra(
                    "media",
                    media as Serializable
                ),
                if (itemCompactImage != null) {
                    ActivityOptionsCompat.makeSceneTransitionAnimation(
                        activity,
                        itemCompactImage,
                        ViewCompat.getTransitionName(itemCompactImage)!!
                    ).toBundle()
                } else {
                    null
                }
            )
        }
    }


    fun longClicked(position: Int): Boolean {
        if (isOtherUser) return false
        if ((mediaList?.size ?: 0) > position && position != -1) {
            val media = mediaList?.get(position) ?: return false
            if (media.id < 0) return false
            if (activity.supportFragmentManager.findFragmentByTag("list") == null) {
                MediaListDialogSmallFragment.newInstance(media)
                    .show(activity.supportFragmentManager, "list")
                return true
            }
        }
        return false
    }

    fun getBitmapFromImageView(imageView: ImageView): Bitmap? {
        val drawable = imageView.drawable ?: return null

        // If the drawable is a BitmapDrawable, then just get the bitmap
        if (drawable is BitmapDrawable) {
            return drawable.bitmap
        }

        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else imageView.width
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else imageView.height
        if (width <= 0 || height <= 0) return null

        val bitmap = try {
            Bitmap.createBitmap(
                width,
                height,
                Bitmap.Config.ARGB_8888
            )
        } catch (_: Exception) {
            return null
        }

        // Draw the drawable onto the bitmap
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)

        return bitmap
    }

    fun resizeBitmap(source: Bitmap?, maxDimension: Int): Bitmap? {
        if (source == null) return null
        val width = source.width
        val height = source.height
        val newWidth: Int
        val newHeight: Int

        if (width > height) {
            newWidth = maxDimension
            newHeight = (height * (maxDimension.toFloat() / width)).toInt()
        } else {
            newHeight = maxDimension
            newWidth = (width * (maxDimension.toFloat() / height)).toInt()
        }

        return Bitmap.createScaledBitmap(source, newWidth, newHeight, true)
    }

}
