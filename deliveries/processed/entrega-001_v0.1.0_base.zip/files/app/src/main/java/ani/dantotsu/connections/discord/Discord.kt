package ani.dantotsu.connections.discord

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.TextView
import ani.dantotsu.R
import ani.dantotsu.others.CustomBottomDialog
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.toast
import ani.dantotsu.tryWith
import io.noties.markwon.Markwon
import io.noties.markwon.SoftBreakAddsNewLinePlugin
import java.io.File

object Discord {

    var token: String? = null
    var userid: String? = null
    var avatar: String? = null

    fun getSavedToken(): Boolean {
        token = PrefManager.getVal(PrefName.DiscordToken, null as String?)
        return token != null
    }

    fun saveToken(newToken: String) {
        PrefManager.setVal(PrefName.DiscordToken, newToken)
        token = newToken  // keep in-memory token in sync
    }

    fun removeSavedToken(context: Context) {
        PrefManager.removeVal(PrefName.DiscordToken)
        token = null
        userid = null
        avatar = null
        RPCManager.reset()
        tryWith(true) {
            // Clear the actual Discord tokens cached by TokenManager
            val discordDir = File(context.filesDir, "discord")
            if (discordDir.deleteRecursively())
                toast(context.getString(R.string.discord_logout_success))
                
            // Clear WebView cookies and storage on the main thread so auto-login doesn't happen
            Handler(Looper.getMainLooper()).post {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
            }
        }
    }

    fun warning(context: Context) = CustomBottomDialog().apply {
        title = context.getString(R.string.warning)
        val md = context.getString(R.string.discord_warning)
        addView(TextView(context).apply {
            val markWon =
                Markwon.builder(context).usePlugin(SoftBreakAddsNewLinePlugin.create()).build()
            markWon.setMarkdown(this, md)
        })

        setNegativeButton(context.getString(R.string.cancel)) {
            dismiss()
        }

        setPositiveButton(context.getString(R.string.login)) {
            dismiss()
            loginIntent(context)
        }
    }

    private fun loginIntent(context: Context) {
        val intent = Intent(context, Login::class.java)
        context.startActivity(intent)
    }

    const val application_Id = "1163925779692912771"
    const val small_Image: String =
        "https://cdn.discordapp.com/emojis/1167344924874784828.webp?size=128&quality=lossless"
    const val small_Image_AniList: String =
        "https://anilist.co/img/icons/android-chrome-512x512.png"
    const val small_Image_MAL: String =
        "https://cdn.myanimelist.net/img/sp/icon/apple-touch-icon-256.png"
    const val small_Image_Simkl: String =
        "https://eu.simkl.in/img_favicon/v2/favicon-192x192.png"
}
