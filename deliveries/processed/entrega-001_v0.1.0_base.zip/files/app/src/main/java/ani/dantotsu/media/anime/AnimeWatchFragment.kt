package ani.dantotsu.media.anime

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.core.math.MathUtils
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.LiveData
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.util.UnstableApi
import androidx.recyclerview.widget.ConcatAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import ani.dantotsu.R
import ani.dantotsu.addons.download.DownloadAddonManager
import ani.dantotsu.databinding.FragmentMediaSourceBinding
import ani.dantotsu.download.DownloadedType
import ani.dantotsu.download.DownloadsManager
import ani.dantotsu.download.DownloadsManager.Companion.compareName
import ani.dantotsu.download.DownloadsManager.Companion.getSubDirectory
import ani.dantotsu.download.anime.AnimeDownloader
import ani.dantotsu.download.anime.AnimeDownloaderService
import ani.dantotsu.download.findValidName
import ani.dantotsu.dp
import ani.dantotsu.isOnline
import ani.dantotsu.media.Media
import ani.dantotsu.media.MediaDetailsActivity
import ani.dantotsu.media.MediaDetailsViewModel
import ani.dantotsu.media.MediaNameAdapter
import ani.dantotsu.media.MediaType
import ani.dantotsu.navBarHeight
import ani.dantotsu.notifications.subscription.SubscriptionHelper
import ani.dantotsu.notifications.subscription.SubscriptionHelper.Companion.saveSubscription
import ani.dantotsu.others.LanguageMapper
import ani.dantotsu.parsers.AnimeParser
import ani.dantotsu.parsers.AnimeSources
import ani.dantotsu.parsers.HAnimeSources
import ani.dantotsu.setBaseline
import ani.dantotsu.setNavigationTheme
import ani.dantotsu.toPx
import ani.dantotsu.settings.extensionprefs.AnimeSourcePreferencesFragment
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.snackString
import ani.dantotsu.toast
import ani.dantotsu.util.Logger
import ani.dantotsu.util.StoragePermissions.Companion.accessAlertDialog
import ani.dantotsu.util.StoragePermissions.Companion.hasDirAccess
import ani.dantotsu.util.customAlertDialog
import com.anggrayudi.storage.file.extension
import com.google.android.material.appbar.AppBarLayout
import eu.kanade.tachiyomi.animesource.ConfigurableAnimeSource
import eu.kanade.tachiyomi.extension.anime.model.AnimeExtension
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import tachiyomi.core.util.lang.launchIO
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

class AnimeWatchFragment : Fragment(), AnimeWatchAdapter.ScanlatorSelectionListener {
    private var _binding: FragmentMediaSourceBinding? = null
    private val binding get() = _binding!!
    private val model: MediaDetailsViewModel by activityViewModels()

    private lateinit var media: Media

    private var start = 0
    private var end: Int? = null
    private var style: Int? = null
    private var reverse = false

    private lateinit var headerAdapter: AnimeWatchAdapter
    private lateinit var episodeAdapter: EpisodeAdapter

    val downloadManager = Injekt.get<DownloadsManager>()

    var screenWidth = 0f
    private var progress = View.VISIBLE

    var continueEp: Boolean = false
    var loaded = false
    private var isReceiverRegistered = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMediaSourceBinding.inflate(inflater, container, false)
        return _binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupDownloadReceiver()
        val gridLayoutManager = setupRecyclerLayout()
        setupSwipeRefresh()
        setupScrollTop(gridLayoutManager)
        observeViewModel()
    }

    private fun setupDownloadReceiver() {
        val intentFilter = IntentFilter().apply {
            addAction(ACTION_DOWNLOAD_STARTED)
            addAction(ACTION_DOWNLOAD_FINISHED)
            addAction(ACTION_DOWNLOAD_FAILED)
            addAction(ACTION_DOWNLOAD_PROGRESS)
        }

        if (!isReceiverRegistered) {
            ContextCompat.registerReceiver(
                requireContext(),
                downloadStatusReceiver,
                intentFilter,
                ContextCompat.RECEIVER_EXPORTED
            )
            isReceiverRegistered = true
        }
    }

    private fun setupRecyclerLayout(): GridLayoutManager {
        binding.mediaSourceRecycler.updatePadding(bottom = binding.mediaSourceRecycler.paddingBottom + navBarHeight)
        screenWidth = resources.displayMetrics.widthPixels.dp

        var maxGridSize = (screenWidth / 100f).roundToInt()
        maxGridSize = max(4, maxGridSize - (maxGridSize % 2))

        val gridLayoutManager = GridLayoutManager(requireContext(), maxGridSize)
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                val style = episodeAdapter.getItemViewType(position)

                return when (position) {
                    0 -> maxGridSize
                    else -> when (style) {
                        0 -> maxGridSize
                        1 -> 2
                        2 -> 1
                        else -> maxGridSize
                    }
                }
            }
        }
        binding.mediaSourceRecycler.layoutManager = gridLayoutManager
        return gridLayoutManager
    }

    private fun setupSwipeRefresh() {
        binding.mediaSourceSwipeRefresh.apply {
            val primaryColor = PrefManager.getVal<Int>(PrefName.PrimaryColor)
            setColorSchemeColors(primaryColor)
            setProgressBackgroundColorSchemeResource(R.color.nav_bg)
            setOnRefreshListener {
                if (!this@AnimeWatchFragment::media.isInitialized) {
                    isRefreshing = false
                    return@setOnRefreshListener
                }
                loadMediaEpisodes(media, force = true)
            }
        }
    }

    private fun loadMediaEpisodes(media: Media, force: Boolean = false) {
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val ctx = context
            val offline = (ctx != null && !isOnline(ctx)) || PrefManager.getVal(PrefName.OfflineMode)
            val isLocal = model.watchSources?.list?.getOrNull(media.selected!!.sourceIndex)?.name == "Local"
            if (offline && !isLocal && !force) {
                media.selected!!.sourceIndex = model.watchSources!!.list.lastIndex
            } else if (!offline && !isLocal) {
                launch { model.loadKitsuEpisodes(media, force = force) }
                launch { model.loadAnifyEpisodes(media, force = force) }
                launch { model.loadFillerEpisodes(media, force = force) }
            }
            model.loadEpisodes(media, media.selected!!.sourceIndex, invalidate = force)
            if (force) {
                withContext(Dispatchers.Main) {
                    _binding?.mediaSourceSwipeRefresh?.isRefreshing = false
                }
            }
        }
    }

    private fun setupScrollTop(gridLayoutManager: GridLayoutManager) {
        binding.ScrollTop.setOnClickListener {
            binding.mediaSourceRecycler.scrollToPosition(10)
            binding.mediaSourceRecycler.smoothScrollToPosition(0)
        }
        binding.mediaSourceRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val position = gridLayoutManager.findFirstVisibleItemPosition()
                if (position > 2) {
                    binding.ScrollTop.translationY = -(navBarHeight + 12.toPx).toFloat()
                    binding.ScrollTop.visibility = View.VISIBLE
                } else {
                    binding.ScrollTop.visibility = View.GONE
                }
            }
        })
        model.scrolledToTop.observe(viewLifecycleOwner) {
            if (it) binding.mediaSourceRecycler.scrollToPosition(0)
        }
    }

    private fun observeViewModel() {
        continueEp = model.continueMedia ?: false
        model.getMedia().observe(viewLifecycleOwner) { initOrReloadMedia(it) }
        model.getEpisodes().observe(viewLifecycleOwner) { onEpisodesLoaded(it) }
        observeMetadataUpdate(model.getKitsuEpisodes()) { media.anime?.kitsuEpisodes = it }
        observeMetadataUpdate(model.getFillerEpisodes()) { media.anime?.fillerEpisodes = it }
        observeMetadataUpdate(model.getAnifyEpisodes()) { media.anime?.anifyEpisodes = it }
    }

    private fun <T> observeMetadataUpdate(
        liveData: LiveData<T>,
        applyData: (T) -> Unit
    ) {
        liveData.observe(viewLifecycleOwner) { data ->
            if (data != null) {
                applyData(data)
                if (loaded) {
                    loadEpisodes(media.selected!!.sourceIndex, false)
                }
            }
        }
    }

    private fun initOrReloadMedia(it: Media?) {
        if (it == null) return
        if (this::media.isInitialized) {
            if (it.anime != null && it.anime?.episodes == null) {
                it.anime?.episodes = media.anime?.episodes
            }
        }
        media = it
        media.selected = model.loadSelected(media)
        if (media.format == "LOCAL") {
            val localSourceIndex = AnimeSources.list.indexOfFirst { parser -> parser.name == "Local" }
                .takeIf { parserIndex -> parserIndex >= 0 } ?: 0
            media.selected!!.sourceIndex = localSourceIndex
        }

        subscribed = SubscriptionHelper.getSubscriptions().containsKey(media.id)
        style = media.selected!!.recyclerStyle
        reverse = media.selected!!.recyclerReversed

        progress = View.GONE
        binding.mediaInfoProgressBar.visibility = progress

        if (!loaded) {
            setupInitialMediaAdapters(it)
            loadMediaEpisodes(media, force = false)
            loaded = true
        } else {
            reload()
        }
    }

    private fun setupInitialMediaAdapters(mediaItem: Media) {
        model.watchSources = if (mediaItem.isAdult) HAnimeSources else AnimeSources
        val offlineMode = model.watchSources!!.isDownloadedSource(media.selected!!.sourceIndex)

        headerAdapter = AnimeWatchAdapter(mediaItem, this, model.watchSources!!)
        headerAdapter.scanlatorSelectionListener = this
        episodeAdapter = EpisodeAdapter(
            style ?: PrefManager.getVal(PrefName.AnimeDefaultView),
            mediaItem,
            this,
            offlineMode = offlineMode
        )

        binding.mediaSourceRecycler.adapter = ConcatAdapter(headerAdapter, episodeAdapter)
    }

    private fun onEpisodesLoaded(loadedEpisodes: Map<Int, Map<String, Episode>>?) {
        if (loadedEpisodes == null) return
        val episodes = loadedEpisodes[media.selected!!.sourceIndex] ?: return
        val currentSourceName = model.watchSources?.get(media.selected!!.sourceIndex)?.name ?: ""
        val isTorrentSource = currentSourceName.equals("Torrent", ignoreCase = true) ||
            episodes.values.any { it.extra?.containsKey("torrentHash") == true }

        val metadataPriority = PrefManager.getVal<Int>(PrefName.EpisodeMetadataSource)
        episodes.forEach { (i, episode) ->
            enrichEpisode(episode, i, isTorrentSource, metadataPriority)
        }
        media.anime?.episodes = episodes.toMutableMap()
        headerAdapter.options = getScanlators(episodes)
        if (headerAdapter.options.size > 1) {
            if (media.selected!!.scanlators != null) {
                headerAdapter.hiddenScanlators = media.selected!!.scanlators!!.toMutableList()
            }
        } else {
            headerAdapter.hiddenScanlators.clear()
        }
        updateEpisodes()
    }

    private fun enrichEpisode(
        episode: Episode,
        indexKey: String,
        isTorrentSource: Boolean,
        metadataPriority: Int
    ) {
        val epNum = episode.number
        if (!isTorrentSource) {
            applyFillerMetadata(episode, epNum)
            if (metadataPriority == 0) {
                applyAniZipMetadata(episode, epNum)
                applyKitsuMetadata(episode, epNum)
            } else {
                applyKitsuMetadata(episode, epNum)
                applyAniZipMetadata(episode, epNum)
            }
            episode.title = resolveEpisodeTitle(episode, indexKey, epNum)
        } else {
            if (episode.title.isNullOrBlank()) {
                episode.title = episode.sEpisode?.name ?: buildFallbackEpisodeTitle(indexKey, episode)
            }
        }
    }

    private fun resolveEpisodeTitle(episode: Episode, indexKey: String, epNum: String): String {
        val anifyTitle = cleanTitle((media.anime?.anifyEpisodes?.get(epNum) ?: media.anime?.anifyEpisodes?.getEpisode(epNum))?.title)
        val kitsuTitle = cleanTitle((media.anime?.kitsuEpisodes?.get(epNum) ?: media.anime?.kitsuEpisodes?.getEpisode(epNum))?.title)
        val jikanTitle = cleanTitle((media.anime?.fillerEpisodes?.get(epNum) ?: media.anime?.fillerEpisodes?.getEpisode(epNum))?.title)
        return anifyTitle ?: kitsuTitle ?: jikanTitle ?: buildFallbackEpisodeTitle(indexKey, episode)
    }

    private fun applyFillerMetadata(episode: Episode, epNum: String) {
        if (media.anime?.fillerEpisodes != null) {
            val fillerEp = media.anime!!.fillerEpisodes!![epNum]
                ?: media.anime!!.fillerEpisodes!!.getEpisode(epNum)
            if (fillerEp != null) {
                episode.filler = fillerEp.filler
                episode.date = fillerEp.date ?: episode.date
            }
        }
    }

    private fun applyKitsuMetadata(episode: Episode, epNum: String) {
        if (media.anime?.kitsuEpisodes != null) {
            val kitsuEp = media.anime!!.kitsuEpisodes!![epNum]
                ?: media.anime!!.kitsuEpisodes!!.getEpisode(epNum)
            if (kitsuEp != null) {
                episode.desc = kitsuEp.desc ?: episode.desc
                episode.thumb = kitsuEp.thumb ?: episode.thumb
            }
        }
    }

    private fun applyAniZipMetadata(episode: Episode, epNum: String) {
        if (media.anime?.anifyEpisodes != null) {
            val anifyEp = media.anime!!.anifyEpisodes!![epNum]
                ?: media.anime!!.anifyEpisodes!!.getEpisode(epNum)
            if (anifyEp != null) {
                episode.desc = anifyEp.desc ?: episode.desc
                episode.thumb = anifyEp.thumb ?: episode.thumb
                episode.rating = anifyEp.extra?.get("rating") ?: episode.rating
                val airDate = anifyEp.extra?.get("airDate")
                if (!airDate.isNullOrBlank()) {
                    episode.date = airDate.substringBefore("T")
                }
            }
        }
    }

    private fun cleanTitle(value: String?): String? = value?.trim()?.takeIf { it.isNotEmpty() }
    private fun buildFallbackEpisodeTitle(index: String, currentEpisode: Episode): String {
        val parsedNumber = MediaNameAdapter.findEpisodeNumber(currentEpisode.number)
            ?: MediaNameAdapter.findEpisodeNumber(index)
            ?: currentEpisode.number
        return "Episode $parsedNumber"
    }

    override fun onScanlatorsSelected() {
        updateEpisodes()
    }

    fun onScanlatorChange(list: List<String>) {
        val selected = model.loadSelected(media)
        selected.scanlators = list
        model.saveSelected(media.id, selected)
        media.selected = selected
    }

    private fun getScanlators(epMap: Map<String, Episode>?): List<String> {
        if (epMap == null) return emptyList()
        val nonSeasonRegex = Regex("^(sub|dub|raw|unknown|default|subbed|dubbed|s-sub|softsub)$", RegexOption.IGNORE_CASE)
        val scanlators = mutableListOf<String>()
        for (episode in epMap.values) {
            val scan = episode.sEpisode?.scanlator?.trim()
            if (!scan.isNullOrBlank() && !nonSeasonRegex.matches(scan)) {
                scanlators.add(scan)
            }
        }
        return scanlators.distinct()
    }

    private fun updateEpisodes() {
        val loadedEpisodes = model.getEpisodes().value ?: return
        val episodes = loadedEpisodes[media.selected!!.sourceIndex] ?: return
        val filteredEpisodes = filterHiddenScanlators(episodes)
        media.anime?.episodes = filteredEpisodes.toMutableMap()
        setupEpisodePagination(filteredEpisodes)
        headerAdapter.subscribeButton(true)
        reload()
    }

    private fun filterHiddenScanlators(episodes: Map<String, Episode>): Map<String, Episode> {
        return if (headerAdapter.options.size > 1 && headerAdapter.hiddenScanlators.isNotEmpty()) {
            episodes.filterNot { (_, episode) ->
                (episode.sEpisode?.scanlator ?: "Unknown") in headerAdapter.hiddenScanlators
            }
        } else {
            episodes
        }
    }

    private fun setupEpisodePagination(filteredEpisodes: Map<String, Episode>) {
        val total = filteredEpisodes.size
        val divisions = total.toDouble() / 10
        start = 0
        end = null
        val limit = when {
            divisions < 25 -> 25
            divisions < 50 -> 50
            else -> 100
        }
        headerAdapter.clearChips()
        if (total > limit) {
            val arr = filteredEpisodes.keys.toTypedArray()
            val stored = ceil(total.toDouble() / limit).toInt()
            val position = calculateSelectedChipPosition(filteredEpisodes, arr, limit, stored)
            val last = if (position + 1 == stored) total else limit * (position + 1)
            start = limit * position
            end = last - 1
            headerAdapter.updateChips(
                limit,
                arr,
                (1..stored).toList().toTypedArray(),
                position
            )
        }
    }

    private fun hasActiveProgress(appEpKey: String?): Boolean {
        if (appEpKey == null) return false
        val cleanNum = MediaNameAdapter.findEpisodeNumber(appEpKey)?.let {
            if (it % 1 == 0f) it.toInt().toString() else it.toString()
        }
        val curr = PrefManager.getNullableCustomVal("${media.id}_${appEpKey}", null, Long::class.java)
            ?: cleanNum?.let { PrefManager.getNullableCustomVal("${media.id}_${it}", null, Long::class.java) }
        val max = PrefManager.getNullableCustomVal("${media.id}_${appEpKey}_max", null, Long::class.java)
            ?: cleanNum?.let { PrefManager.getNullableCustomVal("${media.id}_${it}_max", null, Long::class.java) }
        return if (curr != null && max != null && max > 0L) {
            curr.toFloat() / max.toFloat() < PrefManager.getVal<Float>(PrefName.WatchPercentage)
        } else false
    }

    private fun findTargetEpisodeIndex(
        filteredEpisodes: Map<String, Episode>,
        arr: Array<String>,
        targetEpNum: Float
    ): Int {
        var targetIndex = arr.indexOfFirst { key ->
            val epObj = filteredEpisodes[key]
            MediaNameAdapter.findEpisodeNumber(key) == targetEpNum ||
            (epObj?.number != null && MediaNameAdapter.findEpisodeNumber(epObj.number) == targetEpNum)
        }
        if (targetIndex == -1) {
            val targetIdx = targetEpNum.toInt() - 1
            if (targetIdx in arr.indices) {
                targetIndex = targetIdx
            }
        }
        return targetIndex
    }

    private fun calculateSelectedChipPosition(
        filteredEpisodes: Map<String, Episode>,
        arr: Array<String>,
        limit: Int,
        stored: Int
    ): Int {
        val anilistEp = (media.userProgress ?: 0).plus(1)
        val appEp = PrefManager.getCustomVal<String?>(
            "${media.id}_current_ep", ""
        )?.let { MediaNameAdapter.findEpisodeNumber(it)?.toInt() ?: it.toIntOrNull() } ?: 1
        val appEpKey = arr.find { key ->
            val epObj = filteredEpisodes[key]
            MediaNameAdapter.findEpisodeNumber(key)?.toInt() == appEp ||
            (epObj?.number != null && MediaNameAdapter.findEpisodeNumber(epObj.number)?.toInt() == appEp)
        } ?: arr.getOrNull(appEp - 1)

        val targetEpNum = if (anilistEp > appEp && !hasActiveProgress(appEpKey)) anilistEp.toFloat() else appEp.toFloat()
        val targetIndex = findTargetEpisodeIndex(filteredEpisodes, arr, targetEpNum)
        val targetChip = if (targetIndex >= 0) (targetIndex / limit).coerceIn(0, stored - 1) else 0

        return if (media.selected!!.chip == 0 && targetChip > 0) {
            media.selected!!.chip = targetChip
            targetChip
        } else {
            MathUtils.clamp(media.selected!!.chip, 0, stored - 1)
        }
    }

    //implement Multi download
    fun multiDownload(episodeNumber: String? = null, n: Int) {
        val selected = media.userProgress
        val episodes = media.anime?.episodes?.values?.toList()

        val progressEpisodeIndex =
            if (episodeNumber == null) {
                (episodes?.indexOfFirst {
                    MediaNameAdapter.findEpisodeNumber(it.number)?.toInt() == selected
                } ?: 0) + 1
            } else {
                episodes?.indexOfFirst {
                    it.number == episodeNumber
                } ?: 0
            }

        if (progressEpisodeIndex < 0 || n < 1 || episodes == null) return

        val endIndex = minOf(progressEpisodeIndex + n, episodes.size)

        val listOfEpisodesToDownload = episodes.subList(progressEpisodeIndex, endIndex)

        val episodesToDownload: ArrayList<String> = arrayListOf()
        listOfEpisodesToDownload.forEach {
            episodesToDownload.add(it.number)
        }

        onAnimeEpisodesDownload(episodesToDownload)
    }

    fun multiDelete(episodeNumber: String? = null, n: Int){
        val episodes = media.anime?.episodes?.values?.toList()
        val progressEpisodeIndex = episodes?.indexOfFirst { it.number == episodeNumber } ?: 0

        if (progressEpisodeIndex < 0 || n < 1 || episodes == null) return

        val endIndex = minOf(progressEpisodeIndex + n, episodes.size)

        val episodesToDelete = episodes.subList(progressEpisodeIndex, endIndex)

        for (episode in episodesToDelete) {
            onAnimeEpisodeRemoveDownloadClick(episode.number)
        }
    }

    fun onSourceChange(i: Int): AnimeParser {
        media.anime?.episodes = null
        reload()
        val selected = model.loadSelected(media)
        model.watchSources?.get(selected.sourceIndex)?.showUserTextListener = null
        selected.sourceIndex = i
        selected.server = null
        selected.scanlators = null
        model.saveSelected(media.id, selected)
        media.selected = selected
        return model.watchSources?.get(i)!!
    }

    fun onLangChange(i: Int) {
        val selected = model.loadSelected(media)
        selected.langIndex = i
        model.saveSelected(media.id, selected)
        media.selected = selected
    }

    fun onDubClicked(checked: Boolean) {
        val selected = model.loadSelected(media)
        model.watchSources?.get(selected.sourceIndex)?.selectDub = checked
        selected.preferDub = checked
        model.saveSelected(media.id, selected)
        media.selected = selected
        lifecycleScope.launch(Dispatchers.IO) {
            model.forceLoadEpisode(
                media,
                selected.sourceIndex
            )
        }
    }

    fun loadEpisodes(i: Int, invalidate: Boolean) {
        lifecycleScope.launch(Dispatchers.IO) { model.loadEpisodes(media, i, invalidate) }
    }

    fun loadKitsuEpisodesAsync() {
        lifecycleScope.launch(Dispatchers.IO) { model.loadKitsuEpisodes(media) }
    }

    fun onIconPressed(viewType: Int, rev: Boolean) {
        style = viewType
        reverse = rev
        media.selected!!.recyclerStyle = style
        media.selected!!.recyclerReversed = reverse
        model.saveSelected(media.id, media.selected!!)
        reload()
    }

    fun onChipClicked(i: Int, s: Int, e: Int) {
        media.selected!!.chip = i
        start = s
        end = e
        model.saveSelected(media.id, media.selected!!)
        reload()
    }

    var subscribed = false
    fun onNotificationPressed(subscribed: Boolean, source: String) {
        this.subscribed = subscribed
        saveSubscription(media, subscribed)
        snackString(
            if (subscribed) getString(R.string.subscribed_notification, source)
            else getString(R.string.unsubscribed_notification)
        )
    }

    fun openSettings(pkg: AnimeExtension.Installed) {
        val changeUIVisibility: (Boolean) -> Unit = { show ->
            val activity = activity
            if (activity is MediaDetailsActivity && isAdded) {
                activity.findViewById<AppBarLayout>(R.id.mediaAppBar).isVisible = show
                activity.findViewById<ViewPager2>(R.id.mediaViewPager).isVisible = show
                activity.findViewById<CardView>(R.id.mediaCover).isVisible = show
                activity.findViewById<CardView>(R.id.mediaClose).isVisible = show
                activity.navBar.isVisible = show
                activity.findViewById<FrameLayout>(R.id.fragmentExtensionsContainer).isGone = show
            }
        }
        var itemSelected = false
        val allSettings = pkg.sources.filterIsInstance<ConfigurableAnimeSource>()
        if (allSettings.isNotEmpty()) {
            var selectedSetting = allSettings[0]
            if (allSettings.size > 1) {
                val names =
                    allSettings.map { LanguageMapper.getLanguageName(it.lang) }.toTypedArray()
                requireContext()
                    .customAlertDialog()
                    .apply {
                        setTitle("Select a Source")
                        singleChoiceItems(names) { which ->
                            selectedSetting = allSettings[which]
                            itemSelected = true
                            requireActivity().runOnUiThread {
                                val fragment =
                                    AnimeSourcePreferencesFragment().getInstance(selectedSetting.id) {
                                        changeUIVisibility(true)
                                        loadEpisodes(media.selected!!.sourceIndex, true)
                                    }
                                parentFragmentManager.beginTransaction()
                                    .setCustomAnimations(R.anim.slide_up, R.anim.slide_down)
                                    .replace(R.id.fragmentExtensionsContainer, fragment)
                                    .addToBackStack(null)
                                    .commit()
                            }
                        }
                        onDismiss {
                            if (!itemSelected) {
                                changeUIVisibility(true)
                            }
                        }
                        show()
                    }
            } else {
                // If there's only one setting, proceed with the fragment transaction
                requireActivity().runOnUiThread {
                    val fragment =
                        AnimeSourcePreferencesFragment().getInstance(selectedSetting.id) {
                            changeUIVisibility(true)
                            loadEpisodes(media.selected!!.sourceIndex, true)
                        }
                    parentFragmentManager.beginTransaction().apply {
                        setCustomAnimations(R.anim.slide_up, R.anim.slide_down)
                        replace(R.id.fragmentExtensionsContainer, fragment)
                        addToBackStack(null)
                        commit()
                    }
                }
            }

            changeUIVisibility(false)
        } else {
            Toast.makeText(requireContext(), "Source is not configurable", Toast.LENGTH_SHORT)
                .show()
        }
    }

    fun onEpisodeClick(i: String) {
        model.continueMedia = false
        model.saveSelected(media.id, media.selected!!)
        model.onEpisodeClick(media, i, requireActivity().supportFragmentManager)
    }

    fun openDirectTorrent() {
        val clipboard = ContextCompat.getSystemService(requireContext(), android.content.ClipboardManager::class.java)
        val clipText = clipboard?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()?.trim()
        val clipTorrentUrl = if (clipText != null && (
                clipText.startsWith("magnet:?xt=", ignoreCase = true) ||
                clipText.endsWith(".torrent", ignoreCase = true) ||
                (clipText.startsWith("http", ignoreCase = true) && clipText.contains(".torrent", ignoreCase = true))
            )) {
            clipText
        } else null

        // If no clipboard torrent, check if one is already saved for this media (shows info on re-click)
        val savedUrl = PrefManager.getNullableCustomVal("${media.id}_torrent_url", null, String::class.java)
            ?.takeIf { it.isNotBlank() }

        // Prefer clipboard URL (allows replacing torrent), fall back to saved URL (shows existing torrent info)
        val torrentUrl = clipTorrentUrl ?: savedUrl

        val sheet = ani.dantotsu.torrent.DirectTorrentBottomSheet.newInstanceLinked(media, torrentUrl)
        sheet.onTorrentSelected = { chosenUrl ->
            PrefManager.setCustomVal("${media.id}_torrent_url", chosenUrl)
            val torrentIndex = model.watchSources?.names?.indexOf("Torrent") ?: -1
            if (torrentIndex != -1) {
                val torrentParser = model.watchSources?.get(torrentIndex)
                val title = media.userPreferredName.ifBlank { media.mainName() }
                val sAnime = eu.kanade.tachiyomi.animesource.model.SAnime.create().apply {
                    this.title = title
                    this.url = chosenUrl
                }
                val showResponse = ani.dantotsu.parsers.ShowResponse(
                    name = title,
                    link = chosenUrl,
                    coverUrl = ani.dantotsu.FileUrl(media.cover ?: media.banner ?: ""),
                    sAnime = sAnime
                )
                torrentParser?.saveShowResponse(media.id, showResponse, true)

                media.selected!!.scanlators = null
                media.selected!!.sourceIndex = torrentIndex
                model.saveSelected(media.id, media.selected!!)
                model.invalidateSource(torrentIndex)
                headerAdapter.hiddenScanlators.clear()
                headerAdapter.options = emptyList()
                onSourceChange(torrentIndex)
                headerAdapter.updateSelectedSource(torrentIndex)
                lifecycleScope.launch(Dispatchers.IO) {
                    model.overrideEpisodes(torrentIndex, showResponse, media.id)
                }
                toast(getString(R.string.play_via_torrent_magnet))
            }
        }
        sheet.show(parentFragmentManager, "DirectTorrentBottomSheet")
    }

    fun onAnimeEpisodesDownload(episodesToDownload: ArrayList<String>) {
        if (PrefManager.getVal<Boolean>(PrefName.DownloadWifiOnly) && !ani.dantotsu.isWifiConnected(requireContext())) {
            snackString(getString(R.string.download_wifi_only_warning))
            return
        }
        activity?.let {
            if (!hasDirAccess(it)) {
                (it as MediaDetailsActivity).accessAlertDialog(it.launcher) { success ->
                    if (success) {
                        model.onEpisodeClick(
                            media =  media,
                            manager =  requireActivity().supportFragmentManager,
                            isDownload = true,
                            episodes = episodesToDownload
                        )
                    } else {
                        snackString(getString(R.string.download_permission_required))
                    }
                }
            } else {
                model.onEpisodeClick(
                    media =  media,
                    manager =  requireActivity().supportFragmentManager,
                    isDownload = true,
                    episodes = episodesToDownload
                )
            }
        }
    }

    fun onAnimeEpisodeStopDownloadClick(i: String) {
        // Idle UI immediately (not "Failed"); ignore late progress broadcasts
        AnimeDownloader.stopDownload(media.id, i)
        episodeAdapter.clearDownloadState(i)

        val cancelIntent = Intent().apply {
            action = AnimeDownloaderService.ACTION_CANCEL_DOWNLOAD
            putExtra(
                AnimeDownloaderService.EXTRA_TASK_NAME,
                AnimeDownloaderService.AnimeDownloadTask.getTaskName(media.mainName(), i)
            )
        }
        requireContext().sendBroadcast(cancelIntent)

        // Remove partial files from the manager
        downloadManager.removeDownload(
            DownloadedType(
                media.mainName(),
                i,
                MediaType.ANIME
            )
        ) {}
    }

    @OptIn(UnstableApi::class)
    fun onAnimeEpisodeRemoveDownloadClick(i: String) {
        downloadManager.removeDownload(
            DownloadedType(
                media.mainName(),
                i,
                MediaType.ANIME
            )
        ) {
            val taskName = AnimeDownloaderService.AnimeDownloadTask.getTaskName(media.mainName(), i)
            PrefManager.getAnimeDownloadPreferences().edit().remove(taskName).apply()
            episodeAdapter.deleteDownload(i)
            val isDownloaded = model.watchSources?.isDownloadedSource(media.selected?.sourceIndex ?: 0) == true
            if (isDownloaded) {
                model.invalidateSource(media.selected?.sourceIndex ?: 0)
                loadEpisodes(media.selected?.sourceIndex ?: 0, true)
            }
        }
    }

    @kotlin.OptIn(DelicateCoroutinesApi::class)
    fun fixDownload(i: String) {
        toast(R.string.running_fixes)
        launchIO {
            try {
                val context = context ?: throw Exception("Context is null")
                val directory =
                    getSubDirectory(context, MediaType.ANIME, false, media.mainName(), i)
                        ?: throw Exception("Directory is null")
                val files = directory.listFiles()
                val videoFiles = files.filter { it.extension == "mp4" || it.extension == "mkv" }
                if (videoFiles.size != 1) {
                    val biggest =
                        videoFiles.filter { it.length() > 1000 }.maxByOrNull { it.length() }
                            ?: throw Exception("No video files found")
                    val newName =
                        AnimeDownloaderService.AnimeDownloadTask.getTaskName(media.mainName(), i)
                            .findValidName() + "." + biggest.extension
                    videoFiles.forEach {
                        if (it != biggest) {
                            it.delete()
                        }
                    }
                    if (newName != biggest.name) {
                        biggest.renameTo(newName)
                    }
                    toast(context.getString(R.string.success) + " (1)")
                } else {
                    val ffExtension = Injekt.get<DownloadAddonManager>().extension?.extension!!
                    val extension = ffExtension.getFileExtension()
                    val tempFile =
                        directory.createFile(extension.second, "temp.${extension.first}")
                            ?: throw Exception("Temp file is null")
                    val tempPath = ffExtension.setDownloadPath(
                        context,
                        tempFile.uri
                    )
                    val videoPath = ffExtension.getReadPath(
                        context,
                        videoFiles[0].uri
                    )

                    val id = ffExtension.customFFMpeg(
                        "1", listOf(videoPath, tempPath)
                    ) { log ->
                        Logger.log(log)
                    }
                    val timeOut = System.currentTimeMillis() + 1000 * 60 * 10
                    while (ffExtension.getState(id) != "COMPLETED") {
                        if (ffExtension.getState(id) == "FAILED") {
                            Logger.log("Failed to fix download")
                            ffExtension.getStackTrace(id)?.let {
                                Logger.log(it)
                            }
                            toast(R.string.failed_to_fix)
                            return@launchIO
                        }
                        if (System.currentTimeMillis() > timeOut) {
                            Logger.log("Failed to fix download: Timeout")
                            toast(R.string.failed_to_fix)
                            return@launchIO
                        }
                    }
                    if (ffExtension.hadError(id)) {
                        Logger.log("Failed to fix download: ${ffExtension.getStackTrace(id)}")
                        toast(R.string.failed_to_fix)
                        return@launchIO
                    }
                    val name = videoFiles[0].name
                    if (videoFiles[0].delete().not()) {
                        toast(R.string.delete_fail)
                        return@launchIO
                    }
                    tempFile.renameTo(name!!)
                    toast(context.getString(R.string.success) + " (2)")
                }
            } catch (e: Exception) {
                toast(getString(R.string.error_msg, e.message))
                Logger.log(e)
            }
        }
    }

    private val downloadStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!this@AnimeWatchFragment::episodeAdapter.isInitialized) return
            when (intent.action) {
                ACTION_DOWNLOAD_STARTED -> {
                    val chapterNumber = intent.getStringExtra(EXTRA_EPISODE_NUMBER)
                    val mediaId = intent.getIntExtra("mediaId", -1)
                    if (mediaId != media.id) return
                    chapterNumber?.let { episodeAdapter.startDownload(it) }
                }

                ACTION_DOWNLOAD_FINISHED -> {
                    val chapterNumber = intent.getStringExtra(EXTRA_EPISODE_NUMBER)
                    val mediaId = intent.getIntExtra("mediaId", -1)
                    val size = intent.getDoubleExtra("size", 0.0)
                    if (mediaId != media.id) return
                    chapterNumber?.let { episodeAdapter.addToDownloadedEpisodes(it, size) }
                }

                ACTION_DOWNLOAD_FAILED -> {
                    val chapterNumber = intent.getStringExtra(EXTRA_EPISODE_NUMBER)
                    val mediaId = intent.getIntExtra("mediaId", -1)
                    if (mediaId != media.id) return
                    chapterNumber?.let {
                        episodeAdapter.purgeDownload(it)
                    }
                }

                ACTION_DOWNLOAD_PROGRESS -> {
                    val chapterNumber = intent.getStringExtra(EXTRA_EPISODE_NUMBER)
                    val progress = intent.getIntExtra("progress", 0)
                    val mediaId = intent.getIntExtra("mediaId", -1)
                    val downloadedBytes = intent.getLongExtra(EXTRA_DOWNLOADED_BYTES, -1L)
                    val estimatedTotalBytes = intent.getLongExtra(EXTRA_ESTIMATED_TOTAL_BYTES, -1L)
                    if (mediaId != media.id) return
                    chapterNumber?.let {
                        episodeAdapter.updateDownloadProgress(
                            it,
                            progress,
                            downloadedBytes,
                            estimatedTotalBytes
                        )
                    }
                }
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun reload() {
        val selected = model.loadSelected(media)

        // Find latest episode for subscription
        selected.latest =
            media.anime?.episodes?.values?.maxOfOrNull { it.number.toFloatOrNull() ?: 0f } ?: 0f
        selected.latest =
            media.userProgress?.toFloat()?.takeIf { selected.latest < it } ?: selected.latest

        model.saveSelected(media.id, selected)
        headerAdapter.handleEpisodes()
        val isDownloaded = model.watchSources!!.isDownloadedSource(media.selected!!.sourceIndex)
        episodeAdapter.offlineMode = isDownloaded
        episodeAdapter.notifyItemRangeRemoved(0, episodeAdapter.arr.size)
        var arr: ArrayList<Episode> = arrayListOf()
        if (media.anime!!.episodes != null) {
            val end = if (end != null && end!! < media.anime!!.episodes!!.size) end else null
            arr.addAll(
                media.anime!!.episodes!!.values.toList()
                    .slice(start..(end ?: (media.anime!!.episodes!!.size - 1)))
            )
            if (reverse)
                arr = arr.reversed() as? ArrayList<Episode> ?: ArrayList(arr.reversed())
        }
        episodeAdapter.arr = arr
        episodeAdapter.updateType(style ?: PrefManager.getVal(PrefName.AnimeDefaultView))
        episodeAdapter.notifyItemRangeInserted(0, arr.size)
        episodeAdapter.clearAllDownloaded()
        for (download in downloadManager.animeDownloadedTypes) {
            if (media.compareName(download.titleName)) {
                episodeAdapter.addToDownloadedEpisodes(download.chapterName, downloadManager.getSize(download))
            }
        }
    }

    override fun onDestroyView() {
        if (isReceiverRegistered) {
            try {
                context?.unregisterReceiver(downloadStatusReceiver)
            } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        if (::headerAdapter.isInitialized) {
            headerAdapter.clearBinding()
        }
        super.onDestroyView()
        _binding?.mediaSourceRecycler?.adapter = null
        _binding = null
    }

    override fun onDestroy() {
        model.watchSources?.flushText()
        if (isReceiverRegistered) {
            try {
                context?.unregisterReceiver(downloadStatusReceiver)
            } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        super.onDestroy()
    }

    var state: Parcelable? = null
    override fun onResume() {
        super.onResume()
        binding.mediaInfoProgressBar.visibility = progress
        binding.mediaSourceRecycler.layoutManager?.onRestoreInstanceState(state)

        requireActivity().setNavigationTheme()

        if (this::media.isInitialized && this::headerAdapter.isInitialized) {
            val isCurrentlySubscribed = SubscriptionHelper.getSubscriptions().containsKey(media.id)
            if (subscribed != isCurrentlySubscribed) {
                subscribed = isCurrentlySubscribed
                headerAdapter.subscribe?.setState(isCurrentlySubscribed)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        state = binding.mediaSourceRecycler.layoutManager?.onSaveInstanceState()
    }

    companion object {
        const val ACTION_DOWNLOAD_STARTED = "ani.dantotsu.ACTION_DOWNLOAD_STARTED"
        const val ACTION_DOWNLOAD_FINISHED = "ani.dantotsu.ACTION_DOWNLOAD_FINISHED"
        const val ACTION_DOWNLOAD_FAILED = "ani.dantotsu.ACTION_DOWNLOAD_FAILED"
        const val ACTION_DOWNLOAD_PROGRESS = "ani.dantotsu.ACTION_DOWNLOAD_PROGRESS"
        const val EXTRA_EPISODE_NUMBER = "extra_episode_number"
        const val EXTRA_DOWNLOADED_BYTES = "extra_downloaded_bytes"
        const val EXTRA_ESTIMATED_TOTAL_BYTES = "extra_estimated_total_bytes"
    }

}
