package ani.dantotsu.media.comments

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import ani.dantotsu.R
import ani.dantotsu.connections.comments.Comment
import ani.dantotsu.connections.comments.CommentsAPI
import ani.dantotsu.copyToClipboard
import ani.dantotsu.databinding.ItemCommentsBinding
import ani.dantotsu.getAppString
import ani.dantotsu.getThemeColor
import ani.dantotsu.loadImage
import ani.dantotsu.openImage
import ani.dantotsu.profile.ProfileActivity
import ani.dantotsu.setAnimation
import ani.dantotsu.snackString
import ani.dantotsu.util.ColorEditor.Companion.adjustColorForContrast
import ani.dantotsu.util.ColorEditor.Companion.getContrastRatio
import ani.dantotsu.util.customAlertDialog
import com.xwray.groupie.GroupieAdapter
import com.xwray.groupie.Section
import com.xwray.groupie.viewbinding.BindableItem
import io.noties.markwon.Markwon
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.sqrt

class CommentItem(
    val comment: Comment,
    private val markwon: Markwon,
    val parentSection: Section,
    private val commentsFragment: CommentsFragment,
    private val backgroundColor: Int,
    val commentDepth: Int
) :
    BindableItem<ItemCommentsBinding>() {
    lateinit var binding: ItemCommentsBinding
    val adapter = GroupieAdapter()
    private var subCommentIds: MutableList<Int> = mutableListOf()
    val repliesSection = Section()
    private var isEditing = false
    var isReplying = false
    var repliesVisible = false
    var MAX_DEPTH = 3

    init {
        adapter.add(repliesSection)
    }

    fun updateRepliesVisibility(visible: Boolean) {
        repliesVisible = visible
        if (::binding.isInitialized) {
            if ((comment.replyCount ?: 0) > 0 || repliesVisible) {
                binding.commentTotalReplies.visibility = View.VISIBLE
                binding.commentRepliesDivider.visibility = View.VISIBLE
            }
            if (visible) {
                binding.commentTotalReplies.setText(R.string.hide_replies)
            } else {
                val replyCount = comment.replyCount ?: 1
                binding.commentTotalReplies.text = if (replyCount == 1)
                    binding.commentTotalReplies.context.getString(R.string.view_reply)
                else
                    binding.commentTotalReplies.context.getString(R.string.view_replies_count, replyCount)
            }
        }
    }

    private fun bindUserTag(viewBinding: ItemCommentsBinding) {
        if (comment.tag == null) {
            viewBinding.commentUserTagLayout.visibility = View.GONE
        } else {
            viewBinding.commentUserTagLayout.visibility = View.VISIBLE
            viewBinding.commentUserTag.text = comment.tag.toString()
            viewBinding.commentUserTagLayout.setOnClickListener {
                commentsFragment.onTagClicked(comment.tag.toString())
            }
        }
    }

    private fun getReplyButtonText(context: Context, forceHide: Boolean = repliesVisible): String {
        if (forceHide) return context.getString(R.string.hide_replies)
        val replyCount = comment.replyCount ?: 1
        return if (replyCount == 1) {
            context.getString(R.string.view_reply)
        } else {
            context.getString(R.string.view_replies_count, replyCount)
        }
    }

    private fun bindRepliesSection(viewBinding: ItemCommentsBinding, item: CommentItem) {
        val hasReplies = (comment.replyCount ?: 0) > 0 || repliesVisible
        viewBinding.commentTotalReplies.visibility = if (hasReplies) View.VISIBLE else View.GONE
        viewBinding.commentRepliesDivider.visibility = if (hasReplies) View.VISIBLE else View.GONE
        if (hasReplies) {
            viewBinding.commentTotalReplies.text = getReplyButtonText(viewBinding.commentTotalReplies.context)
        }
        viewBinding.commentReply.visibility = View.VISIBLE
        viewBinding.commentTotalReplies.setOnClickListener {
            if (repliesVisible) {
                repliesSection.clear()
                removeSubCommentIds()
                viewBinding.commentTotalReplies.text = getReplyButtonText(viewBinding.commentTotalReplies.context, forceHide = false)
                repliesVisible = false
            } else {
                viewBinding.commentTotalReplies.setText(R.string.hide_replies)
                repliesSection.clear()
                commentsFragment.viewReplyCallback(item)
                repliesVisible = true
            }
        }
    }

    private fun bindProfileNavigation(viewBinding: ItemCommentsBinding) {
        val openProfile = {
            ContextCompat.startActivity(
                commentsFragment.activity,
                Intent(commentsFragment.activity, ProfileActivity::class.java)
                    .putExtra("userId", comment.userId.toInt()),
                null
            )
        }
        viewBinding.commentUserName.setOnClickListener { openProfile() }
        viewBinding.commentUserAvatar.setOnClickListener { openProfile() }
    }

    private fun bindInteractionButtons(viewBinding: ItemCommentsBinding, item: CommentItem) {
        viewBinding.commentText.setOnLongClickListener {
            copyToClipboard(comment.content)
            true
        }
        viewBinding.commentEdit.setOnClickListener {
            editing(!isEditing)
            commentsFragment.editCallback(item)
        }
        viewBinding.commentReply.setOnClickListener {
            replying(!isReplying)
            commentsFragment.replyTo(item, comment.username)
            commentsFragment.replyCallback(item)
        }
    }

    private fun bindUserDetails(viewBinding: ItemCommentsBinding, levelColor: Pair<Int, Int>) {
        viewBinding.commentTotalVotes.text = (comment.upvotes - comment.downvotes).toString()
        viewBinding.commentUserAvatar.openImage(
            commentsFragment.activity.getString(R.string.avatar, comment.username),
            comment.profilePictureUrl ?: ""
        )
        comment.profilePictureUrl?.let { viewBinding.commentUserAvatar.loadImage(it) }
        viewBinding.commentUserName.text = comment.username
        val userColor = "[${levelColor.second}]"
        viewBinding.commentUserLevel.text = userColor
        viewBinding.commentUserLevel.setTextColor(levelColor.first)
        viewBinding.commentUserTime.text = formatTimestamp(comment.timestamp)
    }

    override fun bind(viewBinding: ItemCommentsBinding, position: Int) {
        binding = viewBinding
        setAnimation(binding.root.context, binding.root)
        val item = this
        viewBinding.apply {
            commentRepliesList.layoutManager =
                LinearLayoutManager(commentsFragment.activity)
            commentRepliesList.adapter = adapter
            val isUserComment = CommentsAPI.userId == comment.userId
            val levelColor = getAvatarColor(comment.totalVotes, backgroundColor)
            markwon.setMarkdown(commentText, comment.content)
            applyTimestampHighlighting(commentText)
            commentEdit.visibility = if (isUserComment) View.VISIBLE else View.GONE
            bindUserTag(viewBinding)
            replying(isReplying) //sets default text
            editing(isEditing)
            bindRepliesSection(viewBinding, item)
            bindProfileNavigation(viewBinding)
            bindInteractionButtons(viewBinding, item)
            modBadge.visibility = if (comment.isMod == true) View.VISIBLE else View.GONE
            adminBadge.visibility =
                if (comment.isAdmin == true) View.VISIBLE else View.GONE
            setupCommentActionsMenu(this, isUserComment)
            //fill the icon if the user has liked the comment
            setVoteButtons(viewBinding)
            setupVoteClickListeners(this)
            bindUserDetails(viewBinding, levelColor)
        }
    }

    override fun getLayout(): Int {
        return R.layout.item_comments
    }

    fun showReplies() {
        if (!repliesVisible) {
            repliesVisible = true
            if (::binding.isInitialized) {
                binding.commentTotalReplies.setText(R.string.hide_replies)
            }
            repliesSection.clear()
            commentsFragment.viewReplyCallback(this)
        }
    }

    fun containsGif(): Boolean {
        return comment.content.contains(".gif")
    }

    override fun initializeViewBinding(view: View): ItemCommentsBinding {
        return ItemCommentsBinding.bind(view)
    }

    fun replying(isReplying: Boolean) {
        binding.commentReply.text =
            if (isReplying) commentsFragment.activity.getString(R.string.cancel) else "Reply"
        this.isReplying = isReplying
    }

    fun editing(isEditing: Boolean) {
        binding.commentEdit.text =
            if (isEditing) commentsFragment.activity.getString(R.string.cancel) else commentsFragment.activity.getString(
                R.string.edit
            )
        this.isEditing = isEditing
    }

    fun registerSubComment(id: Int) {
        subCommentIds.add(id)
    }

    private fun removeSubCommentIds() {
        subCommentIds.forEach { id ->
            @Suppress("UNCHECKED_CAST")
            val parentComments = parentSection.groups as? List<CommentItem> ?: emptyList()
            val commentToRemove = parentComments.find { it.comment.commentId == id }
            commentToRemove?.let {
                it.removeSubCommentIds()
                parentSection.remove(it)
            }
        }
        subCommentIds.clear()
    }

    private fun setVoteButtons(viewBinding: ItemCommentsBinding) {
        when (comment.userVoteType) {
            1 -> {
                viewBinding.commentUpVote.setImageResource(R.drawable.ic_round_upvote_active_24)
                viewBinding.commentUpVote.alpha = 1f
                viewBinding.commentDownVote.setImageResource(R.drawable.ic_round_upvote_inactive_24)
            }

            -1 -> {
                viewBinding.commentUpVote.setImageResource(R.drawable.ic_round_upvote_inactive_24)
                viewBinding.commentDownVote.setImageResource(R.drawable.ic_round_upvote_active_24)
                viewBinding.commentDownVote.alpha = 1f
            }

            else -> {
                viewBinding.commentUpVote.setImageResource(R.drawable.ic_round_upvote_inactive_24)
                viewBinding.commentDownVote.setImageResource(R.drawable.ic_round_upvote_inactive_24)
            }
        }
    }

    @SuppressLint("SimpleDateFormat")
    private fun formatTimestamp(timestamp: String): String {
        return try {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ROOT)
            dateFormat.timeZone = TimeZone.getTimeZone("UTC")
            val parsedDate = dateFormat.parse(timestamp)
            val currentDate = Date()

            val diff = currentDate.time - (parsedDate?.time ?: 0)

            val days = diff / (24 * 60 * 60 * 1000)
            val hours = diff / (60 * 60 * 1000) % 24
            val minutes = diff / (60 * 1000) % 60

            return when {
                days > 0 -> "${days}d"
                hours > 0 -> "${hours}h"
                minutes > 0 -> "${minutes}m"
                else -> "now"
            }
        } catch (e: Exception) {
            "now"
        }
    }

    companion object {
        @SuppressLint("SimpleDateFormat")
        fun timestampToMillis(timestamp: String): Long {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ROOT)
            dateFormat.timeZone = TimeZone.getTimeZone("UTC")
            val parsedDate = dateFormat.parse(timestamp)
            return parsedDate?.time ?: 0
        }
    }

    private fun getAvatarColor(voteCount: Int, backgroundColor: Int): Pair<Int, Int> {
        val level = if (voteCount < 0) 0 else sqrt(abs(voteCount.toDouble()) / 0.8).toInt()
        val colorString =
            if (level > usernameColors.size - 1) usernameColors[usernameColors.size - 1] else usernameColors[level]
        var color = Color.parseColor(colorString)
        val ratio = getContrastRatio(color, backgroundColor)
        if (ratio < 4.5) {
            color = adjustColorForContrast(color, backgroundColor)
        }

        return Pair(color, level)
    }

    private fun extractEpisodeTag(text: String): String? {
        val regex = Regex("""(?:\bep(?:isode)?|\be)\.?\s*(\d+)""", RegexOption.IGNORE_CASE)
        return regex.find(text)?.groupValues?.getOrNull(1)
    }

    private fun applyTimestampHighlighting(textView: android.widget.TextView) {
        val currentText = textView.text ?: return
        val spannable = if (currentText is Spannable) currentText else SpannableStringBuilder(currentText)
        val textStr = spannable.toString()

        val timestampRegex = Regex("""\b(?:(?:([0-1]?[0-9]|2[0-3]):)?([0-5]?[0-9]):([0-5][0-9]))\b""")
        val matches = timestampRegex.findAll(textStr).toList()
        if (matches.isEmpty()) return

        val primaryColor = textView.context.getThemeColor(androidx.appcompat.R.attr.colorPrimary)

        for (match in matches) {
            val start = match.range.first
            val end = match.range.last + 1

            val existingUrlSpans = spannable.getSpans(start, end, android.text.style.URLSpan::class.java)
            if (existingUrlSpans.isNotEmpty()) continue

            val hours = match.groups[1]?.value?.toLongOrNull() ?: 0L
            val minutes = match.groups[2]?.value?.toLongOrNull() ?: 0L
            val seconds = match.groups[3]?.value?.toLongOrNull() ?: 0L
            val timestampMs = (hours * 3600 + minutes * 60 + seconds) * 1000L

            val clickableSpan = object : ClickableSpan() {
                override fun onClick(widget: View) {
                    val spoiler = spannable.getSpans(start, end, ani.dantotsu.others.SpoilerPlugin.RedditSpoilerSpan::class.java).firstOrNull()
                    if (spoiler != null && !spoiler.revealed) {
                        spoiler.setRevealed(true)
                        widget.postInvalidateOnAnimation()
                    } else {
                        val fallbackTag = extractEpisodeTag(comment.content)
                        commentsFragment.onTimestampClicked(comment.tag?.toString() ?: fallbackTag, timestampMs)
                    }
                }

                override fun updateDrawState(ds: TextPaint) {
                    super.updateDrawState(ds)
                    val spoiler = spannable.getSpans(start, end, ani.dantotsu.others.SpoilerPlugin.RedditSpoilerSpan::class.java).firstOrNull()
                    if (spoiler != null && !spoiler.revealed) {
                        ds.bgColor = Color.DKGRAY
                        ds.color = Color.DKGRAY
                        ds.isUnderlineText = false
                    } else {
                        ds.color = primaryColor
                        ds.typeface = Typeface.create(ds.typeface, Typeface.BOLD)
                        ds.isUnderlineText = true
                    }
                }
            }

            spannable.setSpan(clickableSpan, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        textView.text = spannable
        textView.movementMethod = LinkMovementMethod.getInstance()
    }

    /**
     * Builds the dialog for yes/no confirmation
     * no doesn't do anything, yes calls the callback
     * @param title the title of the dialog
     * @param message the message of the dialog
     * @param callback the callback to call when the user clicks yes
     */
    private fun dialogBuilder(title: String, message: String, callback: () -> Unit) {
        commentsFragment.activity.customAlertDialog().apply {
            setTitle(title)
            setMessage(message)
            setPosButton("Yes") {
                callback()
            }
            setNegButton("No") {}
        }.show()
    }

    private val usernameColors: Array<String> = arrayOf(
        "#9932cc",
        "#a020f0",
        "#8b008b",
        "#7b68ee",
        "#da70d6",
        "#dda0dd",
        "#ffe4b5",
        "#f0e68c",
        "#ffb6c1",
        "#fa8072",
        "#b03060",
        "#ff1493",
        "#ff00ff",
        "#ff69b4",
        "#dc143c",
        "#8b0000",
        "#ff0000",
        "#a0522d",
        "#f4a460",
        "#b8860b",
        "#ffa500",
        "#d2691e",
        "#ff6347",
        "#808000",
        "#ffd700",
        "#ffff54",
        "#8fbc8f",
        "#3cb371",
        "#008000",
        "#00fa9a",
        "#98fb98",
        "#00ff00",
        "#adff2f",
        "#32cd32",
        "#556b2f",
        "#9acd32",
        "#7fffd4",
        "#2f4f4f",
        "#5f9ea0",
        "#87ceeb",
        "#00bfff",
        "#00ffff",
        "#1e90ff",
        "#4682b4",
        "#0000ff",
        "#0000cd",
        "#00008b",
        "#191970",
        "#ffffff",
    )
    private fun setupCommentActionsMenu(binding: ItemCommentsBinding, isUserComment: Boolean) {
        val item = this
        binding.apply {
            commentInfo.setOnClickListener {
                val popup = PopupMenu(commentsFragment.requireContext(), commentInfo)
                popup.menuInflater.inflate(R.menu.profile_details_menu, popup.menu)
                popup.menu.findItem(R.id.commentDelete)?.isVisible =
                    isUserComment || CommentsAPI.isAdmin || CommentsAPI.isMod
                popup.menu.findItem(R.id.commentBanUser)?.isVisible =
                    (CommentsAPI.isAdmin || CommentsAPI.isMod) && !isUserComment
                popup.menu.findItem(R.id.commentReport)?.isVisible = !isUserComment
                popup.setOnMenuItemClickListener { item ->
                    when (item.itemId) {
                        R.id.commentReport -> {
                            dialogBuilder(
                                getAppString(R.string.report_comment),
                                getAppString(R.string.report_comment_confirm)
                            ) {
                                CoroutineScope(Dispatchers.Main + SupervisorJob()).launch {
                                    val success = CommentsAPI.reportComment(
                                        comment.commentId,
                                        comment.username,
                                        commentsFragment.mediaName,
                                        comment.userId
                                    )
                                    if (success) {
                                        snackString(R.string.comment_reported)
                                    }
                                }
                            }
                            true
                        }

                        R.id.commentDelete -> {
                            dialogBuilder(
                                getAppString(R.string.delete_comment),
                                getAppString(R.string.delete_comment_confirm)
                            ) {
                                CoroutineScope(Dispatchers.Main + SupervisorJob()).launch {
                                    val success = CommentsAPI.deleteComment(comment.commentId)
                                    if (success) {
                                        snackString(R.string.comment_deleted)
                                        parentSection.remove(this@CommentItem)
                                    }
                                }
                            }
                            true
                        }

                        R.id.commentBanUser -> {
                            dialogBuilder(
                                getAppString(R.string.ban_user),
                                getAppString(R.string.ban_user_confirm)
                            ) {
                                CoroutineScope(Dispatchers.Main + SupervisorJob()).launch {
                                    val success = CommentsAPI.banUser(comment.userId)
                                    if (success) {
                                        snackString(R.string.user_banned)
                                    }
                                }
                            }
                            true
                        }

                        else -> {
                            false
                        }
                    }
                }
                popup.show()
            }
        }
    }

    private fun setupVoteClickListeners(binding: ItemCommentsBinding) {
        binding.apply {
            commentUpVote.setOnClickListener {
                val voteType = if (comment.userVoteType == 1) 0 else 1
                val previousVoteType = comment.userVoteType
                val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
                scope.launch {
                    val success = CommentsAPI.vote(comment.commentId, voteType)
                    if (success) {
                        comment.userVoteType = voteType

                        if (previousVoteType == -1) {
                            comment.downvotes -= 1
                        }
                        comment.upvotes += if (voteType == 1) 1 else -1
                        notifyChanged()
                    }
                }
            }

            commentDownVote.setOnClickListener {
                val voteType = if (comment.userVoteType == -1) 0 else -1
                val previousVoteType = comment.userVoteType
                val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
                scope.launch {
                    val success = CommentsAPI.vote(comment.commentId, voteType)
                    if (success) {
                        comment.userVoteType = voteType
                        if (previousVoteType == 1) {
                            comment.upvotes -= 1
                        }
                        comment.downvotes += if (voteType == -1) 1 else -1
                        notifyChanged()
                    }
                }
            }
        }
    }

}
