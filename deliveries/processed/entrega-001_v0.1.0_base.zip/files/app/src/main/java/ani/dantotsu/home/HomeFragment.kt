package ani.dantotsu.home

import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Animatable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LayoutAnimationController
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ani.dantotsu.MainActivity
import ani.dantotsu.R
import ani.dantotsu.Refresh
import ani.dantotsu.blurImage
import ani.dantotsu.bottomBarOrNull
import ani.dantotsu.connections.anilist.Anilist
import ani.dantotsu.connections.mal.MAL
import ani.dantotsu.connections.anilist.AnilistHomeViewModel
import ani.dantotsu.connections.anilist.getUserId
import ani.dantotsu.currContext
import ani.dantotsu.databinding.FragmentHomeBinding
import ani.dantotsu.home.status.UserStatusAdapter
import ani.dantotsu.loadImage
import ani.dantotsu.media.Media
import ani.dantotsu.media.MediaAdaptor
import ani.dantotsu.media.MediaListViewActivity
import ani.dantotsu.media.user.ListActivity
import ani.dantotsu.navBarHeight
import ani.dantotsu.openLinkInBrowser
import ani.dantotsu.profile.ProfileActivity
import ani.dantotsu.profile.User
import ani.dantotsu.setSafeOnClickListener
import ani.dantotsu.setSlideIn
import ani.dantotsu.setSlideUp
import ani.dantotsu.settings.SettingsDialogFragment
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefManager.asLiveBool
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.snackString
import ani.dantotsu.statusBarHeight
import ani.dantotsu.tryWithSuspend
import ani.dantotsu.util.Logger
import ani.dantotsu.util.customAlertDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onDestroyView() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            _binding?.homeScroll?.setOnScrollChangeListener(null as View.OnScrollChangeListener?)
        }
        super.onDestroyView()
        Refresh.activity.remove(this.hashCode())
        _binding = null
    }

    val model: AnilistHomeViewModel by activityViewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val scope = viewLifecycleOwner.lifecycleScope
        Logger.log("HomeFragment")

        setupHeaderListeners()
        setupScrollAndInsets()

        // UserData
        loadUserData()

        // List Images
        model.getListImages().observe(viewLifecycleOwner) {
            if (it.isNotEmpty()) {
                binding.homeAnimeListImage.loadImage(it[0] ?: "https://bit.ly/31bsIHq")
                binding.homeMangaListImage.loadImage(it[1] ?: "https://bit.ly/2ZGfcuG")
            }
        }

        setupMediaSections(scope)
        setupUserStatusStories()
        setupHiddenItems()

        binding.homeUserAvatarContainer.startAnimation(setSlideUp())

        setupDynamicLayoutAndRefresh(scope)
    }

    private fun bindUserHeader(currentBinding: FragmentHomeBinding, rescueMode: Boolean) {
        if (rescueMode && MAL.token != null) {
            currentBinding.homeUserName.text = MAL.username ?: Anilist.username
            currentBinding.homeUserAvatar.loadImage(MAL.avatar ?: Anilist.avatar)
        } else {
            currentBinding.homeUserName.text = Anilist.username
            currentBinding.homeUserAvatar.loadImage(Anilist.avatar)
        }
    }

    private fun bindUserStats(currentBinding: FragmentHomeBinding, rescueMode: Boolean) {
        if (!rescueMode) {
            currentBinding.homeUserEpisodesWatched.text = Anilist.episodesWatched.toString()
            currentBinding.homeUserChaptersRead.text = Anilist.chapterRead.toString()
            currentBinding.homeNotificationCount.isVisible = Anilist.unreadNotificationCount > 0
                    && PrefManager.getVal<Boolean>(PrefName.ShowNotificationRedDot) == true
            currentBinding.homeNotificationCount.text = Anilist.unreadNotificationCount.toString()
        } else {
            currentBinding.homeUserEpisodesWatched.text = MAL.episodesWatched?.toString() ?: "—"
            currentBinding.homeUserChaptersRead.text = MAL.chaptersRead?.toString() ?: "—"
            currentBinding.homeNotificationCount.isVisible = false
        }
    }

    private fun bindUserBanner(currentBinding: FragmentHomeBinding, rescueMode: Boolean) {
        val bannerAnimations: Boolean = PrefManager.getVal(PrefName.BannerAnimations)
        val bannerUrl = if (rescueMode) Anilist.bg ?: MAL.avatar else Anilist.bg
        blurImage(
            if (bannerAnimations) currentBinding.homeUserBg else currentBinding.homeUserBgNoKen,
            bannerUrl
        )
        currentBinding.homeUserDataProgressBar.visibility = View.GONE
    }

    private fun bindUserLists(currentBinding: FragmentHomeBinding, rescueMode: Boolean) {
        val listUserId = Anilist.userid ?: 0
        val listUsername = if (rescueMode) MAL.username ?: Anilist.username else Anilist.username
        currentBinding.homeAnimeList.setOnClickListener {
            ContextCompat.startActivity(
                requireActivity(), Intent(requireActivity(), ListActivity::class.java)
                    .putExtra("anime", true)
                    .putExtra("userId", listUserId)
                    .putExtra("username", listUsername), null
            )
        }
        currentBinding.homeMangaList.setOnClickListener {
            ContextCompat.startActivity(
                requireActivity(), Intent(requireActivity(), ListActivity::class.java)
                    .putExtra("anime", false)
                    .putExtra("userId", listUserId)
                    .putExtra("username", listUsername), null
            )
        }

        binding.homeUserAvatarContainer.startAnimation(setSlideUp())
        binding.homeUserDataContainer.visibility = View.VISIBLE
        binding.homeUserDataContainer.layoutAnimation =
            LayoutAnimationController(setSlideUp(), 0.25f)
        binding.homeAnimeList.visibility = View.VISIBLE
        binding.homeMangaList.visibility = View.VISIBLE
        binding.homeListContainer.layoutAnimation =
            LayoutAnimationController(setSlideIn(), 0.25f)
    }

    private fun loadUserData() {
        Logger.log("Loading HomeFragment")
        if (activity != null && _binding != null) {
            viewLifecycleOwner.lifecycleScope.launch(Dispatchers.Main) {
                val currentBinding = _binding ?: return@launch
                val rescueMode: Boolean = PrefManager.getVal(PrefName.RescueMode)
                bindUserHeader(currentBinding, rescueMode)
                bindUserStats(currentBinding, rescueMode)
                bindUserBanner(currentBinding, rescueMode)
                bindUserLists(currentBinding, rescueMode)
            }
        } else {
            snackString(currContext()?.getString(R.string.please_reload))
        }
    }

    private fun setupHeaderListeners() {
        binding.homeUserAvatarContainer.setSafeOnClickListener {
            val dialogFragment =
                SettingsDialogFragment.newInstance(SettingsDialogFragment.Companion.PageType.HOME)
            dialogFragment.show(
                (it.context as androidx.appcompat.app.AppCompatActivity).supportFragmentManager,
                "dialog"
            )
        }
        binding.searchImageContainer.setSafeOnClickListener {
            SearchBottomSheet.newInstance().show(
                (it.context as androidx.appcompat.app.AppCompatActivity).supportFragmentManager,
                "search"
            )
        }
        binding.homeUserAvatarContainer.setOnLongClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (!PrefManager.getVal<Boolean>(PrefName.RescueMode)) {
                ContextCompat.startActivity(
                    requireContext(), Intent(requireContext(), ProfileActivity::class.java)
                        .putExtra("userId", Anilist.userid), null
                )
            } else {
                val malUsername = MAL.username
                if (!malUsername.isNullOrBlank()) {
                    try {
                        CustomTabsIntent.Builder().build().launchUrl(
                            requireContext(),
                            Uri.parse("https://myanimelist.net/profile/$malUsername")
                        )
                    } catch (e: Exception) {
                        openLinkInBrowser("https://myanimelist.net/profile/$malUsername")
                    }
                } else {
                    snackString(getString(R.string.rescue_mode_active))
                }
            }
            false
        }
    }

    private fun calculateCutoutHeight(): Int {
        var height = statusBarHeight
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val displayCutout = activity?.window?.decorView?.rootWindowInsets?.displayCutout
            if (displayCutout != null && displayCutout.boundingRects.isNotEmpty()) {
                val rect = displayCutout.boundingRects[0]
                height = max(statusBarHeight, min(rect.width(), rect.height()))
            }
        }
        return height
    }

    private fun setupScrollAndInsets() {
        binding.homeContainer.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            bottomMargin = navBarHeight
        }
        binding.homeUserBg.updateLayoutParams { height += statusBarHeight }
        binding.homeUserBgNoKen.updateLayoutParams { height += statusBarHeight }
        binding.homeTopContainer.updatePadding(top = statusBarHeight)

        var reached = false
        val duration = (PrefManager.getVal<Float>(PrefName.AnimationSpeed) * 200).toLong()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            binding.homeScroll.setOnScrollChangeListener { _, _, _, _, _ ->
                val bar = bottomBarOrNull ?: return@setOnScrollChangeListener
                if (!binding.homeScroll.canScrollVertically(1)) {
                    reached = true
                    bar.animate().translationZ(0f).setDuration(duration).start()
                    ObjectAnimator.ofFloat(bar, "elevation", 4f, 0f).setDuration(duration).start()
                } else if (reached) {
                    bar.animate().translationZ(12f).setDuration(duration).start()
                    ObjectAnimator.ofFloat(bar, "elevation", 0f, 4f).setDuration(duration).start()
                }
            }
        }
        val height = calculateCutoutHeight()
        binding.homeRefresh.setSlingshotDistance(height + 128)
        binding.homeRefresh.setProgressViewEndTarget(false, height + 128)
        binding.homeRefresh.setOnRefreshListener {
            Refresh.activity[1]!!.postValue(true)
        }
    }

    private fun getSkeletonMediaList(count: Int = 7): ArrayList<Media> {
        val list = ArrayList<Media>()
        for (i in 0 until count) {
            list.add(
                Media(
                    anime = ani.dantotsu.media.anime.Anime(),
                    manga = null,
                    id = -100 - i,
                    name = "—",
                    nameRomaji = "—",
                    userPreferredName = "—",
                    cover = null,
                    isAdult = false,
                    meanScore = 0,
                    userProgress = 0
                )
            )
        }
        return list
    }

    private fun updateRecyclerAdapter(recyclerView: RecyclerView, it: ArrayList<Media>) {
        val currentAdapter = recyclerView.adapter as? MediaAdaptor
        if (currentAdapter != null && currentAdapter.type == 0 && currentAdapter.mediaList === it && recyclerView.tag == "loaded") {
            currentAdapter.notifyDataSetChanged()
        } else {
            recyclerView.tag = "loaded"
            recyclerView.adapter = MediaAdaptor(0, it, requireActivity())
            recyclerView.layoutManager = LinearLayoutManager(
                requireContext(),
                LinearLayoutManager.HORIZONTAL,
                false
            )
            recyclerView.visibility = View.VISIBLE
            recyclerView.layoutAnimation = LayoutAnimationController(setSlideIn(), 0.25f)
        }
    }

    private fun initRecyclerView(
        mode: LiveData<ArrayList<Media>>,
        container: View,
        recyclerView: RecyclerView,
        progress: View,
        empty: View,
        title: View,
        more: View,
        string: String
    ) {
        container.visibility = View.VISIBLE
        progress.visibility = View.GONE
        empty.visibility = View.GONE
        title.visibility = View.VISIBLE
        more.visibility = View.VISIBLE
        recyclerView.visibility = View.VISIBLE

        recyclerView.adapter = MediaAdaptor(0, getSkeletonMediaList(), requireActivity())
        recyclerView.layoutManager = LinearLayoutManager(
            requireContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )

        mode.observe(viewLifecycleOwner) { it ->
            if (it != null) {
                if (it.isNotEmpty()) {
                    empty.visibility = View.GONE
                    updateRecyclerAdapter(recyclerView, it)
                    more.setOnClickListener { i ->
                        MediaListViewActivity.passedMedia = it
                        val intent = Intent(i.context, MediaListViewActivity::class.java)
                            .putExtra("title", string)
                        if (string == getString(R.string.recommended)) {
                            intent.putExtra("type", "RECOMMENDED")
                            intent.putExtra("page", model.recommendationPage)
                        }
                        ContextCompat.startActivity(i.context, intent, null)
                    }
                } else {
                    recyclerView.visibility = View.GONE
                    empty.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun setupMediaSections(scope: kotlinx.coroutines.CoroutineScope) {
        initRecyclerView(
            model.getAnimeContinue(),
            binding.homeContinueWatchingContainer,
            binding.homeWatchingRecyclerView,
            binding.homeWatchingProgressBar,
            binding.homeWatchingEmpty,
            binding.homeContinueWatch,
            binding.homeContinueWatchMore,
            getString(R.string.continue_watching)
        )
        binding.homeWatchingBrowseButton.setOnClickListener {
            bottomBarOrNull?.selectTabAt(0)
        }

        initRecyclerView(
            model.getAnimeFav(),
            binding.homeFavAnimeContainer,
            binding.homeFavAnimeRecyclerView,
            binding.homeFavAnimeProgressBar,
            binding.homeFavAnimeEmpty,
            binding.homeFavAnime,
            binding.homeFavAnimeMore,
            getString(R.string.fav_anime)
        )

        initRecyclerView(
            model.getAnimePlanned(),
            binding.homePlannedAnimeContainer,
            binding.homePlannedAnimeRecyclerView,
            binding.homePlannedAnimeProgressBar,
            binding.homePlannedAnimeEmpty,
            binding.homePlannedAnime,
            binding.homePlannedAnimeMore,
            getString(R.string.planned_anime)
        )
        binding.homePlannedAnimeBrowseButton.setOnClickListener {
            bottomBarOrNull?.selectTabAt(0)
        }

        initRecyclerView(
            model.getMissingSequels(),
            binding.homeMissingSequelsContainer,
            binding.homeMissingSequelsRecyclerView,
            binding.homeMissingSequelsProgressBar,
            binding.homeMissingSequelsEmpty,
            binding.homeMissingSequels,
            binding.homeMissingSequelsMore,
            getString(R.string.missing_sequels)
        )

        initRecyclerView(
            model.getMangaContinue(),
            binding.homeContinueReadingContainer,
            binding.homeReadingRecyclerView,
            binding.homeReadingProgressBar,
            binding.homeReadingEmpty,
            binding.homeContinueRead,
            binding.homeContinueReadMore,
            getString(R.string.continue_reading)
        )
        binding.homeReadingBrowseButton.setOnClickListener {
            bottomBarOrNull?.selectTabAt(2)
        }

        initRecyclerView(
            model.getMangaFav(),
            binding.homeFavMangaContainer,
            binding.homeFavMangaRecyclerView,
            binding.homeFavMangaProgressBar,
            binding.homeFavMangaEmpty,
            binding.homeFavManga,
            binding.homeFavMangaMore,
            getString(R.string.fav_manga)
        )

        initRecyclerView(
            model.getMangaPlanned(),
            binding.homePlannedMangaContainer,
            binding.homePlannedMangaRecyclerView,
            binding.homePlannedMangaProgressBar,
            binding.homePlannedMangaEmpty,
            binding.homePlannedManga,
            binding.homePlannedMangaMore,
            getString(R.string.planned_manga)
        )
        binding.homePlannedMangaBrowseButton.setOnClickListener {
            bottomBarOrNull?.selectTabAt(2)
        }

        initRecyclerView(
            model.getRecommendation(),
            binding.homeRecommendedContainer,
            binding.homeRecommendedRecyclerView,
            binding.homeRecommendedProgressBar,
            binding.homeRecommendedEmpty,
            binding.homeRecommended,
            binding.homeRecommendedMore,
            getString(R.string.recommended)
        )
        binding.homeRecommendedRecyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (!recyclerView.canScrollHorizontally(1)) {
                    if (model.recommendationHasNextPage && !model.recommendationLoading) {
                        scope.launch(Dispatchers.IO) {
                            model.loadMoreRecommendations()
                        }
                    }
                }
                super.onScrolled(recyclerView, dx, dy)
            }
        })
    }

    private fun setupUserStatusStories() {
        val storiesEnabled = PrefManager.getVal<List<Boolean>>(PrefName.HomeLayout)
            .getOrElse(7) { true } && !PrefManager.getVal<Boolean>(PrefName.RescueMode)
        binding.homeUserStatusContainer.visibility =
            if (storiesEnabled) View.VISIBLE else View.GONE
        binding.homeUserStatusProgressBar.visibility =
            if (storiesEnabled) View.VISIBLE else View.GONE
        binding.homeUserStatusRecyclerView.visibility = View.GONE
        binding.homeUserStatusRecyclerView.layoutManager = LinearLayoutManager(
            requireContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )
        var latestStatusUsers: ArrayList<User> = arrayListOf()
        model.getUserStatus().observe(viewLifecycleOwner) { users ->
            when {
                users == null -> {
                    val show = PrefManager.getVal<List<Boolean>>(PrefName.HomeLayout)
                        .getOrElse(7) { true } && !PrefManager.getVal<Boolean>(PrefName.RescueMode)
                    if (show) {
                        binding.homeUserStatusContainer.visibility = View.VISIBLE
                        binding.homeUserStatusProgressBar.visibility = View.VISIBLE
                        binding.homeUserStatusRecyclerView.visibility = View.GONE
                    }
                }
                users.isNotEmpty() -> {
                    latestStatusUsers = users
                    binding.homeUserStatusProgressBar.visibility = View.GONE
                    binding.homeUserStatusContainer.visibility = View.VISIBLE
                    binding.homeUserStatusRecyclerView.adapter = UserStatusAdapter(users)
                    binding.homeUserStatusRecyclerView.visibility = View.VISIBLE
                    binding.homeUserStatusRecyclerView.layoutAnimation =
                        LayoutAnimationController(setSlideIn(), 0.25f)
                }
                else -> {
                    latestStatusUsers = arrayListOf()
                    binding.homeUserStatusProgressBar.visibility = View.GONE
                    binding.homeUserStatusRecyclerView.visibility = View.GONE
                    binding.homeUserStatusContainer.visibility = View.GONE
                }
            }
        }
        PrefManager.getLiveVal(PrefName.RefreshStatus, false).asLiveBool()
            .observe(viewLifecycleOwner) {
                if (latestStatusUsers.isNotEmpty()) {
                    binding.homeUserStatusRecyclerView.adapter =
                        UserStatusAdapter(latestStatusUsers)
                }
            }
    }

    private fun setupHiddenItems() {
        binding.homeHiddenItemsContainer.visibility = View.GONE
        model.getHidden().observe(viewLifecycleOwner) {
            if (!it.isNullOrEmpty()) {
                binding.homeHiddenItemsRecyclerView.adapter =
                    MediaAdaptor(0, it, requireActivity())
                binding.homeHiddenItemsRecyclerView.layoutManager = LinearLayoutManager(
                    requireContext(),
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
                binding.homeContinueWatch.setOnLongClickListener {
                    binding.homeHiddenItemsContainer.visibility = View.VISIBLE
                    binding.homeHiddenItemsRecyclerView.layoutAnimation =
                        LayoutAnimationController(setSlideIn(), 0.25f)
                    true
                }
                binding.homeHiddenItemsMore.setSafeOnClickListener { _ ->
                    MediaListViewActivity.passedMedia = it
                    ContextCompat.startActivity(
                        requireActivity(),
                        Intent(requireActivity(), MediaListViewActivity::class.java)
                            .putExtra("title", getString(R.string.hidden)),
                        null
                    )
                }
                binding.homeHiddenItemsTitle.setOnLongClickListener {
                    binding.homeHiddenItemsContainer.visibility = View.GONE
                    true
                }
            } else {
                binding.homeContinueWatch.setOnLongClickListener {
                    snackString(getString(R.string.no_hidden_items))
                    true
                }
            }
        }
    }

    private fun showRescueModeOfflineDialog(ctx: Context) {
        if (!isAdded || _binding == null) return
        ctx.customAlertDialog().apply {
            setTitle(R.string.rescue_mode_prompt_title)
            setMessage(R.string.rescue_mode_offline_prompt_message)
            setPosButton(R.string.use_offline_cache) {
                Anilist.anilistDisabledSignal = false
                snackString(ctx.getString(R.string.offline_mode_active))
            }
            setNeutralButton(R.string.rescue_mode_enable) {
                PrefManager.setVal(PrefName.RescueMode, true)
                Anilist.anilistDisabledSignal = false
                val intent = Intent(ctx, MainActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                startActivity(intent)
                activity?.overridePendingTransition(0, 0)
                activity?.finish()
                activity?.overridePendingTransition(0, 0)
            }
            setNegButton(R.string.cancel) {
                Anilist.anilistDisabledSignal = false
            }
            show()
        }
    }

    private fun applyDynamicHomeLayout(containers: Array<View>): Boolean {
        var empty = true
        val homeLayoutShow: List<Boolean> = PrefManager.getVal(PrefName.HomeLayout)
        val homeLayoutOrderPref: List<Int> = PrefManager.getVal(PrefName.HomeLayoutOrder)
        val homeLayoutOrder = if (homeLayoutOrderPref.isEmpty()) (0..7).toList() else homeLayoutOrderPref

        containers.indices.forEach { i ->
            if (homeLayoutShow.getOrElse(i) { true }) {
                empty = false
            } else {
                containers[i].visibility = View.GONE
            }
        }

        var insertIndex = binding.homeContainer.indexOfChild(binding.homeHiddenItemsContainer) + 1
        homeLayoutOrder.forEach { i ->
            val container = containers.getOrNull(i)
            if (container != null) {
                binding.homeContainer.removeView(container)
                binding.homeContainer.addView(container, insertIndex)
                insertIndex++
            }
        }
        return empty
    }

    private fun setupDynamicLayoutAndRefresh(scope: kotlinx.coroutines.CoroutineScope) {
        val containers: Array<View> = arrayOf(
            binding.homeContinueWatchingContainer,
            binding.homeFavAnimeContainer,
            binding.homePlannedAnimeContainer,
            binding.homeContinueReadingContainer,
            binding.homeFavMangaContainer,
            binding.homePlannedMangaContainer,
            binding.homeRecommendedContainer,
            binding.homeUserStatusContainer,
            binding.homeMissingSequelsContainer,
        )

        model.empty.observe(viewLifecycleOwner) { isEmpty ->
            if (_binding != null) {
                binding.homeDantotsuContainer.visibility = if (isEmpty == true) View.VISIBLE else View.GONE
                (binding.homeDantotsuIcon.drawable as? Animatable)?.start()
                binding.homeDantotsuContainer.startAnimation(setSlideUp())
                binding.homeDantotsuIcon.setSafeOnClickListener {
                    (binding.homeDantotsuIcon.drawable as? Animatable)?.start()
                }
            }
        }

        var running = false
        val live = Refresh.activity.getOrPut(1) { MutableLiveData(true) }
        live.observe(viewLifecycleOwner) { shouldRefresh ->
            if (shouldRefresh && !running) {
                running = true
                scope.launch {
                    performHomeRefresh(containers, live)
                    running = false
                }
            }
        }
    }

    private suspend fun performHomeRefresh(
        containers: Array<View>,
        live: MutableLiveData<Boolean>
    ) = coroutineScope {
        if (_binding != null) {
            if (!model.loaded) {
                withContext(Dispatchers.Main) {
                    if (activity != null) {
                        if (Anilist.token != null || MAL.token != null) {
                            loadUserData()
                        }
                    }
                }
                model.loaded = true
            }

            if (Anilist.anilistDisabledSignal && !PrefManager.getVal<Boolean>(PrefName.RescueMode)) {
                withContext(Dispatchers.Main) {
                    context?.let { showRescueModeOfflineDialog(it) }
                }
            }

            val empty = withContext(Dispatchers.Main) {
                applyDynamicHomeLayout(containers)
            }

            val rescueMode: Boolean = PrefManager.getVal(PrefName.RescueMode)
            val isPullToRefresh = _binding?.homeRefresh?.isRefreshing == true
            val initHomePage = async(Dispatchers.IO) { model.initHomePage(forceRefresh = isPullToRefresh) }
            async(Dispatchers.IO) { model.setListImages() }
            if (!rescueMode) {
                async(Dispatchers.IO) { model.initUserStatus(forceRefresh = isPullToRefresh) }
            }
            initHomePage.await()

            withContext(Dispatchers.Main) {
                model.empty.postValue(empty)
                binding.homeHiddenItemsContainer.visibility = View.GONE
            }

            live.postValue(false)
            _binding?.homeRefresh?.isRefreshing = false
        }
    }

    override fun onResume() {
        if (!model.loaded) Refresh.activity[1]!!.postValue(true)
        if (_binding != null) {
            val rescueMode: Boolean = PrefManager.getVal(PrefName.RescueMode)
            binding.homeNotificationCount.isVisible = !rescueMode
                    && Anilist.unreadNotificationCount > 0
                    && PrefManager.getVal<Boolean>(PrefName.ShowNotificationRedDot) == true
            binding.homeNotificationCount.text = Anilist.unreadNotificationCount.toString()
        }
        super.onResume()
    }
}
