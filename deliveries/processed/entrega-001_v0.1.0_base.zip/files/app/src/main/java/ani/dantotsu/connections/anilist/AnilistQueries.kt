package ani.dantotsu.connections.anilist

import android.util.Base64
import ani.dantotsu.R
import ani.dantotsu.checkGenreTime
import ani.dantotsu.checkId
import ani.dantotsu.connections.anilist.Anilist.authorRoles
import ani.dantotsu.connections.anilist.Anilist.executeQuery
import ani.dantotsu.connections.anilist.api.Activity
import ani.dantotsu.connections.anilist.api.FeedResponse
import ani.dantotsu.connections.anilist.api.FuzzyDate
import ani.dantotsu.connections.anilist.api.MediaEdge
import ani.dantotsu.connections.anilist.api.MediaList
import ani.dantotsu.connections.anilist.api.NotificationResponse
import ani.dantotsu.connections.anilist.api.Page
import ani.dantotsu.connections.anilist.api.Query
import ani.dantotsu.connections.anilist.api.Recommendation
import ani.dantotsu.connections.anilist.api.ReplyResponse
import ani.dantotsu.connections.anilist.api.Media as ApiMedia
import ani.dantotsu.currContext
import ani.dantotsu.isOnline
import ani.dantotsu.logError
import ani.dantotsu.home.status.sortUserStatusList
import ani.dantotsu.media.Author
import ani.dantotsu.media.Character
import ani.dantotsu.media.Media
import ani.dantotsu.media.Studio
import ani.dantotsu.others.MalScraper
import ani.dantotsu.connections.mal.MAL
import ani.dantotsu.connections.mapping.IdMapper
import ani.dantotsu.util.Logger
import ani.dantotsu.profile.User
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.snackString
import ani.dantotsu.tryWithSuspend
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.io.Serializable
import java.util.Calendar
import kotlin.system.measureTimeMillis

class AnilistQueries {
    companion object {

        const val ITEMS_PER_PAGE = 25
    }

    private data class UserStatusCache(
        val users: ArrayList<User>,
        val cachedAt: Long
    ) : Serializable

    private data class HomePageCache(
        val data: Map<String, ArrayList<Media>>,
        val cachedAt: Long
    ) : Serializable

    fun loadHomePageCache(): Map<String, ArrayList<Media>>? {
        val cached = PrefManager.getNullableCustomVal(
            "home_page_cache",
            null,
            HomePageCache::class.java
        ) ?: return null
        val cacheExpired = System.currentTimeMillis() - cached.cachedAt > 3 * 60 * 60 * 1000L
        if (cacheExpired) return null
        return cached.data
    }

    fun saveHomePageCache(data: Map<String, ArrayList<Media>>) {
        PrefManager.setCustomVal(
            "home_page_cache",
            HomePageCache(data, System.currentTimeMillis())
        )
    }

    fun invalidateHomePageCache() {
        PrefManager.setCustomVal("home_page_cache", null)
    }

    suspend fun getUserData(): Boolean {
        val response: Query.Viewer?
        measureTimeMillis {
            response = executeQuery(
                """{Viewer{name options{timezone titleLanguage staffNameLanguage activityMergeTime airingNotifications displayAdultContent restrictMessagesToFollowing} avatar{medium} bannerImage id mediaListOptions{scoreFormat rowOrder animeList{customLists} mangaList{customLists}} statistics{anime{episodesWatched} manga{chaptersRead}} unreadNotificationCount}}"""
            )
        }.also { println("time : $it") }
        val user = response?.data?.user ?: return false

        PrefManager.setVal(PrefName.AnilistUserName, user.name)
        Anilist.userid = user.id
        PrefManager.setVal(PrefName.AnilistUserId, user.id.toString())
        Anilist.username = user.name
        Anilist.bg = user.bannerImage
        Anilist.avatar = user.avatar?.medium
        Anilist.episodesWatched = user.statistics?.anime?.episodesWatched
        Anilist.chapterRead = user.statistics?.manga?.chaptersRead
        Anilist.adult = user.options?.displayAdultContent ?: false
        val anilistCount = user.unreadNotificationCount ?: 0
        val userCount = PrefManager.getVal<Int>(PrefName.UnreadUserNotifications)
        val mediaCount = PrefManager.getVal<Int>(PrefName.UnreadMediaNotifications)
        val subsCount = PrefManager.getVal<Int>(PrefName.UnreadSubscriptionNotifications)
        val commentCount = PrefManager.getVal<Int>(PrefName.UnreadCommentNotifications)
        Anilist.unreadNotificationCount = anilistCount + subsCount + commentCount
        Anilist.initialized = true

        user.options?.let {
            Anilist.titleLanguage = it.titleLanguage.toString()
            Anilist.staffNameLanguage = it.staffNameLanguage.toString()
            Anilist.airingNotifications = it.airingNotifications ?: false
            Anilist.restrictMessagesToFollowing = it.restrictMessagesToFollowing ?: false
            Anilist.timezone = it.timezone
            Anilist.activityMergeTime = it.activityMergeTime
        }
        user.mediaListOptions?.let {
            Anilist.scoreFormat = it.scoreFormat.toString()
            Anilist.rowOrder = it.rowOrder

            it.animeList?.let { animeList ->
                Anilist.animeCustomLists = animeList.customLists
            }

            it.mangaList?.let { mangaList ->
                Anilist.mangaCustomLists = mangaList.customLists
            }
        }
        return true
    }

    suspend fun getMedia(id: Int, mal: Boolean = false, type: String? = null): Media? {
        if (!Anilist.anilistDisabledSignal) {
            try {
                val typeArg = if (type != null) "type: $type," else ""
                val response = executeQuery<Query.Media>(
                    """{Media($typeArg${if (!mal) "id:" else "idMal:"}$id){id idMal status chapters episodes nextAiringEpisode{episode}type meanScore isAdult isFavourite format bannerImage coverImage{large}title{english romaji userPreferred}mediaListEntry{progress private score(format:POINT_100)status}}}""",
                    force = true
                )
                val fetchedMedia = response?.data?.media
                if (fetchedMedia != null) return Media(fetchedMedia)
            } catch (e: Exception) {
                Logger.log("getMedia online query failed: ${e.message}")
            }
        }
        val isAnime = if (type != null) type.uppercase() == "ANIME" else null
        val targetId = if (mal) {
            IdMapper.getAnilistId(id, isAnime = isAnime ?: true) ?: id
        } else id
        return MediaIndexClient.getMedia(targetId, isAnime)
    }

    suspend fun getMediaList(ids: List<Int>): List<Media>? {
        if (ids.isEmpty()) return null

        if (!Anilist.anilistDisabledSignal) {
            try {
                val idsString = ids.joinToString(",")
                val response = executeQuery<Query.MediaList>(
                    """{Page(page:1,perPage:50){media(id_in:[${idsString}],isAdult:false){id mediaListEntry{progress private score(format:POINT_100) status} idMal type isAdult popularity status(version:2) chapters episodes nextAiringEpisode{episode} meanScore isFavourite format bannerImage coverImage{large} title{english romaji userPreferred} startDate{year}}}}""",
                    force = true
                )
                val fetchedMediaList = response?.data?.page?.media
                if (fetchedMediaList != null) {
                    return fetchedMediaList.map { Media(it) }
                }
            } catch (e: Exception) {
                Logger.log("getMediaList online query failed: ${e.message}")
            }
        }
        val fallback = MediaIndexClient.getMediaList(ids)
        return fallback.ifEmpty { null }
    }

    fun mediaDetails(media: Media): Media {
        media.cameFromContinue = false
        runBlocking {
            val anilist = async {
                fetchAndParseMediaDetails(media)
            }
            val mal = async {
                if (media.idMAL == null) {
                    anilist.await()
                }
                if (media.idMAL == null && media.id != 0) {
                    media.idMAL = ani.dantotsu.others.IdMappers.getMalId(media.id)
                }
                if (media.idMAL != null) {
                    MalScraper.loadMedia(media)
                }
            }
            awaitAll(anilist, mal)
        }
        return media
    }

    private suspend fun fetchAndParseMediaDetails(media: Media) {
        var response =
            executeQuery<Query.Media>(fullMediaInformation(media.id), force = true)
        if (response != null) {
            val fetchedMedia = response.data?.media
            if (fetchedMedia != null) {
                parseMediaDetails(media, fetchedMedia, response.data?.page)
            } else {
                snackString(currContext()?.getString(R.string.adult_stuff))
                response = executeQuery(
                    fullMediaInformation(media.id),
                    force = true,
                    useToken = false
                )
                val retryMedia = response?.data?.media
                if (retryMedia != null) {
                    parseMediaDetails(media, retryMedia, response?.data?.page)
                } else {
                    snackString(currContext()?.getString(R.string.what_did_you_open))
                }
            }
        } else {
            if (currContext()?.let { isOnline(it) } == true) {
                snackString(currContext()?.getString(R.string.error_getting_data))
            }
        }
    }

    private fun parseMediaDetails(
        media: Media,
        fetchedMedia: ApiMedia,
        page: Page?
    ) {
        populateMediaBasics(media, fetchedMedia)
        populateCharacters(media, fetchedMedia)
        populateStaff(media, fetchedMedia)
        populateRelations(media, fetchedMedia)
        populateRecommendations(media, fetchedMedia)
        populateReviewsAndStats(media, fetchedMedia)
        populateUserLists(media, page, fetchedMedia)
        populateMediaListEntry(media, fetchedMedia.mediaListEntry)

        if (media.anime != null) {
            populateAnimeDetails(media, fetchedMedia)
        } else if (media.manga != null) {
            populateMangaDetails(media, fetchedMedia)
        }

        if (!fetchedMedia.externalLinks.isNullOrEmpty()) {
            media.externalLinks = ArrayList(fetchedMedia.externalLinks!!)
        }
        media.shareLink = fetchedMedia.siteUrl
    }

    private fun populateMediaBasics(media: Media, fetchedMedia: ApiMedia) {
        if (fetchedMedia.idMal != null) media.idMAL = fetchedMedia.idMal
        media.isFav = fetchedMedia.isFavourite ?: false
        media.source = fetchedMedia.source?.toString()?.replace("_", " ")?.lowercase()?.split(" ")
            ?.joinToString(" ") { it.replaceFirstChar(Char::titlecase) }
        media.countryOfOrigin = fetchedMedia.countryOfOrigin
        media.format = fetchedMedia.format?.toString()
        media.cover = fetchedMedia.coverImage?.large ?: media.cover
        media.banner = fetchedMedia.bannerImage ?: media.banner
        media.favourites = fetchedMedia.favourites
        media.popularity = fetchedMedia.popularity
        media.startDate = fetchedMedia.startDate
        media.endDate = fetchedMedia.endDate
        media.streamingEpisodes = fetchedMedia.streamingEpisodes
        if (fetchedMedia.genres != null) {
            media.genres = arrayListOf()
            fetchedMedia.genres?.forEach { media.genres.add(it) }
        }

        media.trailer = fetchedMedia.trailer?.let { i ->
            if (i.site != null && i.site.toString() == "youtube")
                i.id.toString().trim('"')
            else null
        }

        fetchedMedia.synonyms?.apply {
            media.synonyms = arrayListOf()
            this.forEach { media.synonyms.add(it) }
        }

        fetchedMedia.tags?.apply {
            media.tags = arrayListOf()
            media.tagsIsSpoiler = arrayListOf()
            this.forEach {
                media.tags.add("${it.name} : ${it.rank}%")
                media.tagsIsSpoiler.add(it.isMediaSpoiler == true)
            }
        }
        media.description = fetchedMedia.description.toString()
    }

    private fun populateCharacters(media: Media, fetchedMedia: ApiMedia) {
        val characterEdges = fetchedMedia.characters?.edges ?: return
        media.characters = arrayListOf()
        val mainRole = currContext()?.getString(R.string.main_role) ?: "MAIN"
        val supportingRole = currContext()?.getString(R.string.supporting_role) ?: "SUPPORTING"
        for (edge in characterEdges) {
            val node = edge.node ?: continue
            val roleName = when (edge.role.toString()) {
                "MAIN" -> mainRole
                "SUPPORTING" -> supportingRole
                else -> edge.role.toString()
            }
            val voiceActors = edge.voiceActors?.map {
                Author(
                    id = it.id,
                    name = it.name?.userPreferred,
                    image = it.image?.large,
                    role = it.languageV2
                )
            }?.distinctBy { it.id }?.let { ArrayList(it) }

            media.characters?.add(
                Character(
                    id = node.id,
                    name = node.name?.userPreferred,
                    image = node.image?.medium,
                    banner = media.banner ?: media.cover,
                    isFav = node.isFavourite ?: false,
                    role = roleName,
                    voiceActor = voiceActors
                )
            )
        }
    }

    private fun populateStaff(media: Media, fetchedMedia: ApiMedia) {
        val staffEdges = fetchedMedia.staff?.edges ?: return
        media.staff = arrayListOf()
        val mainRole = currContext()?.getString(R.string.main_role) ?: "MAIN"
        val supportingRole = currContext()?.getString(R.string.supporting_role) ?: "SUPPORTING"
        for (edge in staffEdges) {
            val node = edge.node ?: continue
            val roleName = when (edge.role.toString()) {
                "MAIN" -> mainRole
                "SUPPORTING" -> supportingRole
                else -> edge.role.toString()
            }
            media.staff?.add(
                Author(
                    id = node.id,
                    name = node.name?.userPreferred,
                    image = node.image?.large,
                    role = roleName
                )
            )
        }
    }

    private fun populateRelations(media: Media, fetchedMedia: ApiMedia) {
        val edges = fetchedMedia.relations?.edges ?: return
        val relations = arrayListOf<Media>()
        for (mediaEdge in edges) {
            val m = Media(mediaEdge)
            relations.add(m)
            if (m.relation == "SEQUEL") {
                media.sequel =
                    if ((media.sequel?.popularity ?: 0) < (m.popularity ?: 0)) m else media.sequel
            } else if (m.relation == "PREQUEL") {
                media.prequel =
                    if ((media.prequel?.popularity ?: 0) < (m.popularity ?: 0)) m else media.prequel
            }
        }
        relations.sortByDescending { it.popularity }
        relations.sortByDescending { it.startDate?.year }
        relations.sortBy { it.relation }
        media.relations = relations
    }

    private fun populateRecommendations(media: Media, fetchedMedia: ApiMedia) {
        val nodes = fetchedMedia.recommendations?.nodes ?: return
        val recommendations = arrayListOf<Media>()
        val recommendationList = arrayListOf<Recommendation>()
        for (i in nodes) {
            recommendationList.add(i)
            i.mediaRecommendation?.apply {
                recommendations.add(Media(this))
            }
        }
        media.recommendations = recommendations
        media.recommendationList = recommendationList
    }

    private fun populateReviewsAndStats(media: Media, fetchedMedia: ApiMedia) {
        media.stats = fetchedMedia.stats
        media.rankings = fetchedMedia.rankings
        if (fetchedMedia.reviews?.nodes != null) {
            @Suppress("UNCHECKED_CAST")
            media.review = fetchedMedia.reviews!!.nodes as ArrayList<Query.Review>
        }
    }

    private fun populateUserLists(media: Media, page: Page?, fetchedMedia: ApiMedia) {
        val mediaLists = page?.mediaList
        if (!mediaLists.isNullOrEmpty()) {
            media.users = mediaLists.mapNotNull { entry ->
                entry.user?.let { user ->
                    if (user.id != Anilist.userid) {
                        User(
                            user.id,
                            user.name ?: "Unknown",
                            user.avatar?.large,
                            "",
                            entry.status?.toString(),
                            entry.score,
                            entry.progress,
                            fetchedMedia.episodes ?: fetchedMedia.chapters,
                        )
                    } else null
                }
            }.toCollection(arrayListOf())
        }
    }

    private fun populateMediaListEntry(media: Media, entry: MediaList?) {
        if (entry != null) {
            media.userProgress = entry.progress
            media.userProgressVolumes = entry.progressVolumes
            media.isListPrivate = entry.private ?: false
            media.notes = entry.notes
            media.userListId = entry.id
            media.userScore = entry.score?.toInt() ?: 0
            media.userStatus = entry.status?.toString()
            media.inCustomListsOf = entry.customLists?.toMutableMap()
            media.userRepeat = entry.repeat ?: 0
            media.userUpdatedAt = entry.updatedAt?.toString()?.toLongOrNull()?.times(1000)
            media.userCompletedAt = entry.completedAt ?: FuzzyDate()
            media.userStartedAt = entry.startedAt ?: FuzzyDate()
        } else {
            media.isListPrivate = false
            media.userStatus = null
            media.userListId = null
            media.userProgress = null
            media.userProgressVolumes = null
            media.userScore = 0
            media.userRepeat = 0
            media.userUpdatedAt = null
            media.userCompletedAt = FuzzyDate()
            media.userStartedAt = FuzzyDate()
        }
    }

    private fun populateAnimeDetails(media: Media, fetchedMedia: ApiMedia) {
        val anime = media.anime ?: return
        anime.episodeDuration = fetchedMedia.duration
        anime.season = fetchedMedia.season?.toString()
        anime.seasonYear = fetchedMedia.seasonYear

        val (mainStudio, producers) = resolveMainStudioAndProducers(fetchedMedia)
        anime.mainStudio = mainStudio
        anime.producers = producers

        fetchedMedia.staff?.edges?.find { authorRoles.contains(it.role?.trim()) }?.node?.let {
            anime.author = Author(
                it.id,
                it.name?.userPreferred ?: "N/A",
                it.image?.medium,
                "AUTHOR"
            )
        }

        anime.nextAiringEpisodeTime = fetchedMedia.nextAiringEpisode?.airingAt?.toLong()

        fetchedMedia.externalLinks?.forEach { i ->
            when (i.site.lowercase()) {
                "youtube" -> anime.youtube = i.url
                "crunchyroll" -> media.crunchySlug = i.url?.split("/")?.getOrNull(3)
                "vrv" -> media.vrvId = i.url?.split("/")?.getOrNull(4)
            }
        }
    }

    private fun resolveMainStudioAndProducers(
        fetchedMedia: ApiMedia
    ): Pair<Studio?, ArrayList<Studio>?> {
        var mainStudio: Studio? = null
        var producers: ArrayList<Studio>? = null

        val studioEdges = fetchedMedia.studios?.edges
        if (!studioEdges.isNullOrEmpty()) {
            val mainNode = studioEdges.firstOrNull { it.isMain == true }?.node
                ?: studioEdges.firstOrNull { it.node?.isAnimationStudio == true }?.node
                ?: studioEdges.firstOrNull()?.node
            if (mainNode != null) {
                mainStudio = Studio(
                    mainNode.id.toString(),
                    mainNode.name ?: "N/A",
                    mainNode.isFavourite ?: false,
                    mainNode.favourites ?: 0,
                    null
                )
            }
            val producerNodes = studioEdges.filter { it.isMain != true }.mapNotNull { it.node }
                .filter { it.id.toString() != mainStudio?.id }
            if (producerNodes.isNotEmpty()) {
                producers = ArrayList(producerNodes.map {
                    Studio(
                        it.id.toString(),
                        it.name ?: "N/A",
                        it.isFavourite ?: false,
                        it.favourites ?: 0,
                        null
                    )
                })
            }
        } else {
            fetchedMedia.studios?.nodes?.let { nodes ->
                if (nodes.isNotEmpty()) {
                    val studioNode = nodes.firstOrNull { it.isAnimationStudio == true } ?: nodes[0]
                    mainStudio = Studio(
                        studioNode.id.toString(),
                        studioNode.name ?: "N/A",
                        studioNode.isFavourite ?: false,
                        studioNode.favourites ?: 0,
                        null
                    )
                }
            }
            if (mainStudio == null) {
                fetchedMedia.producers?.nodes?.firstOrNull { it.isAnimationStudio == true }?.let { studioNode ->
                    mainStudio = Studio(
                        studioNode.id.toString(),
                        studioNode.name ?: "N/A",
                        studioNode.isFavourite ?: false,
                        studioNode.favourites ?: 0,
                        null
                    )
                }
            }
            fetchedMedia.producers?.nodes?.let { nodes ->
                val remaining = nodes.filter { it.id.toString() != mainStudio?.id }
                if (remaining.isNotEmpty()) {
                    producers = ArrayList(remaining.map {
                        Studio(
                            it.id.toString(),
                            it.name ?: "N/A",
                            it.isFavourite ?: false,
                            it.favourites ?: 0,
                            null
                        )
                    })
                }
            }
        }
        return Pair(mainStudio, producers)
    }

    private fun populateMangaDetails(media: Media, fetchedMedia: ApiMedia) {
        val manga = media.manga ?: return
        fetchedMedia.staff?.edges?.find { authorRoles.contains(it.role?.trim()) }?.node?.let {
            manga.author = Author(
                it.id,
                it.name?.userPreferred ?: "N/A",
                it.image?.medium,
                "AUTHOR"
            )
        }
    }

        private suspend fun enrichMediaFromIndex(media: Media) {
        val fallback = MediaIndexClient.getMedia(media.id, isAnime = media.anime != null) ?: return
        media.idMAL = media.idMAL ?: fallback.idMAL
        media.cover = media.cover ?: fallback.cover
        media.banner = media.banner ?: fallback.banner
        media.status = media.status ?: fallback.status
        media.format = media.format ?: fallback.format
        media.countryOfOrigin = media.countryOfOrigin ?: fallback.countryOfOrigin
        media.meanScore = media.meanScore ?: fallback.meanScore
        media.startDate = media.startDate ?: fallback.startDate
        media.endDate = media.endDate ?: fallback.endDate
        if (media.genres.isEmpty()) media.genres = fallback.genres
        media.anime?.apply {
            totalEpisodes = totalEpisodes ?: fallback.anime?.totalEpisodes
            nextAiringEpisode = nextAiringEpisode ?: fallback.anime?.nextAiringEpisode
        }
        media.manga?.apply {
            totalChapters = totalChapters ?: fallback.manga?.totalChapters ?: IdMapper.getCachedChapters(media.id)
        }
    }

fun userMediaDetails(media: Media): Media {
        val query =
            """{Media(id:${media.id}){id mediaListEntry{id status progress progressVolumes private repeat customLists updatedAt startedAt{year month day}completedAt{year month day}}isFavourite idMal}}"""
        runBlocking {
            val anilist = async {
                var response = executeQuery<Query.Media>(query, force = true, show = true)
                if (response != null) {
                    fun parse() {
                        val fetchedMedia = response?.data?.media ?: return
                        media.isFav = fetchedMedia.isFavourite ?: false

                        if (fetchedMedia.mediaListEntry != null) {
                            fetchedMedia.mediaListEntry?.apply {
                                media.userProgress = progress
                                media.userProgressVolumes = progressVolumes
                                media.isListPrivate = private ?: false
                                media.userListId = id
                                media.userStatus = status?.toString()
                                media.inCustomListsOf = customLists?.toMutableMap()
                                media.userRepeat = repeat ?: 0
                                media.userUpdatedAt = updatedAt?.toString()?.toLong()?.times(1000)
                                media.userCompletedAt = completedAt ?: FuzzyDate()
                                media.userStartedAt = startedAt ?: FuzzyDate()
                            }
                        } else {
                            media.isListPrivate = false
                            media.userStatus = null
                            media.userListId = null
                            media.userProgress = null
                            media.userProgressVolumes = null
                            media.userRepeat = 0
                            media.userUpdatedAt = null
                            media.userCompletedAt = FuzzyDate()
                            media.userStartedAt = FuzzyDate()
                        }
                    }

                    if (response.data?.media != null) parse()
                    else {
                        response = executeQuery(query, force = true, useToken = false)
                        if (response?.data?.media != null) parse()
                        else enrichMediaFromIndex(media)
                    }
                }
            }
            awaitAll(anilist)
        }
        return media
    }

    private suspend fun favMedia(anime: Boolean, id: Int? = Anilist.userid): ArrayList<Media> {
        var hasNextPage = true
        var page = 0

        suspend fun getNextPage(page: Int): List<Media> {
            val response = executeQuery<Query.User>("""{${favMediaQuery(anime, page, id)}}""")
            val favourites = response?.data?.user?.favourites
            val apiMediaList = if (anime) favourites?.anime else favourites?.manga
            hasNextPage = apiMediaList?.pageInfo?.hasNextPage ?: false
            return apiMediaList?.edges?.mapNotNull {
                it.node?.let { i ->
                    Media(i).apply { isFav = true }
                }
            } ?: return listOf()
        }

        val responseArray = arrayListOf<Media>()
        while (hasNextPage) {
            page++
            responseArray.addAll(getNextPage(page))
        }
        return responseArray
    }

    fun invalidateUserStatusCache() {
        PrefManager.setCustomVal("user_status_cache", null)
    }

    suspend fun getUserStatus(forceRefresh: Boolean = false): ArrayList<User>? {
        val toShow: List<Boolean> =
            PrefManager.getVal(PrefName.HomeLayout)
        if (toShow.getOrNull(7) != true) return arrayListOf()
        if (!forceRefresh) {
            loadUserStatusCache()?.let { return sortUserStatusList(it) }
        }

        return coroutineScope {
            val followingDeferred = async {
                executeQuery<Query.HomePageMedia>(
                    """{Page1:${status(1)}Page2:${status(2)}}""",
                    force = forceRefresh
                )
            }
            val myDeferred = if (Anilist.userid != null) {
                async {
                    executeQuery<Query.HomePageMedia>(
                        """{${myStatus()}}""",
                        force = forceRefresh
                    )
                }
            } else null

            val followingResponse = followingDeferred.await()
            val myResponse = myDeferred?.await()

            val allPages = mutableListOf<List<Activity>>()
            followingResponse?.data?.page1?.activities?.let { allPages.add(it) }
            followingResponse?.data?.page2?.activities?.let { allPages.add(it) }
            myResponse?.data?.myActivities?.activities?.let { allPages.add(it) }
                ?: followingResponse?.data?.myActivities?.activities?.let { allPages.add(it) }

            if (allPages.isEmpty() && followingResponse == null && myResponse == null) {
                snackString(currContext()?.getString(R.string.error_loading_data, "stories"))
                return@coroutineScope emptyUserStatusFallback() ?: arrayListOf()
            }

            val threeDaysAgo = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, -3)
            }.timeInMillis
            val list = mutableListOf<User>()
            val activities = allPages.asSequence().flatten()
                .filter { it.typename != "MessageActivity" }
                .filter { if (Anilist.adult) true else it.media?.isAdult != true }
                .filter { it.createdAt * 1000L > threeDaysAgo }
                .distinctBy { it.id }
                .toList()
                .sortedByDescending { it.createdAt }
            val anilistActivities = mutableListOf<User>()
            val groupedActivities = activities.groupBy { it.userId }

            groupedActivities.forEach { (_, userActivities) ->
                val user = userActivities.firstOrNull()?.user
                if (user != null) {
                    val userToAdd = User(
                        user.id,
                        user.name ?: "",
                        user.avatar?.large ?: user.avatar?.medium,
                        user.bannerImage,
                        activity = userActivities.sortedBy { it.createdAt }.toList()
                    )
                    if (user.id == Anilist.userid) {
                        anilistActivities.add(0, userToAdd)
                    } else {
                        list.add(userToAdd)
                    }
                }
            }

            if (anilistActivities.isEmpty()) {
                emptyUserStatusFallback()?.firstOrNull()?.let { anilistActivities.add(0, it) }
            }
            list.addAll(0, anilistActivities)
            val result = list.toCollection(ArrayList())
            if (result.isNotEmpty()) {
                saveUserStatusCache(result)
            }
            sortUserStatusList(result)
        }
    }

    private fun emptyUserStatusFallback(): ArrayList<User>? {
        val uid = Anilist.userid ?: return null
        if (Anilist.token == null) return null
        return arrayListOf(
            User(
                uid,
                Anilist.username ?: "",
                Anilist.avatar,
                Anilist.bg,
                activity = listOf()
            )
        )
    }

    private fun favMediaQuery(anime: Boolean, page: Int, id: Int? = Anilist.userid): String {
        return """User(id:${id}){id favourites{${if (anime) "anime" else "manga"}(page:$page){$standardPageInformation edges{favouriteOrder node{id idMal isAdult mediaListEntry{ progress private score(format:POINT_100) status } chapters isFavourite format episodes nextAiringEpisode{episode}meanScore isFavourite format startDate{year month day} title{english romaji userPreferred}type status(version:2)bannerImage coverImage{large}}}}}}"""
    }

    private fun recommendationQuery(sort: String = "RATING_DESC", page: Int = 1, perPage: Int = 50): String {
        return """ Page(page: $page, perPage:$perPage) { $standardPageInformation recommendations(sort: $sort, onList: true) { rating userRating mediaRecommendation { id idMal isAdult mediaListEntry { progress progressVolumes private score(format:POINT_100) status } chapters volumes isFavourite format episodes nextAiringEpisode {episode} popularity meanScore isFavourite format title {english romaji userPreferred } type status(version: 2) bannerImage coverImage { large } description genres tags { name isMediaSpoiler } } } } """
    }

    suspend fun getRecommendations(page: Int, perPage: Int = 50): Pair<ArrayList<Media>, Boolean> {
        val query = """{
            recRating: ${recommendationQuery("RATING_DESC", page, perPage)}
            recNew: ${recommendationQuery("ID_DESC", page, perPage)}
        }"""
        val response = executeQuery<Query.RecommendationsResponse>(query, show = true)
        val subMap = mutableMapOf<Int, Media>()

        response?.data?.recRating?.recommendations?.forEach {
            it.mediaRecommendation?.let { json ->
                val media = Media(json)
                if (media.userStatus == null) {
                    media.relation = json.type?.toString()
                    subMap[media.id] = media
                }
            }
        }
        response?.data?.recNew?.recommendations?.forEach {
            it.mediaRecommendation?.let { json ->
                val media = Media(json)
                if (media.userStatus == null) {
                    media.relation = json.type?.toString()
                    subMap[media.id] = media
                }
            }
        }
        val list = ArrayList(subMap.values).apply { sortByDescending { it.meanScore } }
        val hasNext = response?.data?.recRating?.pageInfo?.hasNextPage == true ||
                response?.data?.recNew?.pageInfo?.hasNextPage == true
        return Pair(list, hasNext)
    }

    private fun missingSequelsCompletedSourceQuery(): String {
        return """ MediaListCollection( userId: ${Anilist.userid}, type: ANIME, status: COMPLETED, sort: UPDATED_TIME_DESC ) { lists { entries { media { id relations { edges { relationType(version: 2) node { id } } } } } } } """.trimIndent()
    }

    private fun missingSequelsAllListSourceQuery(): String {
        return """ MediaListCollection( userId: ${Anilist.userid}, type: ANIME ) { lists { entries { media { id } } } } """.trimIndent()
    }

    private val batchSize = 50
    private fun missingSequelsLookupQuery(ids: List<Int>): String {
        val idsString = ids.joinToString(",")
        return """ { Page(page: 1, perPage: $batchSize) { media( id_in: [$idsString], type: ANIME, status_in: [RELEASING, FINISHED], onList: false ) { id mediaListEntry { progress progressVolumes private score(format: POINT_100) status } idMal type isAdult popularity status(version: 2) chapters volumes episodes nextAiringEpisode { episode } meanScore isFavourite format bannerImage coverImage { large } title { english romaji userPreferred } startDate { year } } } } """.trimIndent()
    }

    private suspend fun fetchMissingSequelMedia(ids: Set<Int>): ArrayList<Media> {
        if (ids.isEmpty()) return arrayListOf()
        val response = executeQuery<Query.Page>(missingSequelsLookupQuery(ids.toList()))
        val mediaList = response?.data?.page?.media?.mapNotNull { media ->
            if (media.mediaListEntry == null) Media(media) else null
        } ?: emptyList()
        return ArrayList(mediaList)
    }

    private fun loadUserStatusCache(): ArrayList<User>? {
        val cached = PrefManager.getNullableCustomVal(
            "user_status_cache",
            null,
            UserStatusCache::class.java
        ) ?: return null
        val cacheExpired = System.currentTimeMillis() - cached.cachedAt > 15 * 60 * 1000L
        if (cacheExpired) return null
        return ArrayList(cached.users)
    }

    private fun saveUserStatusCache(users: ArrayList<User>) {
        PrefManager.setCustomVal(
            "user_status_cache",
            UserStatusCache(users, System.currentTimeMillis())
        )
    }

    private fun continueMediaQuery(type: String, status: String): String {
        return """ MediaListCollection(userId: ${Anilist.userid}, type: $type, status: $status , sort: UPDATED_TIME ) { lists { entries { progress private score(format:POINT_100) status updatedAt media { id idMal type isAdult status chapters episodes nextAiringEpisode {episode} meanScore isFavourite format bannerImage coverImage{large} title { english romaji userPreferred } } } } } """
    }

    suspend fun initHomePage(): Map<String, ArrayList<Media>> {
        val removeList = PrefManager.getCustomVal<Set<String>>("removeList", emptySet())
            .mapNotNull { it.toIntOrNull() }.toSet()
        val hidePrivate = PrefManager.getVal<Boolean>(PrefName.HidePrivate)
        val removedMedia = ArrayList<Media>()
        val toShow = PrefManager.getVal<List<Boolean>>(PrefName.HomeLayout).toMutableList()

        val queries = buildHomePageQueries(toShow)
        if (queries.isEmpty() && toShow.getOrNull(8) != true) {
            return mutableMapOf("hidden" to arrayListOf())
        }

        val response = if (queries.isEmpty()) {
            null
        } else {
            val query = "{${queries.joinToString(",")}}"
            executeQuery<Query.HomePageMedia>(query, show = true)
        }
        if (queries.isNotEmpty() && response == null) {
            return emptyMap()
        }

        val returnMap = mutableMapOf<String, ArrayList<Media>>()

        if (toShow.getOrNull(0) == true) {
            returnMap["currentAnime"] = processMediaSection(
                type = "Anime",
                currentMedia = response?.data?.currentAnime?.lists?.flatMap { it.entries ?: emptyList() }?.reversed(),
                repeatingMedia = response?.data?.repeatingAnime?.lists?.flatMap { it.entries ?: emptyList() }?.reversed(),
                removeList = removeList,
                hidePrivate = hidePrivate,
                removedMedia = removedMedia
            )
        }
        if (toShow.getOrNull(2) == true) {
            returnMap["currentAnimePlanned"] = processMediaSection(
                type = "AnimePlanned",
                currentMedia = response?.data?.plannedAnime?.lists?.flatMap { it.entries ?: emptyList() }?.reversed(),
                repeatingMedia = null,
                removeList = removeList,
                hidePrivate = hidePrivate,
                removedMedia = removedMedia
            )
        }
        if (toShow.getOrNull(3) == true) {
            returnMap["currentManga"] = processMediaSection(
                type = "Manga",
                currentMedia = response?.data?.currentManga?.lists?.flatMap { it.entries ?: emptyList() }?.reversed(),
                repeatingMedia = response?.data?.repeatingManga?.lists?.flatMap { it.entries ?: emptyList() }?.reversed(),
                removeList = removeList,
                hidePrivate = hidePrivate,
                removedMedia = removedMedia
            )
        }
        if (toShow.getOrNull(5) == true) {
            returnMap["currentMangaPlanned"] = processMediaSection(
                type = "MangaPlanned",
                currentMedia = response?.data?.plannedManga?.lists?.flatMap { it.entries ?: emptyList() }?.reversed(),
                repeatingMedia = null,
                removeList = removeList,
                hidePrivate = hidePrivate,
                removedMedia = removedMedia
            )
        }
        if (toShow.getOrNull(1) == true) {
            returnMap["favoriteAnime"] = processFavoritesSection(
                favorites = response?.data?.favoriteAnime?.favourites?.anime?.edges,
                removeList = removeList,
                hidePrivate = hidePrivate,
                removedMedia = removedMedia
            )
        }
        if (toShow.getOrNull(4) == true) {
            returnMap["favoriteManga"] = processFavoritesSection(
                favorites = response?.data?.favoriteManga?.favourites?.manga?.edges,
                removeList = removeList,
                hidePrivate = hidePrivate,
                removedMedia = removedMedia
            )
        }
        if (toShow.getOrNull(6) == true) {
            returnMap["recommendations"] = processRecommendationsSection(response)
        }
        if (toShow.getOrNull(8) == true) {
            returnMap["missingSequels"] = processMissingSequelsSection(
                response = response,
                removeList = removeList,
                hidePrivate = hidePrivate,
                removedMedia = removedMedia
            )
        }

        returnMap["hidden"] = sortHiddenMedia(removedMedia)
        return returnMap
    }

    private fun buildHomePageQueries(toShow: List<Boolean>): MutableList<String> {
        val queries = mutableListOf<String>()
        if (toShow.getOrNull(0) == true) {
            queries.add("""currentAnime: ${continueMediaQuery("ANIME", "CURRENT")}""")
            queries.add("""repeatingAnime: ${continueMediaQuery("ANIME", "REPEATING")}""")
        }
        if (toShow.getOrNull(1) == true) queries.add("""favoriteAnime: ${favMediaQuery(true, 1)}""")
        if (toShow.getOrNull(2) == true) queries.add("""plannedAnime: ${continueMediaQuery("ANIME", "PLANNING")}""")
        if (toShow.getOrNull(3) == true) {
            queries.add("""currentManga: ${continueMediaQuery("MANGA", "CURRENT")}""")
            queries.add("""repeatingManga: ${continueMediaQuery("MANGA", "REPEATING")}""")
        }
        if (toShow.getOrNull(4) == true) queries.add("""favoriteManga: ${favMediaQuery(false, 1)}""")
        if (toShow.getOrNull(5) == true) queries.add("""plannedManga: ${continueMediaQuery("MANGA", "PLANNING")}""")
        if (toShow.getOrNull(6) == true) {
            queries.add("""recommendationQuery: ${recommendationQuery("RATING_DESC", 1, 50)}""")
            queries.add("""recommendationQueryNew: ${recommendationQuery("ID_DESC", 1, 50)}""")
        }
        if (toShow.getOrNull(8) == true) {
            queries.add("""missingSequelsCompletedQuery: ${missingSequelsCompletedSourceQuery()}""")
            queries.add("""missingSequelsAllListQuery: ${missingSequelsAllListSourceQuery()}""")
        }
        return queries
    }

    private fun processMediaSection(
        type: String,
        currentMedia: List<MediaList>?,
        repeatingMedia: List<MediaList>?,
        removeList: Set<Int>,
        hidePrivate: Boolean,
        removedMedia: MutableList<Media>
    ): ArrayList<Media> {
        val subMap = mutableMapOf<Int, Media>()
        val returnArray = arrayListOf<Media>()

        fun filterAndMap(entries: List<MediaList>?) {
            entries?.forEach { entry ->
                val media = Media(entry)
                if (media.id !in removeList && (!hidePrivate || !media.isListPrivate)) {
                    media.cameFromContinue = true
                    if (media.manga != null && media.manga.totalChapters == null) {
                        media.manga.totalChapters = IdMapper.getCachedChapters(media.id)
                    }
                    subMap[media.id] = media
                } else {
                    removedMedia.add(media)
                }
            }
        }

        filterAndMap(currentMedia)
        filterAndMap(repeatingMedia)

        @Suppress("UNCHECKED_CAST")
        val list = PrefManager.getNullableCustomVal(
            "continue${type}List",
            listOf<Int>(),
            List::class.java
        ) as List<Int>

        if (list.isNotEmpty()) {
            list.reversed().forEach { id ->
                subMap[id]?.let { returnArray.add(it) }
            }
            subMap.values
                .filter { it !in returnArray }
                .sortedByDescending { it.userUpdatedAt ?: 0L }
                .forEach { returnArray.add(it) }
        } else {
            returnArray.addAll(
                subMap.values.sortedByDescending { it.userUpdatedAt ?: 0L }
            )
        }
        return returnArray
    }

    private fun processFavoritesSection(
        favorites: List<MediaEdge>?,
        removeList: Set<Int>,
        hidePrivate: Boolean,
        removedMedia: MutableList<Media>
    ): ArrayList<Media> {
        val returnArray = arrayListOf<Media>()
        favorites?.forEach { edge ->
            edge.node?.let {
                val media = Media(it).apply { isFav = true }
                if (media.id !in removeList && (!hidePrivate || !media.isListPrivate)) {
                    returnArray.add(media)
                } else {
                    removedMedia.add(media)
                }
            }
        }
        return returnArray
    }

    private fun processRecommendationsSection(
        response: Query.HomePageMedia?
    ): ArrayList<Media> {
        val subMap = mutableMapOf<Int, Media>()
        fun extractRecs(recs: List<Recommendation>?) {
            recs?.forEach { node ->
                node.mediaRecommendation?.let { json ->
                    val media = Media(json)
                    if (media.userStatus == null) {
                        media.relation = json.type?.toString()
                        subMap[media.id] = media
                    }
                }
            }
        }
        extractRecs(response?.data?.recommendationQuery?.recommendations)
        extractRecs(response?.data?.recommendationQueryNew?.recommendations)
        return ArrayList(subMap.values).apply { sortByDescending { it.meanScore } }
    }

    private suspend fun processMissingSequelsSection(
        response: Query.HomePageMedia?,
        removeList: Set<Int>,
        hidePrivate: Boolean,
        removedMedia: MutableList<Media>
    ): ArrayList<Media> {
        val completedEntries =
            response?.data?.missingSequelsCompletedQuery?.lists?.flatMap { it.entries ?: emptyList() }
        val allAnimeEntries =
            response?.data?.missingSequelsAllListQuery?.lists?.flatMap { it.entries ?: emptyList() }

        val sequelIds = mutableSetOf<Int>()
        completedEntries?.forEach { entry ->
            entry.media?.relations?.edges?.forEach { edge ->
                if (edge.relationType?.name == "SEQUEL") {
                    edge.node?.id?.let { sequelIds.add(it) }
                }
            }
        }
        val allAnimeIds = allAnimeEntries?.mapNotNull { it.media?.id }?.toSet() ?: emptySet()
        val filteredSequelIds = sequelIds - allAnimeIds

        val sequels = if (filteredSequelIds.isNotEmpty()) fetchMissingSequelMedia(filteredSequelIds) else arrayListOf()
        val visibleSequels = arrayListOf<Media>()
        sequels.forEach { sequel ->
            if (sequel.id !in removeList && (!hidePrivate || !sequel.isListPrivate)) {
                visibleSequels.add(sequel)
            } else {
                removedMedia.add(sequel)
            }
        }
        return visibleSequels
    }

    private fun sortHiddenMedia(removedMedia: List<Media>): ArrayList<Media> {
        val allOrders = listOf(
            "continueAnimeList",
            "continueAnimePlannedList",
            "continueMangaList",
            "continueMangaPlannedList"
        ).flatMap {
            PrefManager.getNullableCustomVal(it, listOf<Int>(), List::class.java) as List<*>
        }

        val hiddenList = removedMedia.distinctBy { it.id }
        val sortedHidden = arrayListOf<Media>()

        if (allOrders.isNotEmpty()) {
            allOrders.reversed().forEach { id ->
                hiddenList.find { it.id == id }?.let { sortedHidden.add(it) }
            }
            hiddenList
                .filter { it !in sortedHidden }
                .sortedByDescending { it.userUpdatedAt ?: 0L }
                .forEach { sortedHidden.add(it) }
        } else {
            sortedHidden.addAll(hiddenList.sortedByDescending { it.userUpdatedAt ?: 0L })
        }
        return sortedHidden
    }

    private suspend fun bannerImage(type: String): String? {
        if (PrefManager.getVal<Boolean>(PrefName.RescueMode)) {
            if (MAL.token != null) {
                val isAnime = type == "ANIME"
                val status = if (isAnime) "watching" else "reading"
                val listRes = tryWithSuspend {
                    if (isAnime) MAL.query.getUserAnimeList(status = status, limit = 25)
                    else MAL.query.getUserMangaList(status = status, limit = 25)
                }
                val randomCover = listRes?.data?.mapNotNull {
                    it.node.mainPicture?.large ?: it.node.mainPicture?.medium
                }?.randomOrNull()
                if (randomCover != null) return randomCover
            }
            return MAL.avatar
        }

        val image = BannerImage(
            PrefManager.getCustomVal("banner_${type}_url", ""),
            PrefManager.getCustomVal("banner_${type}_time", 0L)
        )
        if (image.url.isNullOrEmpty() || image.checkTime()) {
            val response =
                executeQuery<Query.MediaListCollection>("""{ MediaListCollection(userId: ${Anilist.userid}, type: $type, chunk:1,perChunk:25, sort: [SCORE_DESC,UPDATED_TIME_DESC]) { lists { entries{ media { id bannerImage isAdult } } } } } """)
            val random: String? = response?.data?.mediaListCollection?.lists?.mapNotNull {
                it.entries?.filter { i -> i.media?.isAdult != true }?.mapNotNull { entry ->
                    val imageUrl = entry.media?.bannerImage
                    if (imageUrl != null && imageUrl != "null") imageUrl else null
                }
            }?.flatten()?.randomOrNull()
            if (random == null) return null
            PrefManager.setCustomVal("banner_${type}_url", random)
            PrefManager.setCustomVal("banner_${type}_time", System.currentTimeMillis())
            return random
        } else return image.url
    }

    suspend fun getBannerImages(): ArrayList<String?> {
        return coroutineScope {
            val anime = async { bannerImage("ANIME") }
            val manga = async { bannerImage("MANGA") }
            arrayListOf(anime.await(), manga.await())
        }
    }

    suspend fun getMediaLists(
        anime: Boolean,
        userId: Int,
        sortOrder: String? = null
    ): MutableMap<String, ArrayList<Media>> {
        val response =
            executeQuery<Query.MediaListCollection>("""{ MediaListCollection(userId: $userId, type: ${if (anime) "ANIME" else "MANGA"}) { lists { name isCustomList entries { status progress progressVolumes private score(format:POINT_100) updatedAt startedAt{year month day} completedAt{year month day} media { id idMal isAdult type status chapters volumes episodes nextAiringEpisode {episode} bannerImage genres tags { name isMediaSpoiler } meanScore isFavourite format coverImage{large} startDate{year month day} title {english romaji userPreferred } } } } user { id mediaListOptions { rowOrder animeList { sectionOrder } mangaList { sectionOrder } } } } }""")
        val sorted = mutableMapOf<String, ArrayList<Media>>()
        val unsorted = mutableMapOf<String, ArrayList<Media>>()
        val all = arrayListOf<Media>()
        val allIds = arrayListOf<Int>()

        response?.data?.mediaListCollection?.lists?.forEach { i ->
            val name = i.name.toString().trim('"')
            unsorted[name] = arrayListOf()
            i.entries?.forEach {
                val a = Media(it)
                unsorted[name]?.add(a)
                if (!allIds.contains(a.id)) {
                    allIds.add(a.id)
                    all.add(a)
                }
            }
        }

        val options = response?.data?.mediaListCollection?.user?.mediaListOptions
        val mediaList = if (anime) options?.animeList else options?.mangaList
        mediaList?.sectionOrder?.forEach {
            if (unsorted.containsKey(it)) sorted[it] = unsorted[it]!!
        }
        unsorted.forEach {
            if (!sorted.containsKey(it.key)) sorted[it.key] = it.value
        }

        sorted["Favourites"] = favMedia(anime, userId)
        sorted["Favourites"]?.sortWith(compareBy { it.userFavOrder })
        //favMedia doesn't fill userProgress, so we need to fill it manually by searching :(
        sorted["Favourites"]?.forEach { fav ->
            all.find { it.id == fav.id }?.let {
                fav.userProgress = it.userProgress
                fav.userProgressVolumes = it.userProgressVolumes
            }
        }

        sorted["All"] = all
        val listSort: String? = if (anime) PrefManager.getVal(PrefName.AnimeListSortOrder)
        else PrefManager.getVal(PrefName.MangaListSortOrder)
        val sort = listSort ?: sortOrder ?: options?.rowOrder
        for (i in sorted.keys) {
            when (sort) {
                "score" -> sorted[i]?.sortWith { b, a ->
                    compareValuesBy(
                        a,
                        b,
                        { it.userScore },
                        { it.meanScore })
                }

                "title" -> sorted[i]?.sortWith(compareBy { it.userPreferredName })
                "updatedAt" -> sorted[i]?.sortWith(compareByDescending { it.userUpdatedAt })
                "release" -> sorted[i]?.sortWith(compareByDescending { it.startDate })
                "id" -> sorted[i]?.sortWith(compareBy { it.id })
            }
        }
        return sorted
    }


    suspend fun getGenresAndTags(): Boolean {
        var genres: ArrayList<String>? = PrefManager.getVal<Set<String>>(PrefName.GenresList)
            .toMutableList() as ArrayList<String>?
        val adultTags = PrefManager.getVal<Set<String>>(PrefName.TagsListIsAdult).toMutableList()
        val nonAdultTags =
            PrefManager.getVal<Set<String>>(PrefName.TagsListNonAdult).toMutableList()
        var tags = if (adultTags.isEmpty() || nonAdultTags.isEmpty()) null else
            mapOf(
                true to adultTags.sortedBy { it },
                false to nonAdultTags.sortedBy { it }
            )

        if (genres.isNullOrEmpty()) {
            executeQuery<Query.GenreCollection>(
                """{GenreCollection}""",
                force = true,
                useToken = false
            )?.data?.genreCollection?.apply {
                val list = arrayListOf<String>()
                forEach {
                    list.add(it)
                }
                genres = list
                PrefManager.setVal(PrefName.GenresList, list.toSet())
            }
        }
        if (tags == null) {
            executeQuery<Query.MediaTagCollection>(
                """{ MediaTagCollection { name isAdult } }""",
                force = true
            )?.data?.mediaTagCollection?.apply {
                val adult = mutableListOf<String>()
                val good = mutableListOf<String>()
                forEach { node ->
                    if (node.isAdult == true) adult.add(node.name)
                    else good.add(node.name)
                }
                tags = mapOf(
                    true to adult,
                    false to good
                )
                PrefManager.setVal(PrefName.TagsListIsAdult, adult.toSet())
                PrefManager.setVal(PrefName.TagsListNonAdult, good.toSet())
            }
        }
        return if (!genres.isNullOrEmpty() && tags != null) {
            Anilist.genres = ArrayList(genres.sorted())
            Anilist.tags = tags
            true
        } else false
    }

    suspend fun getGenres(genres: ArrayList<String>, listener: ((Pair<String, String>) -> Unit)) {
        genres.forEach {
            val thumbnail = getGenreThumbnail(it)
            if (thumbnail != null) {
                listener.invoke(it to thumbnail.thumbnail)
            } else {
                listener.invoke(it to "")
            }
        }
    }

    private fun <K, V : Serializable> saveSerializableMap(prefKey: String, map: Map<K, V>) {
        val byteStream = ByteArrayOutputStream()

        ObjectOutputStream(byteStream).use { outputStream ->
            outputStream.writeObject(map)
        }
        val serializedMap = Base64.encodeToString(byteStream.toByteArray(), Base64.DEFAULT)
        PrefManager.setCustomVal(prefKey, serializedMap)
    }

    @Suppress("UNCHECKED_CAST")
    private fun <K, V : Serializable> loadSerializableMap(prefKey: String): Map<K, V>? {
        try {
            val serializedMap = PrefManager.getCustomVal(prefKey, "")
            if (serializedMap.isEmpty()) return null

            val bytes = Base64.decode(serializedMap, Base64.DEFAULT)
            val byteArrayStream = ByteArrayInputStream(bytes)

            return ObjectInputStream(byteArrayStream).use { inputStream ->
                inputStream.readObject() as? Map<K, V>
            }
        } catch (e: Exception) {
            return null
        }
    }

    private suspend fun getGenreThumbnail(genre: String): Genre? {
        val genres: MutableMap<String, Genre> =
            loadSerializableMap<String, Genre>("genre_thumb")?.toMutableMap()
                ?: mutableMapOf()
        if (genres.checkGenreTime(genre)) {
            try {
                val genreQuery =
                    """{ Page(perPage: 10){media(genre:"$genre", sort: TRENDING_DESC, type: ANIME, countryOfOrigin:"JP") {id bannerImage title{english romaji userPreferred} } } }"""
                executeQuery<Query.Page>(genreQuery, force = true)?.data?.page?.media?.forEach {
                    if (genres.checkId(it.id) && it.bannerImage != null) {
                        genres[genre] = Genre(
                            genre,
                            it.id,
                            it.bannerImage!!,
                            System.currentTimeMillis()
                        )
                        saveSerializableMap("genre_thumb", genres)
                        return genres[genre]
                    }
                }
            } catch (e: Exception) {
                logError(e)
            }
        } else {
            return genres[genre]
        }
        return null
    }

    suspend fun searchAniManga(
        type: String,
        page: Int? = null,
        perPage: Int? = null,
        search: String? = null,
        sort: String? = null,
        genres: MutableList<String>? = null,
        tags: MutableList<String>? = null,
        status: String? = null,
        source: String? = null,
        format: String? = null,
        countryOfOrigin: String? = null,
        isAdult: Boolean = false,
        onList: Boolean? = null,
        excludedGenres: MutableList<String>? = null,
        excludedTags: MutableList<String>? = null,
        startYear: Int? = null,
        seasonYear: Int? = null,
        season: String? = null,
        id: Int? = null,
        hd: Boolean = false,
        adultOnly: Boolean = false
    ): AniMangaSearchResults? {
        val variables = buildAniMangaSearchVariables(
            type = type,
            page = page,
            search = search,
            sort = sort,
            genres = genres,
            tags = tags,
            status = status,
            source = source,
            format = format,
            countryOfOrigin = countryOfOrigin,
            isAdult = isAdult,
            onList = onList,
            excludedGenres = excludedGenres,
            excludedTags = excludedTags,
            startYear = startYear,
            seasonYear = seasonYear,
            season = season,
            id = id,
            adultOnly = adultOnly
        )
        val response =
            executeQuery<Query.Page>(aniMangaSearch(perPage), variables, true)?.data?.page
        if (response?.media != null) {
            val pageInfo = response.pageInfo ?: return null
            return AniMangaSearchResults(
                type = type,
                perPage = perPage,
                search = search,
                sort = sort,
                isAdult = isAdult,
                onList = onList,
                genres = genres,
                excludedGenres = excludedGenres,
                tags = tags,
                excludedTags = excludedTags,
                status = status,
                source = source,
                format = format,
                countryOfOrigin = countryOfOrigin,
                startYear = startYear,
                seasonYear = seasonYear,
                season = season,
                results = parseAniMangaMediaList(response.media, hd, onList),
                page = pageInfo.currentPage.toString().toIntOrNull() ?: 0,
                hasNextPage = pageInfo.hasNextPage == true,
            )
        }
        if (!search.isNullOrBlank()) {
            val fallbackResults =
                MediaIndexClient.searchByTitle(search, isAnime = type == "ANIME", limit = perPage ?: 20)
            if (fallbackResults.isNotEmpty()) {
                return AniMangaSearchResults(
                    type = type,
                    perPage = perPage,
                    search = search,
                    sort = sort,
                    isAdult = isAdult,
                    onList = onList,
                    genres = genres,
                    excludedGenres = excludedGenres,
                    tags = tags,
                    excludedTags = excludedTags,
                    status = status,
                    source = source,
                    format = format,
                    countryOfOrigin = countryOfOrigin,
                    startYear = startYear,
                    seasonYear = seasonYear,
                    season = season,
                    results = ArrayList(fallbackResults),
                    page = 1,
                    hasNextPage = false
                )
            }
        }
        return null
    }

    private fun parseAniMangaMediaList(
        mediaList: List<ApiMedia>?,
        hd: Boolean,
        onList: Boolean?
    ): ArrayList<Media> {
        val responseArray = arrayListOf<Media>()
        mediaList?.forEach { i ->
            val userStatus = i.mediaListEntry?.status.toString()
            val genresArr = arrayListOf<String>()
            i.genres?.let { genresArr.addAll(it) }
            val media = Media(i)
            if (!hd) media.cover = i.coverImage?.large
            media.relation = if (onList == true) userStatus else null
            media.genres = genresArr
            responseArray.add(media)
        }
        return responseArray
    }

    private fun buildAniMangaSearchVariables(
        type: String,
        page: Int?,
        search: String?,
        sort: String?,
        genres: MutableList<String>?,
        tags: MutableList<String>?,
        status: String?,
        source: String?,
        format: String?,
        countryOfOrigin: String?,
        isAdult: Boolean,
        onList: Boolean?,
        excludedGenres: MutableList<String>?,
        excludedTags: MutableList<String>?,
        startYear: Int?,
        seasonYear: Int?,
        season: String?,
        id: Int?,
        adultOnly: Boolean
    ): String {
        val fields = mutableListOf<String>()
        fields.add("\"type\":\"$type\"")
        fields.add("\"isAdult\":${if (adultOnly) true else isAdult}")
        if (onList != null) fields.add("\"onList\":$onList")
        if (page != null) fields.add("\"page\":\"$page\"")
        if (id != null) fields.add("\"id\":\"$id\"")
        if (search != null) fields.add("\"search\":\"$search\"")
        if (sort != null) fields.add("\"sort\":\"$sort\"")
        appendDateAndSeasonFields(fields, type, startYear, seasonYear, season)
        appendFilterFields(fields, status, source, format, countryOfOrigin)
        appendListFields(fields, genres, excludedGenres, tags, excludedTags)
        return "{${fields.joinToString(",")}}".prepare()
    }

    private fun appendDateAndSeasonFields(
        fields: MutableList<String>,
        type: String,
        startYear: Int?,
        seasonYear: Int?,
        season: String?
    ) {
        if (type == "ANIME" && seasonYear != null) {
            fields.add("\"seasonYear\":\"$seasonYear\"")
        }
        if (type == "MANGA" && startYear != null) {
            fields.add("\"yearGreater\":${startYear}0000,\"yearLesser\":${startYear + 1}0000")
        }
        if (season != null) {
            fields.add("\"season\":\"$season\"")
        }
    }

    private fun appendFilterFields(
        fields: MutableList<String>,
        status: String?,
        source: String?,
        format: String?,
        countryOfOrigin: String?
    ) {
        if (status != null) fields.add("\"status\":\"$status\"")
        if (source != null) fields.add("\"source\":\"$source\"")
        if (format != null) fields.add("\"format\":\"${format.replace(" ", "_")}\"")
        if (countryOfOrigin != null) fields.add("\"countryOfOrigin\":\"$countryOfOrigin\"")
    }

    private fun appendListFields(
        fields: MutableList<String>,
        genres: MutableList<String>?,
        excludedGenres: MutableList<String>?,
        tags: MutableList<String>?,
        excludedTags: MutableList<String>?
    ) {
        if (!genres.isNullOrEmpty()) {
            fields.add("\"genres\":[${genres.joinToString { "\"$it\"" }}]")
        }
        if (!excludedGenres.isNullOrEmpty()) {
            fields.add("\"excludedGenres\":[${excludedGenres.joinToString { "\"${it.replace("Not ", "")}\"" }}]")
        }
        if (!tags.isNullOrEmpty()) {
            fields.add("\"tags\":[${tags.joinToString { "\"$it\"" }}]")
        }
        if (!excludedTags.isNullOrEmpty()) {
            fields.add("\"excludedTags\":[${excludedTags.joinToString { "\"${it.replace("Not ", "")}\"" }}]")
        }
    }

    suspend fun searchCharacters(page: Int, search: String?): CharacterSearchResults? {
        if (search.isNullOrBlank()) return null
        val query = """
           {
             Page(page: $page, perPage: $ITEMS_PER_PAGE) {
               $standardPageInformation
               characters(search: "$search") {
                  ${characterInformation(false)}
               }
             }
           }
        """.prepare()

        val response = executeQuery<Query.Page>(query, force = true)?.data?.page

        if (response?.characters != null) {
            val responseArray = arrayListOf<Character>()
            response.characters?.forEach { i ->
                responseArray.add(
                    Character(
                        i.id,
                        i.name?.full,
                        i.image?.medium ?: i.image?.large,
                        null,
                        null.toString(),
                        i.isFavourite ?: false,
                        i.description,
                        i.age,
                        i.gender,
                        i.dateOfBirth,
                    )
                )
            }

            val pageInfo = response.pageInfo ?: return null

            return CharacterSearchResults(
                search = search,
                results = responseArray,
                page = pageInfo.currentPage ?: 0,
                hasNextPage = pageInfo.hasNextPage == true
            )
        }
        return null
    }

    suspend fun searchStudios(page: Int, search: String?): StudioSearchResults? {
        if (search.isNullOrBlank()) return null
        val query = """
           {
             Page(page: $page, perPage: $ITEMS_PER_PAGE) {
               $standardPageInformation
               studios(search: "$search") {
                  ${studioInformation(1, 1)}
               }
             }
           }
        """.prepare()

        val response = executeQuery<Query.Page>(query, force = true)?.data?.page

        if (response?.studios != null) {
            val responseArray = arrayListOf<Studio>()
            response.studios?.forEach { i ->
                responseArray.add(
                    Studio(
                        i.id.toString(),
                        i.name ?: return null,
                        i.isFavourite ?: false,
                        i.favourites,
                        i.media?.edges?.firstOrNull()?.node?.let { it.coverImage?.large }
                    )
                )
            }

            val pageInfo = response.pageInfo ?: return null

            return StudioSearchResults(
                search = search,
                results = responseArray,
                page = pageInfo.currentPage ?: 0,
                hasNextPage = pageInfo.hasNextPage == true
            )
        }
        return null
    }

    suspend fun searchStaff(page: Int, search: String?): StaffSearchResults? {
        if (search.isNullOrBlank()) return null
        val query = """
           {
             Page(page: $page, perPage: $ITEMS_PER_PAGE) {
               $standardPageInformation
               staff(search: "$search") {
                  ${staffInformation(1, 1)}
               }
             }
           }
        """.prepare()

        val response = executeQuery<Query.Page>(query, force = true)?.data?.page

        if (response?.staff != null) {
            val responseArray = arrayListOf<Author>()
            response.staff?.forEach { i ->
                responseArray.add(
                    Author(
                        i.id,
                        i.name?.userPreferred ?: return null,
                        i.image?.large,
                        null,
                        null,
                        null
                    )
                )
            }

            val pageInfo = response.pageInfo ?: return null

            return StaffSearchResults(
                search = search,
                results = responseArray,
                page = pageInfo.currentPage ?: 0,
                hasNextPage = pageInfo.hasNextPage == true
            )
        }
        return null
    }

    suspend fun searchUsers(page: Int, search: String?): UserSearchResults? {
        val query = """
           {
             Page(page: $page, perPage: $ITEMS_PER_PAGE) {
               $standardPageInformation
               users(search: "$search") {
                  ${userInformation()}
               }
             }
           }
        """.prepare()

        val response = executeQuery<Query.Page>(query, force = true)?.data?.page

        if (response?.users != null) {
            val users = response.users?.map { user ->
                User(
                    user.id,
                    user.name ?: return null,
                    user.avatar?.medium,
                    user.bannerImage
                )
            } ?: return null

            return UserSearchResults(
                search = search,
                results = users.toMutableList(),
                page = response.pageInfo?.currentPage ?: 0,
                hasNextPage = response.pageInfo?.hasNextPage == true
            )
        }
        return null
    }

    private fun mediaList(media1: Page?): ArrayList<Media> {
        val combinedList = arrayListOf<Media>()
        media1?.media?.mapTo(combinedList) { Media(it) }
        return combinedList
    }

    private fun getPreference(pref: PrefName): Boolean = PrefManager.getVal(pref)

    private fun buildQueryString(
        sort: String,
        type: String,
        format: String? = null,
        country: String? = null
    ): String {
        val includeList = when {
            type == "ANIME" && !getPreference(PrefName.IncludeAnimeList) -> "onList:false"
            type == "MANGA" && !getPreference(PrefName.IncludeMangaList) -> "onList:false"
            else -> ""
        }
        val isAdult = if (getPreference(PrefName.AdultOnly)) "isAdult:true" else ""
        val formatFilter = format?.let { "format:$it, " } ?: ""
        val countryFilter = country?.let { "countryOfOrigin:$it, " } ?: ""

        return buildString {
            append("""Page(page:1,perPage:50){$standardPageInformation media(sort:$sort, type:$type, $formatFilter $countryFilter $includeList $isAdult){id idMal status chapters episodes nextAiringEpisode{episode} isAdult type meanScore isFavourite format bannerImage countryOfOrigin coverImage{large} title{english romaji userPreferred} description genres tags { name isMediaSpoiler } mediaListEntry{progress private score(format:POINT_100) status}}}""")
        }
    }

    private fun recentAnimeUpdates(page: Int): String {
        val currentTime = System.currentTimeMillis() / 1000
        return buildString {
            append("""Page(page:$page,perPage:50){$standardPageInformation airingSchedules(airingAt_greater:0 airingAt_lesser:${currentTime - 10000} sort:TIME_DESC){episode airingAt media{id idMal status chapters episodes nextAiringEpisode{episode} isAdult type meanScore isFavourite format bannerImage countryOfOrigin coverImage{large} title{english romaji userPreferred} description genres tags { name isMediaSpoiler } mediaListEntry{progress private score(format:POINT_100) status}}}}""")
        }
    }

    private fun queryAnimeList(onList: Boolean = true): String {
        val (season, year) = Anilist.currentSeasons[1]
        val includeList = if (!onList) "onList:false" else ""
        val isAdult = if (getPreference(PrefName.AdultOnly)) "isAdult:true" else ""
        return buildString {
            append(
                """{recentUpdates:${recentAnimeUpdates(1)} trendingMovies:${
                    buildQueryString(
                        "POPULARITY_DESC",
                        "ANIME",
                        "MOVIE"
                    )
                } topRated:${
                    buildQueryString(
                        "SCORE_DESC",
                        "ANIME"
                    )
                } mostFav:${buildQueryString("FAVOURITES_DESC", "ANIME")} trending: Page(page:1, perPage:12) { $standardPageInformation media(sort:TRENDING_DESC, type:ANIME, season:$season, seasonYear:$year, $isAdult) { id idMal status episodes nextAiringEpisode{episode} isAdult type meanScore isFavourite format bannerImage countryOfOrigin coverImage{large} title{english romaji userPreferred} description genres tags { name isMediaSpoiler } mediaListEntry{progress private score(format:POINT_100) status} } } popular: Page(page:1, perPage:50) { $standardPageInformation media(sort:POPULARITY_DESC, type:ANIME, $includeList $isAdult) { id idMal status chapters episodes nextAiringEpisode{episode} isAdult type meanScore isFavourite format bannerImage countryOfOrigin coverImage{large} title{english romaji userPreferred} description genres tags { name isMediaSpoiler } mediaListEntry{progress private score(format:POINT_100) status} } }}"""
            )
        }
    }

    private fun queryMangaList(onList: Boolean = true): String {
        val includeList = if (!onList) "onList:false" else ""
        val isAdult = if (getPreference(PrefName.AdultOnly)) "isAdult:true" else ""
        return buildString {
            append(
                """{trendingManga:${
                    buildQueryString(
                        "POPULARITY_DESC",
                        "MANGA",
                        country = "JP"
                    )
                } trendingManhwa:${
                    buildQueryString(
                        "POPULARITY_DESC",
                        "MANGA",
                        country = "KR"
                    )
                } trendingNovel:${
                    buildQueryString(
                        "POPULARITY_DESC",
                        "MANGA",
                        format = "NOVEL",
                        country = "JP"
                    )
                } topRated:${
                    buildQueryString(
                        "SCORE_DESC",
                        "MANGA"
                    )
                } mostFav:${buildQueryString("FAVOURITES_DESC", "MANGA")} trending: Page(page:1, perPage:10) { $standardPageInformation media(sort:TRENDING_DESC, type:MANGA, $isAdult) { id idMal status chapters episodes nextAiringEpisode{episode} isAdult type meanScore isFavourite format bannerImage countryOfOrigin coverImage{large} title{english romaji userPreferred} description genres tags { name isMediaSpoiler } mediaListEntry{progress private score(format:POINT_100) status} } } popular: Page(page:1, perPage:50) { $standardPageInformation media(sort:POPULARITY_DESC, type:MANGA, $includeList $isAdult) { id idMal status chapters episodes nextAiringEpisode{episode} isAdult type meanScore isFavourite format bannerImage countryOfOrigin coverImage{large} title{english romaji userPreferred} description genres tags { name isMediaSpoiler } mediaListEntry{progress private score(format:POINT_100) status} } }}"""
            )
        }
    }

    suspend fun loadAnimeList(onList: Boolean = true): Map<String, ArrayList<Media>> = coroutineScope {
        val list = mutableMapOf<String, ArrayList<Media>>()

        fun filterRecentUpdates(page: Page?): ArrayList<Media> {
            val listOnly = getPreference(PrefName.RecentlyListOnly)
            val adultOnly = getPreference(PrefName.AdultOnly)
            val idArr = mutableSetOf<Int>()
            return page?.airingSchedules?.mapNotNull { i ->
                i.media?.takeIf { !idArr.contains(it.id) }?.let {
                    val shouldAdd = when {
                        !listOnly && adultOnly && it.isAdult == true -> true
                        !listOnly && !adultOnly && it.countryOfOrigin == "JP" && it.isAdult == false -> true
                        listOnly && it.mediaListEntry != null -> true
                        else -> false
                    }
                    if (shouldAdd) {
                        idArr.add(it.id)
                        Media(it)
                    } else null
                }
            }?.toCollection(ArrayList()) ?: arrayListOf()
        }

        val animeList = async { executeQuery<Query.AnimeList>(queryAnimeList(onList), force = true) }

        animeList.await()?.data?.apply {
            list["recentUpdates"] = filterRecentUpdates(recentUpdates)
            list["trendingMovies"] = mediaList(trendingMovies)
            list["topRated"] = mediaList(topRated)
            list["mostFav"] = mediaList(mostFav)
            list["trending"] = mediaList(trending)
            list["popular"] = mediaList(popular)
        }

        list
    }

    suspend fun loadMangaList(onList: Boolean = true): Map<String, ArrayList<Media>> = coroutineScope {
        val list = mutableMapOf<String, ArrayList<Media>>()

        val mangaList = async { executeQuery<Query.MangaList>(queryMangaList(onList), force = true) }

        mangaList.await()?.data?.apply {
            list["trendingManga"] = mediaList(trendingManga)
            list["trendingManhwa"] = mediaList(trendingManhwa)
            list["trendingNovel"] = mediaList(trendingNovel)
            list["topRated"] = mediaList(topRated)
            list["mostFav"] = mediaList(mostFav)
            list["trending"] = mediaList(trending)
            list["popular"] = mediaList(popular)
        }

        list
    }

    suspend fun recentlyUpdated(
        greater: Long = 0,
        lesser: Long = System.currentTimeMillis() / 1000 - 10000
    ): MutableList<Media> {
        suspend fun execute(page: Int = 1): Page? {
            val query = """{
Page(page:$page,perPage:50) {
    $standardPageInformation
    airingSchedules(
        airingAt_greater: $greater
        airingAt_lesser: $lesser
        sort:TIME_DESC
    ) {
        episode
        airingAt
        media {
            ${standardMediaInformation()}
        }
    }
}
        }""".prepare()
            return executeQuery<Query.Page>(query, force = true)?.data?.page
        }

        var i = 1
        val list = mutableListOf<Media>()
        var res: Page? = null
        suspend fun next() {
            res = execute(i)
            list.addAll(res?.airingSchedules?.mapNotNull { j ->
                j.media?.let {
                    if (it.countryOfOrigin == "JP" && (if (!Anilist.adult) it.isAdult == false else true)) {
                        Media(it).apply { relation = "${j.episode},${j.airingAt}" }
                    } else null
                }
            } ?: listOf())
        }
        next()
        while (res?.pageInfo?.hasNextPage == true) {
            next()
            i++
        }
        return list.reversed().toMutableList()
    }

    suspend fun getCharacterDetails(character: Character): Character {
        val query = """ {
  Character(id: ${character.id}) {
    ${characterInformation(true)}
  }
}""".prepare()
        executeQuery<Query.Character>(query, force = true)?.data?.character?.let { i ->
            return Character(
                i.id,
                i.name?.full,
                i.image?.large ?: i.image?.medium,
                null,
                null.toString(),
                i.isFavourite ?: false,
                i.description,
                i.age,
                i.gender,
                i.dateOfBirth,
                i.media?.edges?.map {
                    val m = Media(it)
                    m.relation = it.characterRole.toString()
                    m
                }?.let { ArrayList(it) },
                i.media?.edges?.flatMap { edge ->
                    edge.voiceActors?.map { va ->
                        Author(
                            va.id,
                            va.name?.userPreferred,
                            va.image?.large ?: va.image?.medium,
                            va.languageV2
                        )
                    } ?: emptyList()
                }?.distinctBy { it.id }?.let { ArrayList(it) }
            )
        }
        return character
    }

    suspend fun getStudioDetails(studio: Studio): Studio {
        fun query(page: Int = 0) = """ {
  Studio(id: ${studio.id}) {
    ${studioInformation(page, ITEMS_PER_PAGE)}
  }
}""".prepare()

        var hasNextPage = true
        val yearMedia = mutableMapOf<String, ArrayList<Media>>()
        var page = 0
        val seenMediaIds = hashSetOf<Int>()
        while (hasNextPage) {
            page++
            hasNextPage =
                executeQuery<Query.Studio>(query(page), force = true)?.data?.studio?.media?.let {
                    it.edges?.forEach { i ->
                        i.node?.apply {
                            if (id !in seenMediaIds) {
                                seenMediaIds.add(id)
                                val status = status.toString()
                                val year = startDate?.year?.toString() ?: "TBA"
                                val title = if (status != "CANCELLED") year else status
                                if (!yearMedia.containsKey(title))
                                    yearMedia[title] = arrayListOf()
                                yearMedia[title]?.add(Media(this))
                            }
                        }
                    }
                    it.pageInfo?.hasNextPage == true
                } ?: false
        }
        if (yearMedia.contains("CANCELLED")) {
            val a = yearMedia["CANCELLED"]!!
            yearMedia.remove("CANCELLED")
            yearMedia["CANCELLED"] = a
        }
        studio.yearMedia = yearMedia
        return studio
    }


    suspend fun getAuthorDetails(author: Author): Author {
        fun query(page: Int = 0) = """ {
  Staff(id: ${author.id}) {
    ${staffInformation(page, ITEMS_PER_PAGE)}
    characters(page: $page,sort:FAVOURITES_DESC) {
      $standardPageInformation
      nodes{
        ${characterInformation(false)}
      }
    }
  }
}""".prepare()

        var hasNextPage = true
        val yearMedia = mutableMapOf<String, ArrayList<Media>>()
        var page = 0
        val characters = arrayListOf<Character>()
        while (hasNextPage) {
            page++
            val query = executeQuery<Query.Author>(
                query(page), force = true
            )?.data?.author
            author.age = query?.age
            author.yearsActive =
                if (query?.yearsActive?.isEmpty() == true) null else query?.yearsActive
            author.homeTown = if (query?.homeTown?.isBlank() == true) null else query?.homeTown
            author.dateOfDeath = if (query?.dateOfDeath?.toStringOrEmpty()
                    ?.isBlank() == true
            ) null else query?.dateOfDeath?.toStringOrEmpty()
            author.dateOfBirth = if (query?.dateOfBirth?.toStringOrEmpty()
                    ?.isBlank() == true
            ) null else query?.dateOfBirth?.toStringOrEmpty()
            hasNextPage = query?.staffMedia?.let {
                it.edges?.forEach { i ->
                    i.node?.apply {
                        val status = status.toString()
                        val year = startDate?.year?.toString() ?: "TBA"
                        val title = if (status != "CANCELLED") year else status
                        if (!yearMedia.containsKey(title))
                            yearMedia[title] = arrayListOf()
                        val media = Media(this)
                        media.relation = i.staffRole
                        yearMedia[title]?.add(media)
                    }
                }
                it.pageInfo?.hasNextPage == true
            } ?: false
            query?.characters?.let {
                it.nodes?.forEach { i ->
                    characters.add(
                        Character(
                            i.id,
                            i.name?.userPreferred,
                            i.image?.large,
                            i.image?.medium,
                            "",
                            false
                        )
                    )
                }
            }
        }

        if (yearMedia.contains("CANCELLED")) {
            val a = yearMedia["CANCELLED"]!!
            yearMedia.remove("CANCELLED")
            yearMedia["CANCELLED"] = a
        }
        author.character = characters
        author.yearMedia = yearMedia
        return author
    }

    suspend fun getReviews(
        mediaId: Int,
        page: Int = 1,
        sort: String = "SCORE_DESC"
    ): Query.ReviewsResponse? {
        return executeQuery<Query.ReviewsResponse>(
            """{Page(page:$page,perPage:10){$standardPageInformation reviews(mediaId:$mediaId,sort:$sort){id,mediaId,mediaType,summary,body(asHtml:true)rating,ratingAmount,userRating,score,private,siteUrl,createdAt,updatedAt,user{id,name,bannerImage avatar{medium,large}}}}}""",
            force = true
        )
    }

    suspend fun getUserProfile(id: Int): Query.UserProfileResponse? {
        return executeQuery<Query.UserProfileResponse>(
            """{followerPage:Page{followers(userId:$id){id}$standardPageInformation}followingPage:Page{following(userId:$id){id}$standardPageInformation}user:User(id:$id){id name about(asHtml:true)avatar{medium large}bannerImage isFollowing isFollower isBlocked favourites{anime{nodes{id coverImage{extraLarge large medium color}}}manga{nodes{id coverImage{extraLarge large medium color}}}characters{nodes{id name{first middle last full native alternative userPreferred}image{large medium}isFavourite}}staff{nodes{id name{first middle last full native alternative userPreferred}image{large medium}isFavourite}}studios{nodes{id name isFavourite}}}statistics{anime{count meanScore standardDeviation minutesWatched episodesWatched chaptersRead volumesRead}manga{count meanScore standardDeviation minutesWatched episodesWatched chaptersRead volumesRead}}siteUrl}}""",
            force = true
        )
    }

    suspend fun getUserProfile(username: String): Query.UserProfileResponse? {
        val id = getUserId(username) ?: return null
        return getUserProfile(id)
    }

    private suspend fun getUserId(username: String): Int? {
        return executeQuery<Query.User>(
            """{User(name:"$username"){id}}""",
            force = true
        )?.data?.user?.id
    }

    suspend fun getUserStatistics(id: Int, sort: String = "ID"): Query.StatisticsResponse? {
        return executeQuery<Query.StatisticsResponse>(
            """{User(id:$id){id name mediaListOptions{scoreFormat}statistics{anime{...UserStatistics}manga{...UserStatistics}}}}fragment UserStatistics on UserStatistics{count meanScore standardDeviation minutesWatched episodesWatched chaptersRead volumesRead formats(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds format}statuses(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds status}scores(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds score}lengths(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds length}releaseYears(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds releaseYear}startYears(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds startYear}genres(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds genre}tags(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds tag{id name}}countries(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds country}voiceActors(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds voiceActor{id name{first middle last full native alternative userPreferred}}characterIds}staff(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds staff{id name{first middle last full native alternative userPreferred}}}studios(sort:$sort){count meanScore minutesWatched chaptersRead mediaIds studio{id name isAnimationStudio}}}""",
            force = true,
            show = true
        )
    }

    private fun userFavMediaQuery(anime: Boolean, id: Int): String {
        return """User(id:${id}){id favourites{${if (anime) "anime" else "manga"}(page:1){$standardPageInformation edges{favouriteOrder node{id idMal isAdult mediaListEntry{ progress private score(format:POINT_100) status } chapters isFavourite format episodes nextAiringEpisode{episode}meanScore isFavourite format startDate{year month day} title{english romaji userPreferred}type status(version:2)bannerImage coverImage{large}}}}}}"""
    }

    suspend fun userFollowing(id: Int): List<ani.dantotsu.connections.anilist.api.User> {
        val result = mutableListOf<ani.dantotsu.connections.anilist.api.User>()
        var page = 1
        var hasNextPage = true
        while (hasNextPage) {
            val response = executeQuery<Query.Page>(
                """{Page(page:$page,perPage:50) {$standardPageInformation following(userId:${id},sort:[USERNAME]){id name isFollowing isFollower avatar{large medium}bannerImage}}}""",
                force = true
            )
            val pageData = response?.data?.page
            pageData?.following?.let { result.addAll(it) }
            hasNextPage = pageData?.pageInfo?.hasNextPage == true
            page++
        }
        return result
    }

    suspend fun userFollowers(id: Int): List<ani.dantotsu.connections.anilist.api.User> {
        val result = mutableListOf<ani.dantotsu.connections.anilist.api.User>()
        var page = 1
        var hasNextPage = true
        while (hasNextPage) {
            val response = executeQuery<Query.Page>(
                """{Page(page:$page,perPage:50) {$standardPageInformation followers(userId:${id},sort:[USERNAME]){id name isFollowing isFollower avatar{large medium}bannerImage}}}""",
                force = true
            )
            val pageData = response?.data?.page
            pageData?.followers?.let { result.addAll(it) }
            hasNextPage = pageData?.pageInfo?.hasNextPage == true
            page++
        }
        return result
    }

    suspend fun initProfilePage(id: Int): Query.ProfilePageMedia? {
        return executeQuery<Query.ProfilePageMedia>(
            """{
            favoriteAnime:${userFavMediaQuery(true, id)}
            favoriteManga:${userFavMediaQuery(false, id)}
            }""".prepare(), force = true
        )
    }


    suspend fun getNotifications(
        id: Int,
        page: Int = 1,
        resetNotification: Boolean = true,
        type: Boolean? = null
    ): NotificationResponse? {
        val typeIn = "type_in:[AIRING,MEDIA_MERGE,MEDIA_DELETION,MEDIA_DATA_CHANGE,RELATED_MEDIA_ADDITION]"
        val reset = if (resetNotification) "true" else "false"
        val res = executeQuery<NotificationResponse>(
            """{User(id:$id){unreadNotificationCount}Page(page:$page,perPage:$ITEMS_PER_PAGE){$standardPageInformation notifications(resetNotificationCount:$reset , ${if (type == true) typeIn else ""}){__typename...on AiringNotification{id,type,animeId,episode,contexts,createdAt,media{id,title{romaji,english,native,userPreferred}bannerImage,coverImage{medium,large}},}...on FollowingNotification{id,userId,type,context,createdAt,user{id,name,bannerImage,avatar{medium,large,}}}...on ActivityMessageNotification{id,userId,type,activityId,context,createdAt,message{id}user{id,name,bannerImage,avatar{medium,large,}}}...on ActivityMentionNotification{id,userId,type,activityId,context,createdAt,activity{__typename}user{id,name,bannerImage,avatar{medium,large,}}}...on ActivityReplyNotification{id,userId,type,activityId,context,createdAt,activity{__typename}user{id,name,bannerImage,avatar{medium,large,}}}...on ActivityReplySubscribedNotification{id,userId,type,activityId,context,createdAt,activity{__typename}user{id,name,bannerImage,avatar{medium,large,}}}...on ActivityLikeNotification{id,userId,type,activityId,context,createdAt,activity{__typename}user{id,name,bannerImage,avatar{medium,large,}}}...on ActivityReplyLikeNotification{id,userId,type,activityId,context,createdAt,activity{__typename}user{id,name,bannerImage,avatar{medium,large,}}}...on ThreadCommentMentionNotification{id,userId,type,commentId,context,createdAt,thread{id}comment{id}user{id,name,bannerImage,avatar{medium,large,}}}...on ThreadCommentReplyNotification{id,userId,type,commentId,context,createdAt,thread{id}comment{id}user{id,name,bannerImage,avatar{medium,large,}}}...on ThreadCommentSubscribedNotification{id,userId,type,commentId,context,createdAt,thread{id}comment{id}user{id,name,bannerImage,avatar{medium,large,}}}...on ThreadCommentLikeNotification{id,userId,type,commentId,context,createdAt,thread{id}comment{id}user{id,name,bannerImage,avatar{medium,large,}}}...on ThreadLikeNotification{id,userId,type,threadId,context,createdAt,thread{id}comment{id}user{id,name,bannerImage,avatar{medium,large,}}}...on RelatedMediaAdditionNotification{id,type,context,createdAt,media{id,title{romaji,english,native,userPreferred}bannerImage,coverImage{medium,large}}}...on MediaDataChangeNotification{id,type,mediaId,context,reason,createdAt,media{id,title{romaji,english,native,userPreferred}bannerImage,coverImage{medium,large}}}...on MediaMergeNotification{id,type,mediaId,deletedMediaTitles,context,reason,createdAt,media{id,title{romaji,english,native,userPreferred}bannerImage,coverImage{medium,large}}}...on MediaDeletionNotification{id,type,deletedMediaTitle,context,reason,createdAt,}}}}""",
            force = true
        )
        if (res != null && resetNotification) {
            val commentNotifications = PrefManager.getVal(PrefName.UnreadCommentNotifications, 0)
            res.data.user.unreadNotificationCount += commentNotifications
            PrefManager.setVal(PrefName.UnreadCommentNotifications, 0)
            Anilist.unreadNotificationCount = 0
        }
        return res
    }

    suspend fun getFeed(
        userId: Int?,
        global: Boolean = false,
        page: Int = 1,
        activityId: Int? = null
    ): FeedResponse? {
        val filter = if (activityId != null) "id:$activityId,"
        else if (userId != null) "userId:$userId,"
        else if (global) "isFollowing:false,hasRepliesOrTypeText:true,"
        else "isFollowing:true,"
        val typeIn =
            if (filter == "isFollowing:true,") "type_in:[TEXT,ANIME_LIST,MANGA_LIST,MEDIA_LIST]," else ""
        return executeQuery<FeedResponse>(
            """{Page(page:$page,perPage:$ITEMS_PER_PAGE){pageInfo{hasNextPage}activities(${filter}${typeIn}sort:ID_DESC){__typename ... on TextActivity{id userId type replyCount text(asHtml:true)siteUrl isLocked isSubscribed likeCount isLiked isPinned createdAt user{id name bannerImage avatar{medium large}}replies{id userId activityId text(asHtml:true)likeCount isLiked createdAt user{id name bannerImage avatar{medium large}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}... on ListActivity{id userId type replyCount status progress siteUrl isLocked isSubscribed likeCount isLiked isPinned createdAt user{id name bannerImage avatar{medium large}}media{id title{english romaji native userPreferred}bannerImage coverImage{medium large}isAdult}replies{id userId activityId text(asHtml:true)likeCount isLiked createdAt user{id name bannerImage avatar{medium large}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}... on MessageActivity{id recipientId messengerId type replyCount likeCount message(asHtml:true)isLocked isSubscribed isLiked isPrivate siteUrl createdAt recipient{id name bannerImage avatar{medium large}}messenger{id name bannerImage avatar{medium large}}replies{id userId activityId text(asHtml:true)likeCount isLiked createdAt user{id name bannerImage avatar{medium large}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}}}}""",
            force = true
        )
    }

    suspend fun getReplies(
        activityId: Int,
        page: Int = 1
    ): ReplyResponse? {
        val query =
            """{Page(page:$page,perPage:50){activityReplies(activityId:$activityId){id userId activityId text(asHtml:true)likeCount isLiked createdAt user{id name bannerImage avatar{medium large}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}}}"""
        return executeQuery(query, force = true)
    }

    private fun statusActivityFields(): String {
        return """__typename ... on TextActivity{id userId type replyCount text(asHtml:true)siteUrl isLocked isSubscribed likeCount isLiked createdAt user{id name bannerImage avatar{medium large}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}... on ListActivity{id userId type replyCount status progress siteUrl isLocked isSubscribed likeCount isLiked isPinned createdAt user{id name bannerImage avatar{medium large}}media{id isAdult title{english romaji native userPreferred}bannerImage coverImage{large extraLarge}}likes{id name isFollowing isFollower bannerImage avatar{medium large}}}... on MessageActivity{id type createdAt likes{id name isFollowing isFollower bannerImage avatar{medium large}}}"""
    }

    private fun status(page: Int = 1): String {
        return """Page(page:$page,perPage:25){activities(isFollowing: true,type_in:[TEXT,ANIME_LIST,MANGA_LIST,MEDIA_LIST],sort:ID_DESC){${statusActivityFields()}}}"""
    }

    private fun myStatus(): String {
        val uid = Anilist.userid ?: return ""
        return """MyActivities:Page(page:1,perPage:25){activities(userId:$uid,type_in:[TEXT,ANIME_LIST,MANGA_LIST,MEDIA_LIST],sort:ID_DESC){${statusActivityFields()}}}"""
    }

    suspend fun getUpcomingAnime(id: String): List<Media> {
        val res = executeQuery<Query.MediaListCollection>(
            """{MediaListCollection(userId:$id,type:ANIME){lists{name entries{media{id,type, isFavourite,title{userPreferred,romaji}coverImage{medium}nextAiringEpisode{episode,timeUntilAiring}}}}}}""",
            force = true
        )
        val list = mutableListOf<Media>()
        res?.data?.mediaListCollection?.lists?.forEach { listEntry ->
            listEntry.entries?.forEach { entry ->
                entry.media?.nextAiringEpisode?.timeUntilAiring?.let {
                    list.add(Media(entry.media!!))
                }
            }
        }
        return list.sortedBy { it.timeUntilAiring }
            .distinctBy { it.id }
            .filter { it.timeUntilAiring != null }
    }

    suspend fun isUserFav(
        favType: AnilistMutations.FavType,
        id: Int
    ): Boolean {   //anilist isFavourite is broken, so we need to check it manually
        val res = getUserProfile(Anilist.userid ?: return false)
        return when (favType) {
            AnilistMutations.FavType.ANIME -> res?.data?.user?.favourites?.anime?.nodes?.any { it.id == id }
                ?: false

            AnilistMutations.FavType.MANGA -> res?.data?.user?.favourites?.manga?.nodes?.any { it.id == id }
                ?: false

            AnilistMutations.FavType.CHARACTER -> res?.data?.user?.favourites?.characters?.nodes?.any { it.id == id }
                ?: false

            AnilistMutations.FavType.STAFF -> res?.data?.user?.favourites?.staff?.nodes?.any { it.id == id }
                ?: false

            AnilistMutations.FavType.STUDIO -> res?.data?.user?.favourites?.studios?.nodes?.any { it.id == id }
                ?: false
        }
    }

    suspend fun getThreads(
        categoryId: Int? = null,
        mediaCategoryId: Int? = null,
        search: String? = null,
        sort: String = "ID_DESC",
        page: Int = 1
    ): ani.dantotsu.connections.anilist.api.ForumThreadsResponse? {
        val categoryArg = if (categoryId != null) ", categoryId: $categoryId" else ""
        val mediaCategoryArg = if (mediaCategoryId != null) ", mediaCategoryId: $mediaCategoryId" else ""
        val searchArg = if (!search.isNullOrBlank()) ", search: \"$search\"" else ""
        val query = """{Page(page:$page,perPage:25){pageInfo{hasNextPage currentPage}threads(sort:[$sort] $categoryArg $mediaCategoryArg $searchArg){id title body userId replyCount viewCount isLocked isSticky isSubscribed isLiked likeCount createdAt updatedAt siteUrl user{id name avatar{medium large}bannerImage}categories{id name}mediaCategories{id title{userPreferred}coverImage{medium}}}}}"""
        return executeQuery(query, force = true)
    }

    suspend fun getThreadDetails(threadId: Int): ani.dantotsu.connections.anilist.api.ForumThreadsResponse? {
        val query = """{Thread(id:$threadId){id title body userId replyCount viewCount isLocked isSticky isSubscribed isLiked likeCount createdAt updatedAt siteUrl user{id name avatar{medium large}bannerImage}categories{id name}mediaCategories{id title{userPreferred}coverImage{medium}}}}"""
        return executeQuery(query, force = true)
    }

    suspend fun getThreadComments(threadId: Int, page: Int = 1): ani.dantotsu.connections.anilist.api.ThreadCommentsResponse? {
        val query = """{Page(page:$page,perPage:25){pageInfo{hasNextPage currentPage}threadComments(threadId:$threadId){id userId threadId comment isLocked isLiked likeCount createdAt updatedAt siteUrl user{id name avatar{medium large}bannerImage}childComments}}}"""
        return executeQuery(query, force = true)
    }

    suspend fun getMediaCharacters(mediaId: Int, page: Int = 1): Query.Media? {
        val query = """{Media(id:$mediaId){characters(sort:[ROLE,FAVOURITES_DESC],page:$page,perPage:25){pageInfo{hasNextPage currentPage}edges{role voiceActors{id name{userPreferred}image{medium large}languageV2}node{id name{userPreferred}image{medium large}isFavourite}}}}}"""
        return executeQuery(query, force = true)
    }

    suspend fun getMediaStaff(mediaId: Int, page: Int = 1): Query.Media? {
        val query = """{Media(id:$mediaId){staff(sort:[RELEVANCE,ID],page:$page,perPage:25){pageInfo{hasNextPage currentPage}edges{role node{id name{userPreferred}image{medium large}}}}}}"""
        return executeQuery(query, force = true)
    }

    suspend fun getUserRawBio(userId: Int): String? {
        val query = """{User(id:$userId){about(asHtml:false)}}"""
        val res = executeQuery<UserBioResponse>(query, force = true)
        return res?.data?.user?.about
    }
}

@kotlinx.serialization.Serializable
data class UserBioResponse(
    @kotlinx.serialization.SerialName("data")
    val data: Data? = null
) : java.io.Serializable {
    @kotlinx.serialization.Serializable
    data class Data(
        @kotlinx.serialization.SerialName("User")
        val user: BioUser? = null
    ) : java.io.Serializable {
        @kotlinx.serialization.Serializable
        data class BioUser(
            @kotlinx.serialization.SerialName("about")
            val about: String? = null
        ) : java.io.Serializable
    }
}

