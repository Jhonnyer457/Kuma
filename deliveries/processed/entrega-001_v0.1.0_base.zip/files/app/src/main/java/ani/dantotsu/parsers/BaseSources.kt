package ani.dantotsu.parsers

import ani.dantotsu.Lazier
import ani.dantotsu.media.Media
import ani.dantotsu.media.anime.Episode
import ani.dantotsu.media.anime.EpisodeStorage
import ani.dantotsu.media.manga.ChapterStorage
import ani.dantotsu.media.manga.MangaChapter
import ani.dantotsu.tryWithSuspend
import ani.dantotsu.util.Logger
import eu.kanade.tachiyomi.animesource.model.SAnime
import eu.kanade.tachiyomi.source.model.SManga

abstract class WatchSources : BaseSources() {

    override operator fun get(i: Int): AnimeParser {
        return (list.getOrNull(i) ?: list.firstOrNull())?.get?.value as? AnimeParser
            ?: EmptyAnimeParser()
    }

    fun isDownloadedSource(i: Int): Boolean {
        return get(i) is OfflineAnimeParser
    }

    suspend fun loadEpisodesFromMedia(
        i: Int,
        media: Media,
        invalidate: Boolean = false,
        onCachedLoaded: ((MutableMap<String, Episode>) -> Unit)? = null
    ): MutableMap<String, Episode> {
        return tryWithSuspend(true) {
            val parser = get(i)
            val sourceKey = parser.saveName.ifBlank { parser.name }

            var cached: MutableMap<String, Episode>? = null
            if (!invalidate && parser !is OfflineAnimeParser) {
                val savedResponse = parser.loadSavedShowResponse(media.id)
                if (savedResponse != null && savedResponse.link.isNotBlank()) {
                    cached = EpisodeStorage.loadEpisodes(sourceKey, savedResponse.link)
                    if (!cached.isNullOrEmpty()) {
                        onCachedLoaded?.invoke(cached)
                    }
                }
            }

            val res = parser.autoSearch(media) ?: return@tryWithSuspend cached ?: mutableMapOf()
            if (cached.isNullOrEmpty() && !invalidate && parser !is OfflineAnimeParser) {
                cached = EpisodeStorage.loadEpisodes(sourceKey, res.link)
                if (!cached.isNullOrEmpty()) {
                    onCachedLoaded?.invoke(cached)
                }
            }

            val loaded = tryWithSuspend(true) {
                loadEpisodes(i, res.link, res.extra, res.sAnime)
            } ?: mutableMapOf()

            if (loaded.isNotEmpty() && parser !is OfflineAnimeParser) {
                EpisodeStorage.saveEpisodes(sourceKey, res.link, loaded)
                loaded
            } else {
                cached ?: loaded
            }
        } ?: mutableMapOf()
    }

    suspend fun loadEpisodes(
        i: Int,
        showLink: String,
        extra: Map<String, String>?,
        sAnime: SAnime?
    ): MutableMap<String, Episode> {
        val map = mutableMapOf<String, Episode>()
        val parser = get(i)
        val actualAnime = sAnime ?: SAnime.create().apply {
            url = showLink
            title = ""
        }
        tryWithSuspend(true) {
            parser.loadEpisodes(showLink, extra, actualAnime).forEach {
                val key = if (it.sEpisode?.scanlator.isNullOrBlank()) it.number else "${it.number}-${it.sEpisode?.scanlator}"
                map[key] = Episode(
                    it.number,
                    it.link,
                    it.title,
                    it.description,
                    it.thumbnail,
                    it.isFiller,
                    extra = it.extra,
                    sEpisode = it.sEpisode
                )
            }
        }
        if (map.isNotEmpty() && parser !is OfflineAnimeParser) {
            val sourceKey = parser.saveName.ifBlank { parser.name }
            EpisodeStorage.saveEpisodes(sourceKey, showLink, map)
        }
        return map
    }
}

abstract class MangaReadSources : BaseSources() {

    override operator fun get(i: Int): MangaParser {
        return (list.getOrNull(i) ?: list.firstOrNull())?.get?.value as? MangaParser
            ?: EmptyMangaParser()
    }

    fun isDownloadedSource(i: Int): Boolean {
        return get(i) is OfflineMangaParser
    }

    suspend fun loadChaptersFromMedia(
        i: Int,
        media: Media,
        invalidate: Boolean = false,
        onCachedLoaded: ((MutableMap<String, MangaChapter>) -> Unit)? = null
    ): MutableMap<String, MangaChapter> {
        return tryWithSuspend(true) {
            val parser = get(i)
            val sourceKey = parser.saveName.ifBlank { parser.name }

            var cached: MutableMap<String, MangaChapter>? = null
            if (!invalidate && parser !is OfflineMangaParser) {
                val savedResponse = parser.loadSavedShowResponse(media.id)
                if (savedResponse != null && savedResponse.link.isNotBlank()) {
                    cached = ChapterStorage.loadChapters(sourceKey, savedResponse.link)
                    if (!cached.isNullOrEmpty()) {
                        onCachedLoaded?.invoke(cached)
                    }
                }
            }

            val res = parser.autoSearch(media) ?: return@tryWithSuspend cached ?: mutableMapOf()
            if (cached.isNullOrEmpty() && !invalidate && parser !is OfflineMangaParser) {
                cached = ChapterStorage.loadChapters(sourceKey, res.link)
                if (!cached.isNullOrEmpty()) {
                    onCachedLoaded?.invoke(cached)
                }
            }

            val loaded = tryWithSuspend(true) {
                loadChapters(i, res)
            } ?: mutableMapOf()

            if (loaded.isNotEmpty() && parser !is OfflineMangaParser) {
                ChapterStorage.saveChapters(sourceKey, res.link, loaded)
                loaded
            } else {
                cached ?: loaded
            }
        } ?: mutableMapOf()
    }

    suspend fun loadChapters(i: Int, show: ShowResponse): MutableMap<String, MangaChapter> {
        val map = mutableMapOf<String, MangaChapter>()
        val parser = get(i)
        val sManga = show.sManga ?: SManga.create().apply {
            url = show.link
            title = show.name
            thumbnail_url = show.coverUrl.url
        }

        tryWithSuspend(true) {
            parser.loadChapters(show.link, show.extra, sManga).forEach {
                map["${it.number}-${it.scanlator}"] = MangaChapter(it)
            }
        }
        if (map.isNotEmpty() && parser !is OfflineMangaParser) {
            val sourceKey = parser.saveName.ifBlank { parser.name }
            ChapterStorage.saveChapters(sourceKey, show.link, map)
        }
        return map
    }
}

abstract class NovelReadSources : BaseSources() {
    override operator fun get(i: Int): NovelParser? {
        return if (list.isNotEmpty()) {
            (list.getOrNull(i) ?: list[0]).get.value as NovelParser
        } else {
            return EmptyNovelParser()
        }
    }

}

class EmptyNovelParser : NovelParser() {
    override val name: String = "Empty"
    override val hostUrl: String = "Empty"
    override val saveName: String = "Empty"

    override val volumeRegex: Regex = Regex("")

    override suspend fun loadBook(link: String, extra: Map<String, String>?): Book {
        return Book("", "", null, emptyList())  // Return an empty Book object or some default value
    }

    override suspend fun search(query: String): List<ShowResponse> {
        return listOf() // Return an empty list or some default value
    }
}

abstract class BaseSources {
    abstract val list: List<Lazier<BaseParser>>

    val names: List<String> get() = list.map { it.name }

    fun flushText() {
        list.forEach {
            if (it.get.isInitialized())
                it.get.value?.showUserText = ""
        }
    }

    open operator fun get(i: Int): BaseParser? {
        return list[i].get.value
    }

    fun saveResponse(i: Int, mediaId: Int, response: ShowResponse) {
        get(i)?.saveShowResponse(mediaId, response, true)
    }
}