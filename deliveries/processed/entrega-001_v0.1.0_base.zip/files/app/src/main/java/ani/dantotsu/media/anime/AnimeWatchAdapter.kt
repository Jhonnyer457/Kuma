package ani.dantotsu.media.anime

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.NumberPicker
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.getString
import androidx.core.content.ContextCompat.startActivity
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import ani.dantotsu.FileUrl
import ani.dantotsu.R
import ani.dantotsu.currActivity
import ani.dantotsu.currContext
import ani.dantotsu.databinding.CustomDialogLayoutBinding
import ani.dantotsu.databinding.DialogLayoutBinding
import ani.dantotsu.databinding.ItemChipBinding
import ani.dantotsu.databinding.ItemMediaSourceBinding
import ani.dantotsu.displayTimer
import ani.dantotsu.isOnline
import ani.dantotsu.loadImage
import ani.dantotsu.media.Media
import ani.dantotsu.media.MediaDetailsActivity
import ani.dantotsu.media.MediaNameAdapter
import ani.dantotsu.media.SourceSearchDialogFragment
import ani.dantotsu.openSettings
import ani.dantotsu.others.LanguageMapper
import ani.dantotsu.others.webview.CookieCatcher
import ani.dantotsu.parsers.AnimeSources
import ani.dantotsu.parsers.DynamicAnimeParser
import ani.dantotsu.parsers.OfflineAnimeParser
import ani.dantotsu.parsers.WatchSources
import ani.dantotsu.px
import ani.dantotsu.settings.FAQActivity
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.snackString
import ani.dantotsu.toast
import ani.dantotsu.util.customAlertDialog
import com.google.android.material.chip.Chip
import eu.kanade.tachiyomi.animesource.online.AnimeHttpSource
import eu.kanade.tachiyomi.data.notification.Notifications.CHANNEL_SUBSCRIPTION_CHECK
import eu.kanade.tachiyomi.util.system.WebViewUtil
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch


class AnimeWatchAdapter(
    private val media: Media,
    private val fragment: AnimeWatchFragment,
    private val watchSources: WatchSources
) : RecyclerView.Adapter<AnimeWatchAdapter.ViewHolder>() {
    private var autoSelect = true
    var subscribe: MediaDetailsActivity.PopImageButton? = null
    private var _binding: ItemMediaSourceBinding? = null

    fun clearBinding() {
        _binding = null
        subscribe = null
    }

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        _binding = null
        subscribe = null
    }

    var options: List<String> = listOf()
        set(value) {
            field = value
            updateScanlatorDropdown()
        }
    var hiddenScanlators: MutableList<String> = mutableListOf()
    var scanlatorSelectionListener: ScanlatorSelectionListener? = null

    fun updateSelectedSource(newIndex: Int) {
        val b = _binding ?: return
        if (newIndex in 0 until watchSources.names.size) {
            val displayNames = watchSources.names.filter { it != "Local" }
            b.mediaSource.setAdapter(
                ArrayAdapter(
                    fragment.requireContext(),
                    R.layout.item_dropdown,
                    displayNames
                )
            )
            b.mediaSource.setText(watchSources.names[newIndex], false)
            watchSources[newIndex].apply {
                this.selectDub = media.selected!!.preferDub
                b.mediaSourceTitle.text = showUserText
                b.animeSourceDubbedCont.isVisible = isDubAvailableSeparately()
            }
            setLanguageList(0, newIndex)
        }
    }

    interface ScanlatorSelectionListener {
        fun onScanlatorsSelected()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val bind =
            ItemMediaSourceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(bind)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val binding = holder.binding
        _binding = binding

        setupHeaderControls(binding)
        val source = setupSourceAndDub(binding)
        setupActionButtons(binding, source)
        handleEpisodes()
        setupResetProgress(binding)
    }

    private fun setupHeaderControls(binding: ItemMediaSourceBinding) {
        binding.faqbutton.setOnClickListener {
            startActivity(
                fragment.requireContext(),
                Intent(fragment.requireContext(), FAQActivity::class.java),
                null
            )
        }
        // Youtube
        if (media.anime?.youtube != null && PrefManager.getVal(PrefName.ShowYtButton)) {
            binding.animeSourceYT.visibility = View.VISIBLE
            binding.animeSourceYT.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(media.anime.youtube))
                fragment.requireContext().startActivity(intent)
            }
        }

        // Wrong Title
        binding.mediaSourceSearch.setOnClickListener {
            SourceSearchDialogFragment().show(
                fragment.requireActivity().supportFragmentManager,
                null
            )
        }
        val offline = !isOnline(binding.root.context) || PrefManager.getVal(PrefName.OfflineMode)

        binding.mediaSourceNameContainer.isGone = offline
        binding.mediaSourceSettings.isGone = offline
        binding.mediaSourceSearch.isGone = offline
        binding.mediaSourceTitle.isGone = offline
    }

    private fun setupSourceAndDub(binding: ItemMediaSourceBinding): Int {
        binding.animeSourceDubbed.isChecked = media.selected!!.preferDub
        binding.animeSourceDubbedText.text =
            if (media.selected!!.preferDub) binding.root.context.getString(R.string.dubbed) else binding.root.context.getString(
                R.string.subbed
            )

        // PreferDub
        var changing = false
        binding.animeSourceDubbed.setOnCheckedChangeListener { _, isChecked ->
            binding.animeSourceDubbedText.text =
                if (isChecked) binding.root.context.getString(R.string.dubbed) else binding.root.context.getString(
                    R.string.subbed
                )
            if (!changing) fragment.onDubClicked(isChecked)
        }

        // Source Selection
        var source =
            media.selected!!.sourceIndex.let { if (it >= watchSources.names.size) 0 else it }
        setLanguageList(media.selected!!.langIndex, source)
        updateScanlatorDropdown()

        val displayNames = watchSources.names.filter { it != "Local" }
        binding.mediaSource.setAdapter(
            ArrayAdapter(
                fragment.requireContext(),
                R.layout.item_dropdown,
                displayNames
            )
        )

        if (watchSources.names.isNotEmpty() && source in watchSources.names.indices) {
            binding.mediaSource.setText(watchSources.names[source], false)
            watchSources[source].apply {
                this.selectDub = media.selected!!.preferDub
                binding.mediaSourceTitle.text = showUserText
                showUserTextListener = { MainScope().launch { binding.mediaSourceTitle.text = it } }
                binding.animeSourceDubbedCont.isVisible = isDubAvailableSeparately()
            }
        }
        binding.mediaSourceTitle.isSelected = true
        binding.mediaSource.setOnItemClickListener { _, _, i, _ ->
            val actualIndex = watchSources.names.indexOf(displayNames[i])
            val isOffline = watchSources.isDownloadedSource(actualIndex)
            fragment.onSourceChange(actualIndex).apply {
                binding.mediaSourceTitle.text = showUserText
                showUserTextListener = { MainScope().launch { binding.mediaSourceTitle.text = it } }
                changing = true
                binding.animeSourceDubbed.isChecked = selectDub
                changing = false
                binding.animeSourceDubbedCont.isVisible = isDubAvailableSeparately()
                source = actualIndex
                setLanguageList(0, actualIndex)
            }
            subscribeButton(false)
            fragment.loadEpisodes(actualIndex, isOffline)
        }

        binding.mediaSourceLanguage.setOnItemClickListener { _, _, i, _ ->
            // Check if 'extension' and 'selected' properties exist and are accessible
            (watchSources[source] as? DynamicAnimeParser)?.let { ext ->
                ext.sourceLanguage = i
                fragment.onLangChange(i)
                fragment.onSourceChange(media.selected!!.sourceIndex).apply {
                    binding.mediaSourceTitle.text = showUserText
                    showUserTextListener =
                        { MainScope().launch { binding.mediaSourceTitle.text = it } }
                    changing = true
                    binding.animeSourceDubbed.isChecked = selectDub
                    changing = false
                    binding.animeSourceDubbedCont.isVisible = isDubAvailableSeparately()
                    setLanguageList(i, source)
                }
                subscribeButton(false)
                fragment.loadEpisodes(media.selected!!.sourceIndex, true)
            } ?: run { }
        }

        // Settings
        binding.mediaSourceSettings.setOnClickListener {
            (watchSources[source] as? DynamicAnimeParser)?.let { ext ->
                fragment.openSettings(ext.extension)
            }
        }
        return source
    }

    private fun setupActionButtons(binding: ItemMediaSourceBinding, source: Int) {
        // Subscribe
        subscribe = MediaDetailsActivity.PopImageButton(
            fragment.lifecycleScope,
            binding.mediaSourceSubscribe,
            R.drawable.ic_round_notifications_active_24,
            R.drawable.ic_round_notifications_none_24,
            R.color.bg_opp,
            R.color.violet_400,
            fragment.subscribed,
            true
        ) {
            fragment.onNotificationPressed(it, binding.mediaSource.text.toString())
        }

        subscribeButton(false)

        binding.mediaSourceSubscribe.setOnLongClickListener {
            openSettings(fragment.requireContext(), CHANNEL_SUBSCRIPTION_CHECK)
        }

        // Play via Torrent / Magnet Button
        binding.mediaTorrentButton.setOnClickListener {
            fragment.openDirectTorrent()
        }
        binding.mediaTorrentButton.setOnLongClickListener {
            toast(fragment.getString(R.string.play_via_torrent_magnet))
            true
        }

        // Nested Button
        binding.mediaNestedButton.setOnClickListener {
            showNestedOptionsDialog(source)
        }
    }

    private fun setupResetProgress(binding: ItemMediaSourceBinding) {
        //clear progress
        binding.sourceTitle.setOnLongClickListener {
            showResetProgressDialog()
            true
        }
    }

    private fun showResetProgressDialog() {
        fragment.requireContext().customAlertDialog().apply {
            setTitle(" Delete Progress for all episodes of ${media.nameRomaji}")
            setMessage("This will delete all the locally stored progress for all episodes")
            setPosButton(R.string.ok) {
                val prefix = "${media.id}_"
                val regex = Regex("^${prefix}\\d+$")

                PrefManager.getAllCustomValsForMedia(prefix)
                    .keys
                    .filter { it.matches(regex) }
                    .onEach { key -> PrefManager.removeCustomVal(key) }
                snackString("Deleted the progress of all Episodes for ${media.nameRomaji}")
            }
            setNegButton(R.string.no)
            show()
        }
    }

    private fun showNestedOptionsDialog(source: Int) {
        val dialogBinding = DialogLayoutBinding.inflate(fragment.layoutInflater)
        dialogBinding.apply {
            var refresh = false
            var run = false
            var reversed = media.selected!!.recyclerReversed
            var style =
                media.selected!!.recyclerStyle ?: PrefManager.getVal(PrefName.AnimeDefaultView)

            setupSortControls(dialogBinding) {
                reversed = !reversed
                run = true
                reversed
            }

            setupMetadataControls(dialogBinding) {
                refresh = true
            }

            setupStyleControls(dialogBinding, style) { selectedStyle ->
                style = selectedStyle
                run = true
            }

            setupWebviewContainer(dialogBinding, source) {
                refresh = true
            }

            setupDownloadAndProgressControls(dialogBinding)

            fragment.requireContext().customAlertDialog().apply {
                setTitle("Options")
                setCustomView(dialogBinding.root)
                setPosButton("OK") {
                    if (run) fragment.onIconPressed(style, reversed)
                    if (downloadNo.text.toString() != "0") {
                        fragment.multiDownload(n = downloadNo.text.toString().toInt())
                    }
                    if (refresh) fragment.loadEpisodes(source, true)
                }
                setNegButton("Cancel") {
                    if (refresh) fragment.loadEpisodes(source, true)
                }
                show()
            }
        }
    }

    private fun setupSortControls(
        dialogBinding: DialogLayoutBinding,
        onToggleSort: () -> Boolean
    ) {
        dialogBinding.apply {
            val initialReversed = media.selected!!.recyclerReversed
            mediaSourceTop.rotation = if (initialReversed) -90f else 90f
            sortText.text = if (initialReversed) "Down to Up" else "Up to Down"
            mediaSourceTop.setOnClickListener {
                val newReversed = onToggleSort()
                mediaSourceTop.rotation = if (newReversed) -90f else 90f
                sortText.text = if (newReversed) "Down to Up" else "Up to Down"
            }
        }
    }

    private fun setupMetadataControls(
        dialogBinding: DialogLayoutBinding,
        onRefreshNeeded: () -> Unit
    ) {
        dialogBinding.apply {
            var metadataApi = PrefManager.getVal<Int>(PrefName.EpisodeMetadataSource) // 0 or 1
            metadataApiText.text = if (metadataApi == 0) "Kitsu" else "AniZip"
            metadataApiTop.setOnClickListener {
                metadataApi = if (metadataApi == 0) 1 else 0
                metadataApiText.text = if (metadataApi == 0) "Kitsu" else "AniZip"
                PrefManager.setVal(PrefName.EpisodeMetadataSource, metadataApi)

                if (metadataApi == 0) {
                    fragment.loadKitsuEpisodesAsync()
                }
                onRefreshNeeded()
            }
        }
    }

    private fun setupStyleControls(
        dialogBinding: DialogLayoutBinding,
        initialStyle: Int,
        onStyleSelected: (Int) -> Unit
    ) {
        dialogBinding.apply {
            var selected = when (initialStyle) {
                0 -> mediaSourceList
                1 -> mediaSourceGrid
                2 -> mediaSourceCompact
                else -> mediaSourceList
            }
            when (initialStyle) {
                0 -> layoutText.setText(R.string.list)
                1 -> layoutText.setText(R.string.grid)
                2 -> layoutText.setText(R.string.compact)
                else -> mediaSourceList
            }
            selected.alpha = 1f
            fun selectButton(btn: ImageButton) {
                selected.alpha = 0.33f
                selected = btn
                selected.alpha = 1f
            }
            mediaSourceList.setOnClickListener {
                selectButton(it as ImageButton)
                layoutText.setText(R.string.list)
                onStyleSelected(0)
            }
            mediaSourceGrid.setOnClickListener {
                selectButton(it as ImageButton)
                layoutText.setText(R.string.grid)
                onStyleSelected(1)
            }
            mediaSourceCompact.setOnClickListener {
                selectButton(it as ImageButton)
                layoutText.setText(R.string.compact)
                onStyleSelected(2)
            }
        }
    }

    private fun setupWebviewContainer(
        dialogBinding: DialogLayoutBinding,
        source: Int,
        onRefreshNeeded: () -> Unit
    ) {
        dialogBinding.apply {
            mediaWebviewContainer.setOnClickListener {
                if (!WebViewUtil.supportsWebView(fragment.requireContext())) {
                    toast(R.string.webview_not_installed)
                }
                // Start CookieCatcher activity
                if (watchSources.names.isNotEmpty() && source in 0 until watchSources.names.size) {
                    val sourceAHH = watchSources[source] as? DynamicAnimeParser
                    val sourceHttp =
                        sourceAHH?.extension?.sources?.firstOrNull() as? AnimeHttpSource
                    val url = sourceHttp?.baseUrl
                    url?.let {
                        onRefreshNeeded()
                        val headersMap = try {
                            sourceHttp.headers.toMultimap()
                                .mapValues { it.value.getOrNull(0) ?: "" }
                        } catch (e: Exception) {
                            emptyMap()
                        }
                        val intent =
                            Intent(fragment.requireContext(), CookieCatcher::class.java)
                                .putExtra("url", url)
                                .putExtra("headers", headersMap as HashMap<String, String>)
                        startActivity(fragment.requireContext(), intent, null)
                    }
                }
            }
        }
    }

    private fun setupDownloadAndProgressControls(dialogBinding: DialogLayoutBinding) {
        dialogBinding.apply {
            //implement Multi download
            downloadNo.setText("0")
            if (media.format == "LOCAL") {
                animeDownloadContainer.visibility = View.GONE
                mediaWebviewContainer.visibility = View.GONE
            }
            mediaDownloadTop.setOnClickListener {
                // Alert dialog asking for the number of Episodes to download
                fragment.requireContext().customAlertDialog().apply {
                    setTitle("Multi Episode Downloader")
                    setMessage("Enter the number of episodes to download")
                    val input = NumberPicker(currContext())
                    input.minValue = 1
                    input.maxValue = 20
                    input.value = 1
                    setCustomView(input)
                    setPosButton(R.string.ok) {
                        downloadNo.setText("${input.value}")
                    }
                    setNegButton(R.string.cancel)
                    show()
                }
            }

            resetProgress.setOnClickListener {
                showResetProgressDialog()
            }

            resetProgressDef.text = getString(currContext()!!, R.string.clear_stored_episode)
        }
    }

    fun subscribeButton(enabled: Boolean) {
        subscribe?.enabled(enabled)
    }

    // Chips
    fun updateChips(limit: Int, names: Array<String>, arr: Array<Int>, selected: Int = 0) {
        val binding = _binding
        if (binding != null) {
            val screenWidth = fragment.screenWidth.px
            var select: Chip? = null
            for (position in arr.indices) {
                val last = if (position + 1 == arr.size) names.size else limit * (position + 1)
                val chip =
                    ItemChipBinding.inflate(
                        LayoutInflater.from(fragment.context),
                        binding.mediaSourceChipGroup,
                        false
                    ).root
                chip.isCheckable = true
                fun selected() {
                    chip.isChecked = true
                    binding.mediaWatchChipScroll.smoothScrollTo(
                        chip.left - screenWidth / 2 + chip.width / 2,
                        0
                    )
                }

                val startRaw = names[limit * position]
                val endRaw = names[last - 1]
                val startDisplay = MediaNameAdapter.findEpisodeNumber(startRaw)?.let {
                    if (it % 1 == 0f) it.toInt().toString() else it.toString()
                } ?: startRaw
                val endDisplay = MediaNameAdapter.findEpisodeNumber(endRaw)?.let {
                    if (it % 1 == 0f) it.toInt().toString() else it.toString()
                } ?: endRaw

                val chipText = "$startDisplay - $endDisplay"
                chip.text = chipText
                chip.setTextColor(
                    ContextCompat.getColorStateList(
                        fragment.requireContext(),
                        R.color.chip_text_color
                    )
                )

                chip.setOnClickListener {
                    selected()
                    fragment.onChipClicked(position, limit * position, last - 1)
                }
                binding.mediaSourceChipGroup.addView(chip)
                if (selected == position) {
                    selected()
                    select = chip
                }
            }
            if (select != null)
                binding.mediaWatchChipScroll.apply {
                    post {
                        scrollTo(
                            select.left - screenWidth / 2 + select.width / 2,
                            0
                        )
                    }
                }
        }
    }

    fun clearChips() {
        _binding?.mediaSourceChipGroup?.removeAllViews()
    }

    fun handleEpisodes() {
        val binding = _binding ?: return
        val animeEpisodes = media.anime?.episodes
        if (animeEpisodes.isNullOrEmpty()) {
            binding.sourceContinue.visibility = View.GONE
            binding.sourceNotFound.visibility = View.GONE
            binding.faqbutton.visibility = View.GONE
            clearChips()
            binding.sourceProgressBar.visibility = View.VISIBLE
            return
        }

        val episodes = animeEpisodes.keys.toTypedArray()
        if (isUserProgressFinished(episodes)) {
            binding.sourceContinue.visibility = View.GONE
            binding.sourceProgressBar.visibility = View.GONE
            return
        }

        val continueEp = resolveContinueEpisodeKey(episodes)
        if (continueEp != null && continueEp in episodes) {
            bindContinueEpisode(binding, continueEp)
        } else {
            binding.sourceContinue.visibility = View.GONE
        }

        binding.sourceProgressBar.visibility = View.GONE
        updateSourceNotFoundState(binding)
    }

    private fun isUserProgressFinished(episodes: Array<String>): Boolean {
        val userProgress = media.userProgress ?: return false
        val appEp = PrefManager.getCustomVal<String?>(
            "${media.id}_current_ep", ""
        )?.let { MediaNameAdapter.findEpisodeNumber(it)?.toInt() ?: it.toIntOrNull() } ?: 1

        val maxAvailableEp = episodes.maxOfOrNull { key ->
            MediaNameAdapter.findEpisodeNumber(key)
                ?: media.anime?.episodes?.get(key)?.number?.let { MediaNameAdapter.findEpisodeNumber(it) }
                ?: 0f
        } ?: episodes.size.toFloat()

        return userProgress.toFloat() >= maxAvailableEp && userProgress >= appEp
    }

    private fun checkAppEpHasActiveProgress(episodes: Array<String>, appEp: Int): Boolean {
        val appEpKey = episodes.find { key ->
            val epObj = media.anime?.episodes?.get(key)
            MediaNameAdapter.findEpisodeNumber(key)?.toInt() == appEp ||
                    (epObj?.number != null && MediaNameAdapter.findEpisodeNumber(epObj.number)?.toInt() == appEp)
        } ?: episodes.getOrNull(appEp - 1) ?: return false

        val cleanNum = MediaNameAdapter.findEpisodeNumber(appEpKey)?.let {
            if (it % 1 == 0f) it.toInt().toString() else it.toString()
        }
        val curr = PrefManager.getNullableCustomVal("${media.id}_${appEpKey}", null, Long::class.java)
            ?: cleanNum?.let { PrefManager.getNullableCustomVal("${media.id}_${it}", null, Long::class.java) }
        val max = PrefManager.getNullableCustomVal("${media.id}_${appEpKey}_max", null, Long::class.java)
            ?: cleanNum?.let { PrefManager.getNullableCustomVal("${media.id}_${it}_max", null, Long::class.java) }
        return if (curr != null && max != null && max > 0L) {
            curr.toFloat() / max.toFloat() < PrefManager.getVal<Float>(PrefName.WatchPercentage)
        } else false
    }

    private fun findMatchingEpisodeKey(episodes: Array<String>, targetEpNum: Float): String? {
        val directMatch = episodes.find { key ->
            val epObj = media.anime?.episodes?.get(key)
            MediaNameAdapter.findEpisodeNumber(key) == targetEpNum ||
                    (epObj?.number != null && MediaNameAdapter.findEpisodeNumber(epObj.number) == targetEpNum)
        }
        if (directMatch != null) return directMatch
        val targetIdx = targetEpNum.toInt() - 1
        return if (targetIdx in episodes.indices) episodes[targetIdx] else null
    }

    private fun advanceContinueEpisodeIfWatched(
        binding: ItemMediaSourceBinding,
        episodes: Array<String>,
        continueEp: String
    ): String? {
        handleProgress(
            binding.itemMediaProgressCont,
            binding.itemMediaProgress,
            binding.itemMediaProgressEmpty,
            media.id,
            continueEp
        )
        val progressWeight = (binding.itemMediaProgress.layoutParams as LinearLayout.LayoutParams).weight
        if (progressWeight <= PrefManager.getVal<Float>(PrefName.WatchPercentage)) {
            return continueEp
        }
        val nextIdx = episodes.indexOf(continueEp) + 1
        if (nextIdx !in episodes.indices) {
            return null
        }
        val nextEp = episodes[nextIdx]
        handleProgress(
            binding.itemMediaProgressCont,
            binding.itemMediaProgress,
            binding.itemMediaProgressEmpty,
            media.id,
            nextEp
        )
        return nextEp
    }

    private fun resolveContinueEpisodeKey(episodes: Array<String>): String? {
        val anilistEp = (media.userProgress ?: 0).plus(1)
        val appEp = PrefManager.getCustomVal<String?>(
            "${media.id}_current_ep", ""
        )?.let { MediaNameAdapter.findEpisodeNumber(it)?.toInt() ?: it.toIntOrNull() } ?: 1

        val appEpHasActiveProgress = checkAppEpHasActiveProgress(episodes, appEp)
        val targetEpNum = if (anilistEp > appEp && !appEpHasActiveProgress) anilistEp.toFloat() else appEp.toFloat()

        val matchingKey = findMatchingEpisodeKey(episodes, targetEpNum) ?: return null
        if (!episodes.contains(matchingKey)) return null

        val binding = _binding ?: return matchingKey
        return advanceContinueEpisodeIfWatched(binding, episodes, matchingKey)
    }

    private fun bindContinueEpisode(binding: ItemMediaSourceBinding, continueEp: String) {
        val ep = media.anime?.episodes?.get(continueEp) ?: return
        binding.sourceContinue.visibility = View.VISIBLE
        val cleanedTitle = ep.title?.let { MediaNameAdapter.removeEpisodeNumber(it) }

        binding.itemMediaImage.loadImage(
            ep.thumb ?: FileUrl[media.banner ?: media.cover], 0
        )
        if (ep.filler) binding.itemEpisodeFillerView.visibility = View.VISIBLE

        binding.mediaSourceContinueText.text =
            binding.root.context.getString(
                R.string.continue_episode, ep.number, if (ep.filler)
                    binding.root.context.getString(R.string.filler_tag)
                else
                    "", cleanedTitle
            )
        binding.sourceContinue.setOnClickListener {
            fragment.onEpisodeClick(continueEp)
        }
        if (fragment.continueEp) {
            if (
                (binding.itemMediaProgress.layoutParams as LinearLayout.LayoutParams)
                    .weight < PrefManager.getVal<Float>(PrefName.WatchPercentage)
            ) {
                binding.sourceContinue.performClick()
                fragment.continueEp = false
            }
        }
    }

    private fun updateSourceNotFoundState(binding: ItemMediaSourceBinding) {
        val sourceFound = media.anime?.episodes?.isNotEmpty() == true
        val isDownloadedSource =
            watchSources[media.selected!!.sourceIndex] is OfflineAnimeParser

        if (isDownloadedSource) {
            binding.sourceNotFound.text = if (sourceFound) {
                binding.root.context.getString(R.string.source_not_found)
            } else {
                binding.root.context.getString(R.string.download_not_found)
            }
        } else {
            binding.sourceNotFound.text =
                binding.root.context.getString(R.string.source_not_found)
        }

        binding.sourceNotFound.isGone = sourceFound
        binding.faqbutton.isGone = sourceFound

        if (!sourceFound && PrefManager.getVal(PrefName.SearchSources) && autoSelect) {
            tryAutoSelectNextSource(binding)
        }
        binding.mediaSource.setOnClickListener { autoSelect = false }
    }

    private fun tryAutoSelectNextSource(binding: ItemMediaSourceBinding) {
        if (binding.mediaSource.adapter.count > media.selected!!.sourceIndex + 1) {
            val nextIndex = media.selected!!.sourceIndex + 1
            binding.mediaSource.setText(
                binding.mediaSource.adapter
                    .getItem(nextIndex).toString(), false
            )
            fragment.onSourceChange(nextIndex).apply {
                binding.mediaSourceTitle.text = showUserText
                showUserTextListener =
                    { MainScope().launch { binding.mediaSourceTitle.text = it } }
                binding.animeSourceDubbed.isChecked = selectDub
                binding.animeSourceDubbedCont.isVisible = isDubAvailableSeparately()
                setLanguageList(0, nextIndex)
            }
            subscribeButton(false)
            fragment.loadEpisodes(nextIndex, false)
        }
    }

    private fun setLanguageList(lang: Int, source: Int) {
        val binding = _binding
        if (watchSources is AnimeSources) {
            val parser = watchSources[source] as? DynamicAnimeParser
            if (parser != null) {
                val languages = parser.extension.sources.map {
                    LanguageMapper.getLanguageName(it.lang)
                }
                if (languages.size > 1) {
                    binding?.mediaSourceLanguageContainer?.visibility = View.VISIBLE
                    binding?.mediaSourceLanguage?.setAdapter(
                        ArrayAdapter(
                            fragment.requireContext(),
                            R.layout.item_dropdown,
                            languages
                        )
                    )
                    binding?.mediaSourceLanguage?.setText(
                        languages.getOrNull(lang) ?: languages.first(),
                        false
                    )
                } else {
                    binding?.mediaSourceLanguageContainer?.visibility = View.GONE
                }
            } else {
                binding?.mediaSourceLanguageContainer?.visibility = View.GONE
            }
        }
    }

    fun updateScanlatorDropdown() {
        val binding = _binding ?: return
        if (options.size <= 1) {
            binding.mediaSourceScanlatorContainer.visibility = View.GONE
            return
        }

        binding.mediaSourceScanlatorContainer.visibility = View.VISIBLE
        binding.mediaSourceScanlatorContainer.hint = currActivity()?.getString(R.string.season)

        ensureInitialHiddenScanlators()

        val allText = currActivity()?.getString(R.string.all_seasons) ?: "All Seasons"
        val selectedText = determineActiveScanlatorLabel(allText)

        binding.mediaSourceScanlator.setText(selectedText, false)
        val adapter = ArrayAdapter(
            fragment.requireContext(),
            R.layout.item_dropdown,
            listOf(allText) + options
        )
        binding.mediaSourceScanlator.setAdapter(adapter)
        binding.mediaSourceScanlator.setOnItemClickListener { _, _, i, _ ->
            onScanlatorDropdownItemSelected(i)
        }
    }

    private fun ensureInitialHiddenScanlators() {
        if (media.selected?.scanlators == null && hiddenScanlators.isEmpty()) {
            val defaultSeason = options.firstOrNull()
            if (defaultSeason != null) {
                hiddenScanlators.addAll(options.filter { it != defaultSeason })
            }
        }
    }

    private fun determineActiveScanlatorLabel(allText: String): String {
        return if (hiddenScanlators.isEmpty() || hiddenScanlators.size >= options.size) {
            allText
        } else {
            options.firstOrNull { it !in hiddenScanlators } ?: allText
        }
    }

    private fun onScanlatorDropdownItemSelected(i: Int) {
        hiddenScanlators.clear()
        if (i > 0) {
            val selectedOption = options.getOrNull(i - 1)
            if (selectedOption != null) {
                hiddenScanlators.addAll(options.filter { it != selectedOption })
            }
        }
        fragment.onScanlatorChange(hiddenScanlators)
        scanlatorSelectionListener?.onScanlatorsSelected()
    }

    override fun getItemCount(): Int = 1

    inner class ViewHolder(val binding: ItemMediaSourceBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            displayTimer(media, binding.animeSourceContainer)
        }
    }
}
