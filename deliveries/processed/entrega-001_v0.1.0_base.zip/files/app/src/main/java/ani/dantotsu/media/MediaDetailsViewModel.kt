package ani.dantotsu.media

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ani.dantotsu.R
import ani.dantotsu.client
import ani.dantotsu.connections.anilist.Anilist
import ani.dantotsu.connections.mal.MAL
import ani.dantotsu.currContext
import ani.dantotsu.media.anime.Episode
import ani.dantotsu.media.anime.SelectorDialogFragment
import ani.dantotsu.media.anime.getEpisode
import ani.dantotsu.media.manga.MangaChapter
import ani.dantotsu.media.mangaupdates.MangaAnimeUtil
import ani.dantotsu.others.AniSkip
import ani.dantotsu.others.Anify
import ani.dantotsu.others.AniskipCsvFallback
import ani.dantotsu.others.IdMappers
import ani.dantotsu.others.IntroDbService
import ani.dantotsu.others.Jikan
import ani.dantotsu.others.Kitsu
import ani.dantotsu.others.TmdbService
import ani.dantotsu.media.novel.NovelStorage
import ani.dantotsu.parsers.AnimeSources
import ani.dantotsu.parsers.Book
import ani.dantotsu.parsers.MangaImage
import ani.dantotsu.parsers.MangaReadSources
import ani.dantotsu.parsers.MangaSources
import ani.dantotsu.parsers.NovelSources
import ani.dantotsu.parsers.OfflineAnimeParser
import ani.dantotsu.parsers.OfflineMangaParser
import ani.dantotsu.parsers.OfflineNovelParser
import ani.dantotsu.parsers.NovelParser
import ani.dantotsu.parsers.ShowResponse
import ani.dantotsu.parsers.VideoExtractor
import ani.dantotsu.parsers.WatchSources
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.snackString
import ani.dantotsu.tryWithSuspend
import ani.dantotsu.util.Logger
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation
import eu.kanade.tachiyomi.animesource.model.SAnime
import eu.kanade.tachiyomi.source.model.SManga
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.contentOrNull

class MediaDetailsViewModel : ViewModel() {
    val scrolledToTop = MutableLiveData(true)

    fun saveSelected(id: Int, data: Selected) {
        PrefManager.setCustomVal("Selected-$id", data)
    }


    fun loadSelected(media: Media, isDownload: Boolean = false): Selected {
        if ((media.format == "LOCAL" || media.format == "LOCAL_NOVEL") && media.selected != null) {
            return media.selected!!
        }
        val data =
            PrefManager.getNullableCustomVal("Selected-${media.id}", null, Selected::class.java)
                ?: Selected().let {
                    it.sourceIndex = 0
                    it.preferDub = PrefManager.getVal(PrefName.SettingsPreferDub)
                    saveSelected(media.id, it)
                    it
                }
        if (isDownload) {
            data.sourceIndex = when {
                media.anime != null -> {
                    AnimeSources.list.size - 1
                }

                media.format == "MANGA" || media.format == "ONE_SHOT" -> {
                    MangaSources.list.size - 1
                }

                else -> {
                    NovelSources.list.size - 1
                }
            }
        }
        return data
    }

    var continueMedia: Boolean? = null
    var loading = false

    private val media: MutableLiveData<Media> = MutableLiveData<Media>(null)
    fun getMedia(): LiveData<Media> = media
    fun loadMedia(m: Media) {
        if (!loading) {
            loading = true
            val rescueMode: Boolean = PrefManager.getVal(PrefName.RescueMode)
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                if (m.id == 0 && m.format?.startsWith("LOCAL") == true) {
                    loadLocalMedia(m)
                } else if (m.id == 0) {
                    m.folderName = m.folderName ?: m.name
                    media.postValue(m)
                } else if (rescueMode && m.idMAL != null) {
                    loadRescueMedia(m)
                } else if (rescueMode) {
                    media.postValue(m)
                } else {
                    media.postValue(Anilist.query.mediaDetails(m))
                }
                loading = false
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            resolveImdbId(m)
        }
    }

    private suspend fun loadLocalMedia(m: Media) {
        m.folderName = m.folderName ?: m.name
        media.postValue(m)

        val mapKeyStr = m.folderName ?: m.name ?: ""
        var mappedId = PrefManager.getCustomVal<Int>("local_mapping_$mapKeyStr", 0)
        if (mappedId == 0) {
            mappedId = searchLocalMappingId(m, mapKeyStr)
        }

        if (mappedId != 0) {
            val newMedia = m.copy(id = mappedId)
            val fetchedMedia = Anilist.query.mediaDetails(newMedia)
            fetchedMedia?.format = m.format

            // Cache
            fetchedMedia?.cover?.let { PrefManager.setCustomVal("local_cover_$mapKeyStr", it) }
            fetchedMedia?.banner?.let { PrefManager.setCustomVal("local_banner_$mapKeyStr", it) }

            fetchedMedia?.folderName = m.folderName ?: m.name
            fetchedMedia?.selected = m.selected
            media.postValue(fetchedMedia)
        }
    }

    private suspend fun searchLocalMappingId(m: Media, mapKeyStr: String): Int {
        return try {
            val searchType = if (m.manga != null) "MANGA" else "ANIME"
            val searchFormat = if (m.format == "LOCAL_NOVEL") "NOVEL" else null
            var results = Anilist.query.searchAniManga(searchType, search = m.name, format = searchFormat)
            if (results == null || results.results.isEmpty()) {
                if (m.folderName != null && m.folderName != m.name) {
                    results = Anilist.query.searchAniManga(searchType, search = m.folderName!!, format = searchFormat)
                }
            }
            if (results != null && results.results.isNotEmpty()) {
                val mappedId = results.results[0].id
                PrefManager.setCustomVal("local_mapping_$mapKeyStr", mappedId)
                mappedId
            } else {
                0
            }
        } catch (e: Exception) {
            ani.dantotsu.util.Logger.log(e)
            0
        }
    }

    private suspend fun loadRescueMedia(m: Media) {
        tryWithSuspend {
            val isAnime = m.anime != null
            val malId = m.idMAL!!
            val malNode = if (isAnime)
                MAL.query.getAnimeDetails(malId)
            else
                MAL.query.getMangaDetails(malId)
            val detailed = if (malNode != null) {
                Media(malNode, isAnime)
            } else {
                val jikanData = if (isAnime)
                    MAL.jikan.getAnimeById(malId)
                else
                    MAL.jikan.getMangaById(malId)
                if (jikanData != null) Media(jikanData, isAnime) else null
            }
            if (detailed != null) {
                copyUserDataToRescueMedia(detailed, m, isAnime, malId)
                enrichRescueModeDetails(detailed)
                media.postValue(detailed)
                launchBackgroundEnrichment(detailed)
            } else {
                media.postValue(m)
            }
        }
    }

    private fun copyUserDataToRescueMedia(target: Media, source: Media, isAnime: Boolean, malId: Int) {
        target.userProgress = source.userProgress ?: target.userProgress
        target.userStatus = source.userStatus ?: target.userStatus
        target.userScore = if (source.userScore != 0) source.userScore else target.userScore
        target.isListPrivate = source.isListPrivate
        target.userListId = source.userListId
        target.userRepeat = source.userRepeat
        target.userUpdatedAt = source.userUpdatedAt ?: target.userUpdatedAt
        target.userCompletedAt = source.userCompletedAt
        target.userStartedAt = source.userStartedAt
        target.cameFromContinue = source.cameFromContinue
        target.selected = source.selected
        target.isFav = source.isFav
        target.shareLink = "https://myanimelist.net/${if (isAnime) "anime" else "manga"}/$malId"
        if (isAnime) {
            target.anime?.episodes = source.anime?.episodes
        } else {
            target.manga?.chapters = source.manga?.chapters
        }
    }

    private suspend fun resolveImdbId(m: Media) {
        try {
            if (m.idIMDB == null) {
                m.idIMDB = if (PrefManager.getVal<Boolean>(PrefName.RescueMode)) {
                    m.idMAL?.let { ani.dantotsu.others.IdMappers.getImdbIdFromMal(it) }
                } else {
                    ani.dantotsu.others.IdMappers.getImdbId(m.id)
                }
            }
        } catch (e: Exception) {
            ani.dantotsu.util.Logger.log(e)
        }
    }

    private suspend fun enrichRescueModeDetails(media: Media) {
        val malId = media.idMAL ?: return
        supervisorScope {
            val isAnime = media.anime != null
            val fullDeferred = async {
                if (isAnime) MAL.jikan.getAnimeById(malId) else MAL.jikan.getMangaById(malId)
            }
            val charactersDeferred = async {
                if (isAnime) MAL.jikan.getAnimeCharacters(malId) else MAL.jikan.getMangaCharacters(malId)
            }
            val staffDeferred = async {
                if (isAnime) MAL.jikan.getAnimeStaff(malId) else emptyList()
            }
            val reviewsDeferred = async {
                if (isAnime) MAL.jikan.getAnimeReviews(malId) else MAL.jikan.getMangaReviews(malId)
            }
            val recommendationsDeferred = async {
                MAL.jikan.getRecommendations(isAnime, malId)
            }

            val fullData = fullDeferred.await()
            if (fullData != null) {
                mergeFullJikanDetails(media, fullData, isAnime)
            }

            val jRecommendations = try { recommendationsDeferred.await() } catch (_: Exception) { null }
            mergeJikanRecommendations(media, jRecommendations)
            mergeJikanCharacters(media, charactersDeferred.await())
            mergeJikanStaff(media, staffDeferred.await(), fullData, isAnime)

            mapJikanReviews(media, reviewsDeferred.await(), isAnime, malId)
        }
    }

    private fun mergeFullJikanDetails(
        media: Media,
        fullData: ani.dantotsu.connections.mal.JikanMediaData,
        isAnime: Boolean
    ) {
        val fullMapped = Media(fullData, isAnime)
        mergeBasicTextDetails(media, fullMapped)
        mergeBasicScoreAndMedia(media, fullMapped)
        mergeRelationsAndStaff(media, fullMapped)
        if (isAnime) {
            applyFullAnimeDetails(media, fullMapped)
        } else {
            fullMapped.manga?.author?.let { media.manga?.author = it }
        }
    }

    private fun mergeBasicTextDetails(media: Media, fullMapped: Media) {
        if (media.description.isNullOrBlank() && !fullMapped.description.isNullOrBlank()) {
            media.description = fullMapped.description
        }
        if (media.synonyms.isEmpty() && fullMapped.synonyms.isNotEmpty()) media.synonyms = fullMapped.synonyms
        if (media.genres.isEmpty() && fullMapped.genres.isNotEmpty()) media.genres = fullMapped.genres
        if (media.externalLinks.isNullOrEmpty() && !fullMapped.externalLinks.isNullOrEmpty()) {
            media.externalLinks = fullMapped.externalLinks
        }
    }

    private fun mergeBasicScoreAndMedia(media: Media, fullMapped: Media) {
        if ((media.meanScore == null || media.meanScore == 0) && fullMapped.meanScore != null) {
            media.meanScore = fullMapped.meanScore
        }
        if (media.source.isNullOrBlank() && !fullMapped.source.isNullOrBlank()) {
            media.source = fullMapped.source
        }
        if (media.trailer.isNullOrBlank() && !fullMapped.trailer.isNullOrBlank()) {
            media.trailer = fullMapped.trailer
        }
    }

    private fun mergeRelationsAndStaff(media: Media, fullMapped: Media) {
        if (!fullMapped.relations.isNullOrEmpty()) {
            if (media.relations.isNullOrEmpty() || (fullMapped.relations?.size ?: 0) > (media.relations?.size ?: 0)) {
                media.relations = fullMapped.relations
            }
            if (media.prequel == null) media.prequel = fullMapped.prequel
            if (media.sequel == null) media.sequel = fullMapped.sequel
        }
        if (!fullMapped.staff.isNullOrEmpty()) {
            media.staff = ArrayList(
                ((media.staff ?: arrayListOf()) + fullMapped.staff!!).distinctBy { it.id }
            )
        }
        if (!fullMapped.recommendations.isNullOrEmpty() &&
            (fullMapped.recommendations?.size ?: 0) > (media.recommendations?.size ?: 0)) {
            media.recommendations = fullMapped.recommendations
        }
    }

    private fun calculateNextAiringEpisode(watched: Int, estimated: Int?): Int? {
        return if (estimated != null) {
            if (watched > 0 && watched >= estimated + 1) watched else estimated
        } else {
            if (watched > 0) watched else null
        }
    }

    private fun applyFullAnimeDetails(media: Media, fullMapped: Media) {
        val anime = fullMapped.anime ?: return
        if (anime.op.isNotEmpty()) media.anime?.op = anime.op
        if (anime.ed.isNotEmpty()) media.anime?.ed = anime.ed
        if (media.anime?.mainStudio == null) {
            anime.mainStudio?.let { media.anime?.mainStudio = it }
        }
        if (media.anime?.producers.isNullOrEmpty() && !anime.producers.isNullOrEmpty()) {
            media.anime?.producers = anime.producers
        }
        if (media.anime?.season.isNullOrBlank()) anime.season?.let { media.anime?.season = it }
        if (media.anime?.seasonYear == null) anime.seasonYear?.let { media.anime?.seasonYear = it }
        if (media.anime?.nextAiringEpisodeTime == null && anime.nextAiringEpisodeTime != null) {
            media.anime?.nextAiringEpisodeTime = anime.nextAiringEpisodeTime
        }
        val watched = media.userProgress ?: 0
        calculateNextAiringEpisode(watched, anime.nextAiringEpisode)?.let {
            media.anime?.nextAiringEpisode = it
        }
    }

    private fun mergeJikanRecommendations(
        media: Media,
        jRecommendations: List<ani.dantotsu.connections.mal.JikanRecommendation>?
    ) {
        val mappedRecommendations = jRecommendations
            ?.mapNotNull { it.entry }
            ?.map {
                Media(
                    id = it.malId,
                    idMAL = it.malId,
                    name = it.title,
                    nameRomaji = it.title ?: "",
                    userPreferredName = it.title ?: "",
                    cover = it.images?.jpg?.largeImageUrl ?: it.images?.jpg?.imageUrl,
                    banner = it.images?.jpg?.largeImageUrl,
                    isAdult = false,
                    status = null,
                    meanScore = null,
                    popularity = null,
                    format = null,
                )
            }
            ?.distinctBy { it.id }
            ?.let { ArrayList(it) }

        if (!mappedRecommendations.isNullOrEmpty()) {
            if (media.recommendations.isNullOrEmpty() || mappedRecommendations.size > (media.recommendations?.size ?: 0)) {
                media.recommendations = mappedRecommendations
            }
        }
    }

    private fun mergeJikanCharacters(
        media: Media,
        jikanCharacters: List<ani.dantotsu.connections.mal.JikanAnimeCharacter>
    ) {
        val mappedCharacters = jikanCharacters
            .mapNotNull { jChar ->
                val character = jChar.character ?: return@mapNotNull null
                Character(
                    id = character.malId,
                    name = character.name,
                    image = character.images?.jpg?.largeImageUrl ?: character.images?.jpg?.imageUrl,
                    banner = media.banner ?: media.cover,
                    role = jChar.role ?: "",
                    isFav = false,
                    voiceActor = jChar.voiceActors
                        ?.mapNotNull { va ->
                            va.person?.let { person ->
                                Author(
                                    id = person.malId,
                                    name = person.name,
                                    image = person.images?.jpg?.largeImageUrl ?: person.images?.jpg?.imageUrl,
                                    role = va.language
                                )
                            }
                        }
                        ?.let { ArrayList(it) }
                )
            }
        if (mappedCharacters.isNotEmpty()) {
            media.characters = ArrayList(mappedCharacters.distinctBy { it.id })
        }
    }

    private fun mergeJikanStaff(
        media: Media,
        jikanStaff: List<ani.dantotsu.connections.mal.JikanStaffMember>,
        fullData: ani.dantotsu.connections.mal.JikanMediaData?,
        isAnime: Boolean
    ) {
        val mappedStaff = jikanStaff
            .mapNotNull { staff ->
                val person = staff.person ?: return@mapNotNull null
                Author(
                    id = person.malId,
                    name = person.name,
                    image = person.images?.jpg?.largeImageUrl ?: person.images?.jpg?.imageUrl,
                    role = staff.positions?.joinToString(", ")
                )
            }

        val mangaAuthors = if (!isAnime && fullData != null) {
            fullData.authors?.mapNotNull { author ->
                val person = author.person ?: return@mapNotNull null
                Author(
                    id = person.malId,
                    name = person.name,
                    image = person.images?.jpg?.largeImageUrl ?: person.images?.jpg?.imageUrl,
                    role = author.position
                )
            } ?: emptyList()
        } else emptyList()

        val allStaff = (mappedStaff + mangaAuthors).distinctBy { it.id }
        if (allStaff.isNotEmpty()) {
            media.staff = ArrayList(
                ((media.staff ?: arrayListOf()) + allStaff).distinctBy { it.id }
            )
        }
    }

    private fun launchBackgroundEnrichment(media: Media) {
        val malId = media.idMAL ?: return
        val isAnime = media.anime != null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                fetchRelationCovers(media, isAnime)

                enrichRecommendationDetails(media, isAnime)

                this@MediaDetailsViewModel.media.postValue(media)
            } catch (_: Exception) {}
        }
    }

    private data class EnrichedItemData(
        val coverUrl: String? = null,
        val score: Int? = null,
        val statusStr: String? = null,
        val episodesCount: Int? = null,
        val chaptersCount: Int? = null,
        val resolvedFmt: String? = null
    )

    private fun resolveJikanFormat(typeStr: String?, isAnime: Boolean): String {
        return when (typeStr) {
            "LIGHT NOVEL", "NOVEL" -> "NOVEL"
            "ONE-SHOT" -> "ONE_SHOT"
            "DOUJINSHI" -> "DOUJINSHI"
            "MANHWA" -> "MANHWA"
            "MANHUA" -> "MANHUA"
            else -> typeStr ?: if (isAnime) "TV" else "MANGA"
        }
    }

    private suspend fun fetchRemoteMediaInfo(malId: Int, isAnime: Boolean): EnrichedItemData? {
        val node = if (isAnime) MAL.query.getAnimeDetails(malId) else MAL.query.getMangaDetails(malId)
        if (node != null) {
            return EnrichedItemData(
                coverUrl = node.mainPicture?.large ?: node.mainPicture?.medium,
                score = ((node.mean ?: 0f) * 10f).toInt(),
                statusStr = node.status?.replace("_", " ")?.uppercase(java.util.Locale.US),
                episodesCount = node.numEpisodes,
                chaptersCount = node.numChapters,
                resolvedFmt = node.mediaType?.uppercase(java.util.Locale.US)
            )
        }
        val jikanNode = if (isAnime) MAL.jikan.getAnimeById(malId) else MAL.jikan.getMangaById(malId)
        if (jikanNode != null) {
            return EnrichedItemData(
                coverUrl = jikanNode.images?.jpg?.largeImageUrl ?: jikanNode.images?.jpg?.imageUrl,
                score = ((jikanNode.score ?: 0f) * 10f).toInt(),
                statusStr = jikanNode.status?.replace("_", " ")?.uppercase(java.util.Locale.US),
                episodesCount = jikanNode.episodes,
                chaptersCount = jikanNode.chapters,
                resolvedFmt = resolveJikanFormat(jikanNode.type?.uppercase(java.util.Locale.US), isAnime)
            )
        }
        return null
    }

    private suspend fun enrichRecommendationDetails(media: Media, isAnime: Boolean) {
        val recs = media.recommendations?.take(15) ?: return
        val recsToEnrich = recs.filter { rec ->
            rec.meanScore == null || rec.meanScore == 0 ||
            (rec.anime != null && rec.anime?.totalEpisodes == null) ||
            (rec.manga != null && rec.manga?.totalChapters == null)
        }
        if (recsToEnrich.isEmpty()) return
        kotlinx.coroutines.supervisorScope {
            val deferreds = recsToEnrich.map { rec ->
                async {
                    try {
                        val recMalId = rec.idMAL ?: return@async
                        val isRecAnime = rec.anime != null
                        val info = fetchRemoteMediaInfo(recMalId, isRecAnime) ?: return@async
                        applyEnrichedRecommendation(rec, info, isRecAnime)
                    } catch (_: Exception) {}
                }
            }
            deferreds.forEach { it.await() }
        }
        media.recommendations = ArrayList(recs)
    }

    private fun applyEnrichedRecommendation(rec: Media, info: EnrichedItemData, isRecAnime: Boolean) {
        info.coverUrl?.let { rec.cover = rec.cover ?: it }
        info.score?.let { rec.meanScore = it }
        info.statusStr?.let { rec.status = it }
        if (isRecAnime) {
            info.episodesCount?.let { rec.anime?.totalEpisodes = it }
        } else {
            info.chaptersCount?.let { rec.manga?.totalChapters = it }
        }
    }

    private fun mapJikanReviews(
        media: Media,
        jikanReviews: List<ani.dantotsu.connections.mal.JikanReview>,
        isAnime: Boolean,
        malId: Int
    ) {
        if (jikanReviews.isEmpty()) return
        val mapped = jikanReviews.mapNotNull { review ->
            val reviewText = review.review ?: return@mapNotNull null
            val summary = if (reviewText.length > 200) reviewText.take(200) + "…" else reviewText
            val userName = review.user?.username ?: "Anonymous"
            val userAvatar = review.user?.images?.jpg?.imageUrl
            val createdAt = try {
                java.time.Instant.parse(review.date ?: "").epochSecond.toInt()
            } catch (_: Exception) { 0 }
            ani.dantotsu.connections.anilist.api.Query.Review(
                id = review.malId,
                mediaId = malId,
                mediaType = if (isAnime) "ANIME" else "MANGA",
                summary = summary,
                body = reviewText,
                rating = review.reactions?.overall ?: 0,
                ratingAmount = review.reactions?.overall ?: 0,
                userRating = "NO_VOTE",
                score = (review.score ?: 0) * 10,
                private = false,
                siteUrl = review.url ?: "https://myanimelist.net",
                createdAt = createdAt,
                updatedAt = null,
                user = ani.dantotsu.connections.anilist.api.User(
                    id = review.malId,
                    name = userName,
                    avatar = ani.dantotsu.connections.anilist.api.UserAvatar(
                        large = userAvatar,
                        medium = userAvatar
                    ),
                    bannerImage = null,
                    isFollowing = null,
                    isFollower = null,
                    options = null,
                    mediaListOptions = null,
                    favourites = null,
                    statistics = null,
                    unreadNotificationCount = null,
                )
            )
        }
        if (mapped.isNotEmpty()) {
            media.review = ArrayList(mapped.take(5))
        }
    }

    private suspend fun fetchRelationCovers(media: Media, isAnime: Boolean) {
        val relationsToFetch = mutableListOf<Media>()
        media.prequel?.let { if (it.cover == null) relationsToFetch.add(it) }
        media.sequel?.let { if (it.cover == null) relationsToFetch.add(it) }
        media.relations?.forEach { rel ->
            if (rel.cover == null && !relationsToFetch.contains(rel)) relationsToFetch.add(rel)
        }
        if (relationsToFetch.isEmpty()) return

        kotlinx.coroutines.supervisorScope {
            val deferreds = relationsToFetch.take(8).map { rel ->
                async {
                    val relMalId = rel.idMAL ?: return@async
                    val relIsAnime = rel.anime != null || rel.relation?.contains("ANIME", true) == true
                            || rel.manga == null
                    try {
                        val info = fetchRemoteMediaInfo(relMalId, relIsAnime) ?: return@async
                        applyEnrichedRelation(rel, info, relIsAnime)
                    } catch (_: Exception) {}
                }
            }
            deferreds.forEach { it.await() }
        }
    }

    private fun applyEnrichedRelation(rel: Media, info: EnrichedItemData, relIsAnime: Boolean) {
        info.coverUrl?.let {
            rel.cover = it
            rel.banner = it
        }
        if (info.score != null && rel.meanScore == null) {
            rel.meanScore = info.score
        }
        if (info.statusStr != null && rel.status == null) {
            rel.status = info.statusStr
        }
        if (relIsAnime) {
            info.episodesCount?.let { rel.anime?.totalEpisodes = it }
        } else {
            info.chaptersCount?.let { rel.manga?.totalChapters = it }
        }
        if (info.resolvedFmt != null) {
            rel.format = info.resolvedFmt
            val rawRelation = rel.relation?.substringBefore("\n") ?: ""
            if (rawRelation.isNotEmpty()) {
                rel.relation = "$rawRelation\n${info.resolvedFmt}"
            }
        }
    }
    fun setMedia(m: Media) {
        media.postValue(m)

        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (m.idIMDB == null) {
                    m.idIMDB = if (PrefManager.getVal<Boolean>(PrefName.RescueMode)) {
                        m.idMAL?.let { ani.dantotsu.others.IdMappers.getImdbIdFromMal(it) }
                    } else {
                        ani.dantotsu.others.IdMappers.getImdbId(m.id)
                    }
                }
            } catch (e: Exception) {
                ani.dantotsu.util.Logger.log(e)
            }
        }
    }

    val responses = MutableLiveData<List<ShowResponse>?>(null)


    //Anime
    private val kitsuEpisodes: MutableLiveData<Map<String, Episode>> =
        MutableLiveData<Map<String, Episode>>(null)

    fun getKitsuEpisodes(): LiveData<Map<String, Episode>> = kitsuEpisodes
    suspend fun loadKitsuEpisodes(s: Media, force: Boolean = false) {
        tryWithSuspend {
            if (kitsuEpisodes.value == null || force) kitsuEpisodes.postValue(Kitsu.getKitsuEpisodesDetails(s))
        }
    }

    private val anifyEpisodes: MutableLiveData<Map<String, Episode>> =
        MutableLiveData<Map<String, Episode>>(null)

    fun getAnifyEpisodes(): LiveData<Map<String, Episode>> = anifyEpisodes
    suspend fun loadAnifyEpisodes(s: Media, force: Boolean = false) {
        tryWithSuspend {
            if (anifyEpisodes.value == null || force) {
                val anilistId = s.id.takeIf { it != 0 }
                val malId = s.idMAL
                var episodes = Anify.fetchAndParseMetadata(anilistId = anilistId, malId = malId)
                if (episodes.isEmpty()) {
                    val tmdbId = s.idTMDB?.toIntOrNull()
                        ?: runCatching { IdMappers.getIds(s.id)?.tmdbId }.getOrNull()
                    if (tmdbId != null && tmdbId > 0) {
                        val tmdbEpisodes = TmdbService.getEpisodeDetails(tmdbId)
                        if (!tmdbEpisodes.isNullOrEmpty()) {
                            episodes = tmdbEpisodes
                        }
                    }
                }
                anifyEpisodes.postValue(episodes)
            }
        }
    }
    suspend fun loadAnifyEpisodes(s: Int, force: Boolean = false) {
        tryWithSuspend {
            if (anifyEpisodes.value == null || force) anifyEpisodes.postValue(Anify.fetchAndParseMetadata(anilistId = s, malId = null))
        }
    }

    private val fillerEpisodes: MutableLiveData<Map<String, Episode>> =
        MutableLiveData<Map<String, Episode>>(null)

    fun getFillerEpisodes(): LiveData<Map<String, Episode>> = fillerEpisodes
    suspend fun loadFillerEpisodes(s: Media, force: Boolean = false) {
        tryWithSuspend {
            if (fillerEpisodes.value == null || force) fillerEpisodes.postValue(
                Jikan.getEpisodes(
                    s.idMAL ?: return@tryWithSuspend
                )
            )
        }
    }

    var watchSources: WatchSources? = null

    private val episodes = MutableLiveData<MutableMap<Int, MutableMap<String, Episode>>>(null)
    private val epsLoaded = mutableMapOf<Int, MutableMap<String, Episode>>()
    fun getEpisodes(): LiveData<MutableMap<Int, MutableMap<String, Episode>>> = episodes
    fun invalidateSource(sourceIndex: Int) {
        epsLoaded.remove(sourceIndex)
    }

    suspend fun loadEpisodes(media: Media, i: Int, invalidate: Boolean = false) {
        val isOffline = watchSources?.get(i) is OfflineAnimeParser
        val current = epsLoaded[i]
        if (current.isNullOrEmpty() || invalidate || isOffline) {
            val loaded = watchSources?.loadEpisodesFromMedia(
                i = i,
                media = media,
                invalidate = invalidate,
                onCachedLoaded = { cached ->
                    epsLoaded[i] = cached
                    episodes.postValue(epsLoaded)
                }
            ) ?: mutableMapOf()
            if (loaded.isNotEmpty() || invalidate) {
                epsLoaded[i] = loaded
            }
        }
        episodes.postValue(epsLoaded)
    }

    suspend fun forceLoadEpisode(media: Media, i: Int) {
        val loaded = watchSources?.loadEpisodesFromMedia(i, media, true) ?: mutableMapOf()
        if (loaded.isNotEmpty()) {
            epsLoaded[i] = loaded
        }
        episodes.postValue(epsLoaded)
    }

    suspend fun overrideEpisodes(i: Int, source: ShowResponse, id: Int) {
        if (source.sAnime == null) {
            source.sAnime = SAnime.create().apply {
                url = source.link
                title = source.name
                thumbnail_url = source.coverUrl.url
            }
        }
        watchSources?.saveResponse(i, id, source)
        epsLoaded[i] =
            watchSources?.loadEpisodes(i, source.link, source.extra, source.sAnime) ?: return
        episodes.postValue(epsLoaded)
    }

    private var episode = MutableLiveData<Episode?>(null)
    fun getEpisode(): LiveData<Episode?> = episode

    suspend fun loadEpisodeVideos(ep: Episode, i: Int, post: Boolean = true) {
        val link = ep.link ?: return
        if (!ep.allStreams || ep.extractors.isNullOrEmpty()) {
            val existingExtractors = ep.extractors?.toMutableList() ?: mutableListOf()
            val list = mutableListOf<VideoExtractor>()
            ep.extractors = list
            watchSources?.get(i)?.apply {
                if (!post && !allowsPreloading) return@apply
                ep.sEpisode?.let {
                    loadByVideoServers(link, ep.extra, it) { extractor ->
                        if (extractor.videos.isNotEmpty()) {
                            list.add(extractor)
                            ep.extractorCallback?.invoke(extractor)
                        }
                    }
                }
                ep.extractorCallback = null
                if (list.isNotEmpty())
                    ep.allStreams = true
                else if (existingExtractors.isNotEmpty())
                    ep.extractors = existingExtractors
            }
        }


        if (post) {
            episode.postValue(ep)
            MainScope().launch(Dispatchers.Main) {
                episode.value = null
            }
        }
    }

    val timeStamps = MutableLiveData<List<AniSkip.Stamp>?>()
    private val timeStampsMap: MutableMap<Int, List<AniSkip.Stamp>?> = mutableMapOf()
    suspend fun loadTimeStamps(
        malId: Int?,
        episodeNum: Int?,
        duration: Long,
        useProxyForTimeStamps: Boolean,
        extensionTimestamps: List<eu.kanade.tachiyomi.animesource.model.TimeStamp> = emptyList()
    ) {
        episodeNum ?: return
        if (timeStampsMap.containsKey(episodeNum) && !timeStampsMap[episodeNum].isNullOrEmpty()) {
            return timeStamps.postValue(timeStampsMap[episodeNum])
        }
        if (duration <= 0 && extensionTimestamps.isEmpty()) return

        // Extension timestamps take priority; fall back to AniSkip when the extension has none
        val result: List<AniSkip.Stamp>? = if (extensionTimestamps.isNotEmpty()) {
            extensionTimestamps.map { it.toAniSkipStamp() }
        } else {
            var stamps: List<AniSkip.Stamp>? = null
            // 1. Try Live AniSkip API
            if (malId != null) {
                stamps = AniSkip.getResult(malId, episodeNum, duration, useProxyForTimeStamps)
            }
            // 2. Try Offline AniSkip CSV Dump DB
            if (stamps.isNullOrEmpty() && malId != null) {
                val ctx = currContext()
                if (ctx != null) {
                    stamps = AniskipCsvFallback.getInstance(ctx).lookup(malId, episodeNum)
                }
            }
            // 3. Try IntroDB API Fallback
            if (stamps.isNullOrEmpty()) {
                val mediaVal = media.value
                val imdbId = mediaVal?.idIMDB ?: mediaVal?.id?.let { runCatching { IdMappers.getImdbId(it) }.getOrNull() }
                val tmdbId = mediaVal?.idTMDB?.toIntOrNull() ?: mediaVal?.id?.let { runCatching { IdMappers.getIds(it)?.tmdbId }.getOrNull() }
                val tvdbId = mediaVal?.id?.let { runCatching { IdMappers.getIds(it)?.tvdbId }.getOrNull() }
                stamps = IntroDbService.getSkipTimes(imdbId = imdbId, tmdbId = tmdbId, tvdbId = tvdbId, episode = episodeNum.toString())
            }
            stamps
        }
        if (result != null || duration > 0) {
            timeStampsMap[episodeNum] = result
        }
        timeStamps.postValue(result)
    }

    private fun eu.kanade.tachiyomi.animesource.model.TimeStamp.toAniSkipStamp(): AniSkip.Stamp {
        val skipType = when (type) {
            eu.kanade.tachiyomi.animesource.model.ChapterType.Opening -> "op"
            eu.kanade.tachiyomi.animesource.model.ChapterType.Ending -> "ed"
            eu.kanade.tachiyomi.animesource.model.ChapterType.Recap -> "recap"
            eu.kanade.tachiyomi.animesource.model.ChapterType.MixedOp -> "mixed-op"
            eu.kanade.tachiyomi.animesource.model.ChapterType.Other ->
                name.lowercase().replace(" ", "-").ifEmpty { "other" }
        }
        return AniSkip.Stamp(
            interval = AniSkip.AniSkipInterval(start, end),
            skipType = skipType,
            skipId = name,
            // episodeLength represents total episode duration; use 0.0 as a sentinel since
            // extension timestamps don't carry the full episode length
            episodeLength = 0.0
        )
    }

    suspend fun loadEpisodeSingleVideo(
        ep: Episode,
        selected: Selected,
        post: Boolean = true,
        selectedServerName: String? = null
    ): Boolean {

        val server = selectedServerName ?: selected.server ?: return false
        val link = ep.link ?: return false

        if (ep.extractors?.find { it.server.name == server || it.isPreferred } == null) {
            Log.d("AnimeDownloader", "Loading Video Server for episode: ${ep.number}, selected server: $server")
            if(ep.extractors == null){
                ep.extractors = mutableListOf(watchSources?.get(selected.sourceIndex)?.let {
                    selected.sourceIndex = selected.sourceIndex
                    if (!post && !it.allowsPreloading) null
                    else ep.sEpisode?.let { it1 ->
                        it.loadSingleVideoServer(
                            server, link, ep.extra,
                            it1, post
                        )
                    }
                } ?: return false)
            }
            else{
                ep.extractors!!.add(watchSources?.get(selected.sourceIndex)?.let {
                    selected.sourceIndex = selected.sourceIndex
                    if (!post && !it.allowsPreloading) null
                    else ep.sEpisode?.let { it1 ->
                        it.loadSingleVideoServer(
                            server, link, ep.extra,
                            it1, post
                        )
                    }
                } ?: return false)
            }
            //ep.extractors?.forEach { Log.d("AnimeDownloader", "Extractor episode ${ep.number}: ${it.server.name}") }
            ep.allStreams = false
        }
        if (post) {
            episode.postValue(ep)
            MainScope().launch(Dispatchers.Main) {
                episode.value = null
            }
        }
        return true
    }

    fun setEpisode(ep: Episode?, who: String) {
        Logger.log("set episode ${ep?.number} - $who")
        episode.postValue(ep)
        MainScope().launch(Dispatchers.Main) {
            episode.value = null
        }
    }

    val epChanged = MutableLiveData(true)
    fun onEpisodeClick(
        media: Media,
        i: String = "",
        manager: FragmentManager,
        launch: Boolean = true,
        prevEp: String? = null,
        isDownload: Boolean = false,
        episodes: ArrayList<String> = arrayListOf() // used for handling an array of episodes to download or to view a single episode
    ) {
        Handler(Looper.getMainLooper()).post {
            if (manager.findFragmentByTag("dialog") == null && !manager.isDestroyed && !manager.isStateSaved) {
                if(episodes.isEmpty()){
                    episodes.add(i)
                }
                for (ep in episodes){
                    if (media.anime?.episodes?.getEpisode(ep) == null) {
                        snackString(currContext()?.getString(R.string.episode_not_found, ep))
                        return@post
                    }
                }
                media.selected = this.loadSelected(media)
                val selector =
                    SelectorDialogFragment.newInstance(
                        media.selected!!.server,
                        launch,
                        prevEp,
                        isDownload,
                        episodes
                    )
                try {
                    val ft = manager.beginTransaction()
                    ft.add(selector, "dialog")
                    ft.commitAllowingStateLoss()
                } catch (e: Exception) {
                    Logger.log(e)
                }
            }
        }
    }

    //Manga
    var mangaReadSources: MangaReadSources? = null

    private val mangaChapters =
        MutableLiveData<MutableMap<Int, MutableMap<String, MangaChapter>>>(null)
    private val mangaLoaded = mutableMapOf<Int, MutableMap<String, MangaChapter>>()
    fun getMangaChapters(): LiveData<MutableMap<Int, MutableMap<String, MangaChapter>>> =
        mangaChapters

    fun invalidateMangaSource(sourceIndex: Int) {
        mangaLoaded.remove(sourceIndex)
    }

    suspend fun loadMangaChapters(media: Media, i: Int, invalidate: Boolean = false) {
        Logger.log("Loading Manga Chapters : $mangaLoaded")
        val isOffline = mangaReadSources?.get(i) is OfflineMangaParser
        val current = mangaLoaded[i]
        if (current.isNullOrEmpty() || invalidate || isOffline) tryWithSuspend {
            val loaded = mangaReadSources?.loadChaptersFromMedia(
                i = i,
                media = media,
                invalidate = invalidate,
                onCachedLoaded = { cached ->
                    mangaLoaded[i] = cached
                    mangaChapters.postValue(mangaLoaded)
                }
            ) ?: mutableMapOf()
            if (loaded.isNotEmpty() || invalidate) {
                mangaLoaded[i] = loaded
            }
        }
        mangaChapters.postValue(mangaLoaded)
    }

    suspend fun overrideMangaChapters(i: Int, source: ShowResponse, id: Int) {
        if (source.sManga == null) {
            source.sManga = SManga.create().apply {
                url = source.link
                title = source.name
                thumbnail_url = source.coverUrl.url
            }
        }
        mangaReadSources?.saveResponse(i, id, source)
        tryWithSuspend {
            mangaLoaded[i] = mangaReadSources?.loadChapters(i, source) ?: return@tryWithSuspend
        }
        mangaChapters.postValue(mangaLoaded)
    }

    private val mangaChapter = MutableLiveData<MangaChapter?>(null)
    fun getMangaChapter(): LiveData<MangaChapter?> = mangaChapter
    suspend fun loadMangaChapterImages(
        chapter: MangaChapter,
        selected: Selected,
        post: Boolean = true
    ): Boolean {

        return tryWithSuspend(true) {
            chapter.addImages(
                mangaReadSources?.get(selected.sourceIndex)
                    ?.loadImages(chapter.link, chapter.sChapter) ?: return@tryWithSuspend false
            )
            if (post) mangaChapter.postValue(chapter)
            true
        } ?: false
    }

    fun loadTransformation(mangaImage: MangaImage, source: Int): BitmapTransformation? {
        return if (mangaImage.useTransformation) mangaReadSources?.get(source)
            ?.getTransformation() else null
    }

    val novelSources = NovelSources
    val novelResponses = MutableLiveData<List<ShowResponse>>(null)

    private val novelChapters = MutableLiveData<MutableMap<Int, List<ShowResponse>>>(null)
    private val novelLoaded = mutableMapOf<Int, List<ShowResponse>>()
    fun getNovelChapters(): LiveData<MutableMap<Int, List<ShowResponse>>> = novelChapters

    suspend fun searchNovels(query: String, i: Int) {
        val position = if (i >= novelSources.list.size) 0 else i
        val source = novelSources[position]
        tryWithSuspend(post = true) {
            if (source != null) {
                novelResponses.postValue(source.search(query))
            }
        }
    }

    suspend fun autoSearchNovels(media: Media) {
        val source = novelSources[media.selected?.sourceIndex ?: 0]
        tryWithSuspend(post = true) {
            if (source != null) {
                novelResponses.postValue(source.sortedSearch(media))
            }
        }
    }

    suspend fun loadNovelChapters(media: Media, i: Int, invalidate: Boolean = false) {
        val isOffline = novelSources[i] is OfflineNovelParser
        val current = novelLoaded[i]
        if (current.isNullOrEmpty() || invalidate || isOffline) {
            tryWithSuspend {
                val source = novelSources[i]
                if (source == null) {
                    novelLoaded[i] = emptyList()
                    return@tryWithSuspend
                }
                loadNovelChaptersFromSource(media, i, source, invalidate, isOffline)
            }
        }
        novelChapters.postValue(novelLoaded)
    }

    private suspend fun loadNovelChaptersFromSource(
        media: Media,
        i: Int,
        source: NovelParser,
        invalidate: Boolean,
        isOffline: Boolean
    ) {
        val sourceKey = source.saveName.ifBlank { source.name }
        var book: Book? = null
        var novelCover = media.cover?.let { ani.dantotsu.FileUrl(it) } ?: ani.dantotsu.FileUrl("")

        if (!invalidate && !isOffline) {
            loadCachedNovelBook(source, sourceKey, media.id)?.let { (cachedBook, cover) ->
                book = cachedBook
                novelCover = cover
                postNovelChapters(i, cachedBook, cover, source.name)
            }
        }

        val novelResponse = source.autoSearch(media)
        if (novelResponse == null) {
            if (novelLoaded[i] == null) novelLoaded[i] = emptyList()
            return
        }
        novelCover = novelResponse.coverUrl

        book = resolveAndSaveNovelBook(source, sourceKey, novelResponse, book, invalidate, isOffline, i, novelCover)
        if (book == null || book?.links?.isEmpty() == true) {
            if (novelLoaded[i] == null) novelLoaded[i] = emptyList()
            return
        }
        postNovelChapters(i, book!!, novelCover, source.name)
    }

    private suspend fun resolveAndSaveNovelBook(
        source: NovelParser,
        sourceKey: String,
        novelResponse: ShowResponse,
        currentBook: Book?,
        invalidate: Boolean,
        isOffline: Boolean,
        i: Int,
        novelCover: ani.dantotsu.FileUrl
    ): Book? {
        var book = currentBook
        if (book == null && !invalidate && !isOffline) {
            val cachedBook = NovelStorage.loadBook(sourceKey, novelResponse.link)
            if (cachedBook != null && cachedBook.links.isNotEmpty()) {
                book = cachedBook
                postNovelChapters(i, cachedBook, novelCover, source.name)
            }
        }

        val fetchedBook = source.loadBook(novelResponse.link, novelResponse.extra)
        if (fetchedBook != null && fetchedBook.links.isNotEmpty() && !isOffline) {
            NovelStorage.saveBook(sourceKey, novelResponse.link, fetchedBook)
            book = fetchedBook
        }
        return book
    }

    private suspend fun loadCachedNovelBook(
        source: NovelParser,
        sourceKey: String,
        mediaId: Int
    ): Pair<Book, ani.dantotsu.FileUrl>? {
        val savedResponse = source.loadSavedShowResponse(mediaId) ?: return null
        if (savedResponse.link.isBlank()) return null
        val book = NovelStorage.loadBook(sourceKey, savedResponse.link)
        return if (book != null && book.links.isNotEmpty()) {
            book to savedResponse.coverUrl
        } else {
            null
        }
    }

    private fun postNovelChapters(
        i: Int,
        targetBook: Book,
        cover: ani.dantotsu.FileUrl,
        sourceName: String
    ) {
        val chapterResponses = targetBook.links.mapIndexed { index, fileUrl ->
            val chapterName = fileUrl.headers?.get("X-Chapter-Name") ?: "Chapter ${index + 1}"
            val releaseTime = fileUrl.headers?.get("X-Release-Time")
            val chapterNumber = fileUrl.headers?.get("X-Chapter-Number")
            ShowResponse(
                name = chapterName,
                link = fileUrl.url,
                coverUrl = cover,
                extra = mutableMapOf<String, String>().apply {
                    releaseTime?.let { put("releaseTime", it) }
                    chapterNumber?.let { put("chapterNumber", it) }
                    put("sourceName", sourceName)
                }
            )
        }
        novelLoaded[i] = chapterResponses
        novelChapters.postValue(novelLoaded)
    }
    suspend fun overrideNovelChapters(i: Int, source: ShowResponse, mediaId: Int) {
        novelSources.saveResponse(i, mediaId, source)
        novelLoaded.remove(i)
    }

    val book: MutableLiveData<Book> = MutableLiveData(null)
    suspend fun loadBook(novel: ShowResponse, i: Int) {
        tryWithSuspend {
            val source = novelSources[i] ?: return@tryWithSuspend
            val sourceKey = source.saveName.ifBlank { source.name }
            val isOffline = source is OfflineNovelParser
            if (!isOffline) {
                val cached = NovelStorage.loadBook(sourceKey, novel.link)
                if (cached != null && cached.links.isNotEmpty()) {
                    book.postValue(cached)
                }
            }
            val loaded = source.loadBook(novel.link, novel.extra) ?: return@tryWithSuspend
            if (loaded.links.isNotEmpty() && !isOffline) {
                NovelStorage.saveBook(sourceKey, novel.link, loaded)
            }
            book.postValue(loaded)
        }
    }

    private val fetchedOnlineSubtitles = mutableMapOf<String, List<Any>>()

    fun saveFetchedSubtitles(id: String, subs: List<Any>) {
        fetchedOnlineSubtitles[id] = subs
    }

    fun getFetchedSubtitles(id: String): List<Any>? {
        return fetchedOnlineSubtitles[id]
    }

    fun clearFetchedSubtitles(id: String) {
        fetchedOnlineSubtitles.remove(id)
    }

    private val localSubtitlesMap = mutableMapOf<String, MutableList<Any>>()

    fun saveLocalSubtitle(id: String, sub: Any) {
        val list = localSubtitlesMap.getOrPut(id) { mutableListOf() }
        val isDuplicate = list.any { existing ->
            existing is ani.dantotsu.parsers.Subtitle &&
            sub is ani.dantotsu.parsers.Subtitle &&
            existing.file.url == sub.file.url
        }
        if (!isDuplicate) list.add(sub)
    }

    fun getLocalSubtitles(id: String): List<Any> {
        return localSubtitlesMap[id] ?: emptyList()
    }

    fun removeLocalSubtitle(id: String, sub: Any) {
        val list = localSubtitlesMap[id] ?: return
        list.removeAll { existing ->
            if (existing is ani.dantotsu.parsers.Subtitle && sub is ani.dantotsu.parsers.Subtitle) {
                existing.file.url == sub.file.url
            } else {
                existing == sub
            }
        }
        if (list.isEmpty()) {
            localSubtitlesMap.remove(id)
        }
    }

    fun clearLocalSubtitles(id: String) {
        localSubtitlesMap.remove(id)
    }

    val adaptation = MutableLiveData<MangaAnimeUtil.AnimeAdaptation?>()
    val nextRelease = MutableLiveData<MangaAnimeUtil.NextRelease?>()
    fun loadMangaExtras(media: Media) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val seriesDeferred = async {
                    MangaAnimeUtil.getSeriesFromMedia(media)
                }

                val adaptationDeferred = async {
                    MangaAnimeUtil.getAnimeAdaptation(seriesDeferred.await())
                }

                val nextReleaseDeferred = async {
                    MangaAnimeUtil.getNextChapterPrediction(
                        media,
                        seriesDeferred.await()
                    )
                }

                adaptation.postValue(adaptationDeferred.await())
                nextRelease.postValue(nextReleaseDeferred.await())

            } catch (e: Exception) {
                Logger.log("MangaExtras error: $e")
            }
        }
    }

    // Watch Order and News integration
    data class WatchOrderItem(
        val id: String,
        val anilistId: String,
        val image: String,
        val name: String,
        val relationType: String,
        val isCurrent: Boolean = false,
        val airDate: String = "",
        val mediaType: String = "",
        val episodes: String = "",
        val rating: String = ""
    ) : java.io.Serializable

    data class NewsItem(
        val title: String,
        val url: String,
        val date: java.util.Date?
    ) : java.io.Serializable

    suspend fun getWatchOrder(media: Media): List<WatchOrderItem> {
        return tryWithSuspend {
            val headers = mapOf(
                "Referer" to "https://chiaki.site/?/tools/watch_order",
                "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "X-Requested-With" to "XMLHttpRequest"
            )

            val targetId = resolveWatchOrderTargetId(media, headers) ?: return@tryWithSuspend emptyList()

            val orderUrl = "https://chiaki.site/?/tools/watch_order/id/$targetId"
            val html = client.get(orderUrl, headers = headers).text
            val doc = org.jsoup.Jsoup.parse(html)

            val rows = doc.select("tr[data-id]")
            val relationsMap = media.relations?.associateBy { it.id.toString() } ?: emptyMap()
            val targetRow = rows.find { it.attr("data-id") == targetId }
            val relatedMap = parseWatchOrderRelatedMap(targetRow)

            rows.mapIndexedNotNull { index, row ->
                parseWatchOrderRow(row, index, media, targetId, relationsMap, relatedMap)
            }
        } ?: emptyList()
    }

    private suspend fun resolveWatchOrderTargetId(
        media: Media,
        headers: Map<String, String>
    ): String? {
        val malId = media.idMAL ?: ani.dantotsu.others.IdMappers.getMalId(media.id)
        if (media.idMAL == null && malId != null) {
            media.idMAL = malId
        }
        val targetId = malId?.toString()
        if (targetId != null) return targetId

        val searchName = media.userPreferredName.ifEmpty { media.mainName() }
        val encodedTerm = java.net.URLEncoder.encode(searchName, "UTF-8")
        val searchUrl = "https://chiaki.site/?/tools/autocomplete_series&term=$encodedTerm"
        val res = client.get(searchUrl, headers = headers).text
        val json = org.json.JSONArray(res)
        return if (json.length() > 0) {
            json.getJSONObject(0).opt("id")?.toString()
        } else {
            null
        }
    }

    private fun parseWatchOrderRelatedMap(targetRow: org.jsoup.nodes.Element?): Map<String, String> {
        val targetRelatedJson = targetRow?.attr("data-related") ?: "{}"
        return try {
            val jsonObj = org.json.JSONObject(targetRelatedJson)
            val map = mutableMapOf<String, String>()
            jsonObj.keys().forEach { key ->
                map[key] = jsonObj.getString(key)
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun extractWatchOrderImage(
        row: org.jsoup.nodes.Element,
        media: Media,
        anilistId: String,
        relationsMap: Map<String, Media>
    ): String {
        val style = row.select("div.wo_avatar_big").attr("style")
        val imgMatch = Regex("""url\(['"]?([^'")]+)['"]?\)""").find(style)
        var imageUrl = imgMatch?.groupValues?.get(1)?.let { path ->
            when {
                path.startsWith("http") -> path
                path.startsWith("/") -> "https://chiaki.site$path"
                else -> "https://chiaki.site/$path"
            }
        } ?: ""

        if (imageUrl.isEmpty()) {
            if (anilistId == media.id.toString()) {
                imageUrl = media.cover ?: ""
            } else if (relationsMap.containsKey(anilistId)) {
                imageUrl = relationsMap[anilistId]?.cover ?: ""
            }
        }
        return imageUrl
    }

    private fun isCurrentWatchOrderMedia(
        media: Media,
        id: String,
        anilistId: String,
        targetId: String,
        title: String
    ): Boolean {
        val cleanId = id.trim()
        val cleanAnilistId = anilistId.trim()
        val currentMalId = media.idMAL
        return (cleanAnilistId.isNotEmpty() && cleanAnilistId == media.id.toString()) ||
                (cleanId.isNotEmpty() && currentMalId != null && cleanId == currentMalId.toString()) ||
                (cleanId.isNotEmpty() && cleanId == targetId.trim() && (currentMalId == null || currentMalId.toString() == targetId.trim())) ||
                (title.isNotEmpty() && (title.equals(media.userPreferredName, ignoreCase = true) ||
                        title.equals(media.mainName(), ignoreCase = true) ||
                        title.equals(media.name, ignoreCase = true) ||
                        title.equals(media.nameRomaji, ignoreCase = true)))
    }

    private fun resolveWatchOrderRelationType(
        isCurrent: Boolean,
        id: String,
        anilistId: String,
        index: Int,
        format: String,
        relatedMap: Map<String, String>,
        relationsMap: Map<String, Media>
    ): String {
        return when {
            isCurrent -> "Selected"
            relatedMap.containsKey(id) -> relatedMap[id]!!
            relationsMap.containsKey(anilistId) -> {
                relationsMap[anilistId]?.relation?.replace("_", " ")?.lowercase()
                    ?.split(" ")?.joinToString(" ") { it.replaceFirstChar(Char::titlecase) } ?: ""
            }
            index == 0 -> "Main Story"
            format.equals("TV", ignoreCase = true) -> "Sequel"
            format.equals("OVA", ignoreCase = true) || format.equals("Special", ignoreCase = true) -> "Side Story"
            format.equals("Movie", ignoreCase = true) -> "Movie"
            else -> format.ifEmpty { "Entry" }
        }
    }

    private fun parseWatchOrderRow(
        row: org.jsoup.nodes.Element,
        index: Int,
        media: Media,
        targetId: String,
        relationsMap: Map<String, Media>,
        relatedMap: Map<String, String>
    ): WatchOrderItem? {
        val title = row.select("span.wo_title").text().trim()
            .ifEmpty { row.select(".wo_title").text().trim() }
        if (title.isEmpty() || title.equals("Unknown title", ignoreCase = true)) return null

        val id = row.attr("data-id").ifEmpty { targetId }
        val anilistId = row.attr("data-anilist-id")
        val imageUrl = extractWatchOrderImage(row, media, anilistId, relationsMap)

        val metaText = row.select("span.uk-text-muted.uk-text-small").text().trim()
            .ifEmpty { row.select(".wo_meta").text().trim() }
        val parts = metaText.split('|').map { it.trim() }
        val airDate = if (parts.isNotEmpty()) parts[0] else ""
        val format = if (parts.size > 1) parts[1] else ""
        val eps = if (parts.size > 2) parts[2].substringBefore("★").substringBefore("(").trim() else ""

        val isCurrent = isCurrentWatchOrderMedia(media, id, anilistId, targetId, title)
        val relationType = resolveWatchOrderRelationType(isCurrent, id, anilistId, index, format, relatedMap, relationsMap)

        return WatchOrderItem(
            id = id,
            anilistId = anilistId,
            image = imageUrl,
            name = title,
            relationType = relationType,
            isCurrent = isCurrent,
            airDate = airDate,
            mediaType = format,
            episodes = eps,
            rating = ""
        )
    }

    suspend fun getAnimeNews(media: Media): List<NewsItem> {
        return tryWithSuspend {
            val targetId = resolveAnimeMalId(media) ?: return@tryWithSuspend emptyList()

            val headers = mapOf(
                "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Accept" to "application/json, text/plain, */*"
            )

            var result = fetchKuroiruNews(targetId, headers)
            if (result.isEmpty()) {
                result = fetchKuroiruNewsFallback(targetId, media, headers)
            }

            result.sortedByDescending { it.date }
        } ?: emptyList()
    }

    private suspend fun resolveAnimeMalId(media: Media): Int? {
        var malId = media.idMAL
        if (malId == null || malId == 0) {
            malId = ani.dantotsu.others.IdMappers.getMalId(media.id)
        }
        if (malId == null || malId == 0) {
            malId = runCatching {
                Anilist.query.getMedia(media.id)?.idMAL
            }.getOrNull()
            if (malId != null && malId != 0) {
                media.idMAL = malId
            }
        }
        return malId?.takeIf { it != 0 }
    }

    private suspend fun fetchKuroiruNews(id: Int, headers: Map<String, String>): List<NewsItem> {
        val jsonStr = runCatching {
            val res = client.get("https://kuroiru.co/api/anime/$id", headers = headers)
            if (res.isSuccessful) res.text else null
        }.getOrNull() ?: return emptyList()

        val root = runCatching {
            Json.parseToJsonElement(jsonStr).jsonObject
        }.getOrNull() ?: return emptyList()
        val newsArr = root["news"]?.jsonArray ?: return emptyList()
        return newsArr.mapNotNull { parseKuroiruNewsItem(it.jsonObject) }
    }

    private fun parseKuroiruNewsItem(itemObj: kotlinx.serialization.json.JsonObject): NewsItem? {
        val timeMs = itemObj["time"]?.jsonPrimitive?.longOrNull ?: 0L
        val rawTitle = itemObj["title"]?.jsonPrimitive?.contentOrNull ?: ""
        val title = org.jsoup.parser.Parser.unescapeEntities(rawTitle, false)
        val rawLink = itemObj["link"]?.jsonPrimitive?.contentOrNull ?: ""
        val link = normalizeKuroiruLink(rawLink)
        return if (title.isNotEmpty() && link.isNotEmpty()) {
            NewsItem(
                title = title,
                url = link,
                date = if (timeMs > 0) java.util.Date(timeMs * 1000L) else null
            )
        } else {
            null
        }
    }

    private suspend fun fetchKuroiruNewsFallback(
        targetId: Int,
        media: Media,
        headers: Map<String, String>
    ): List<NewsItem> {
        val candidateIds = mutableListOf<Int>()
        media.prequel?.idMAL?.let { candidateIds.add(it) }
        media.relations?.forEach { rel ->
            rel.idMAL?.let { candidateIds.add(it) }
        }
        for (candId in candidateIds) {
            if (candId != targetId && candId != 0) {
                val result = fetchKuroiruNews(candId, headers)
                if (result.isNotEmpty()) return result
            }
        }
        return emptyList()
    }

    private fun normalizeKuroiruLink(rawLink: String): String {
        val link = rawLink.trim()
        if (link.isEmpty()) return ""
        if (link.startsWith("http://", ignoreCase = true) ||
            link.startsWith("https://", ignoreCase = true)
        ) return link
       
        val digitId = link.removePrefix(".")
        if (digitId.isNotEmpty() && digitId.all { it.isDigit() }) {
            return "https://www.animenewsnetwork.com/news/.$digitId"
        }
        return link
    }

    suspend fun getMangaNovelNews(media: Media): List<NewsItem> {
        return tryWithSuspend {
            val bakaBase = "https://api.mangabaka.org/v1"
            val headers = mapOf(
                "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Accept" to "application/json, text/plain, */*"
            )

            val bakaId = getBakaId(media, bakaBase, headers) ?: return@tryWithSuspend emptyList()

            val jsonStr = runCatching {
                val res = client.get("$bakaBase/series/$bakaId/news", headers = headers)
                if (res.isSuccessful) res.text else null
            }.getOrNull() ?: return@tryWithSuspend emptyList()

            val root = runCatching { Json.parseToJsonElement(jsonStr).jsonObject }.getOrNull()
                ?: return@tryWithSuspend emptyList()
            val newsArr = root["data"]?.jsonArray ?: return@tryWithSuspend emptyList()

            val result = newsArr.mapNotNull { parseBakaNewsItem(it.jsonObject) }.toMutableList()
            result.sortByDescending { it.date }
            result
        } ?: emptyList()
    }

    private suspend fun getBakaId(media: Media, bakaBase: String, headers: Map<String, String>): Int? {
        if (media.id != 0) {
            val id = fetchBakaSourceId("$bakaBase/source/anilist/${media.id}", headers)
            if (id != null && id != 0) return id
        }

        if (media.idMAL != null && media.idMAL != 0) {
            val id = fetchBakaSourceId("$bakaBase/source/my-anime-list/${media.idMAL}", headers)
            if (id != null && id != 0) return id
        }

        val titleToSearch = media.userPreferredName.ifEmpty { media.mainName() }
        if (titleToSearch.isNotEmpty()) {
            val encodedTitle = java.net.URLEncoder.encode(titleToSearch, "UTF-8")
            val id = runCatching {
                val res = client.get("$bakaBase/series/search?q=$encodedTitle", headers = headers)
                if (!res.isSuccessful) return@runCatching null
                val root = Json.parseToJsonElement(res.text).jsonObject
                root["data"]?.jsonArray?.firstOrNull()?.jsonObject?.get("id")?.jsonPrimitive?.intOrNull?.takeIf { it != 0 }
            }.getOrNull()
            if (id != null && id != 0) return id
        }

        return null
    }

    private suspend fun fetchBakaSourceId(url: String, headers: Map<String, String>): Int? {
        return runCatching {
            val res = client.get(url, headers = headers)
            if (!res.isSuccessful) return@runCatching null
            val root = Json.parseToJsonElement(res.text).jsonObject
            root["data"]?.jsonObject?.get("series")?.jsonArray?.firstOrNull()?.jsonObject?.get("id")?.jsonPrimitive?.intOrNull?.takeIf { it != 0 }
        }.getOrNull()
    }

    private fun parseBakaDate(dateStr: String): java.util.Date? {
        if (dateStr.isEmpty()) return null
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val instantDate = runCatching {
                java.util.Date(java.time.Instant.parse(dateStr).toEpochMilli())
            }.getOrNull()
            if (instantDate != null) return instantDate
        }
        val formats = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd"
        )
        for (fmt in formats) {
            val parsed = runCatching {
                val sdf = java.text.SimpleDateFormat(fmt, java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }
                sdf.parse(dateStr)
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return null
    }

    private fun parseBakaNewsItem(itemObj: kotlinx.serialization.json.JsonObject): NewsItem? {
        val pubAt = itemObj["published_at"]?.jsonPrimitive?.contentOrNull ?: ""
        val date = parseBakaDate(pubAt)
        val rawTitle = itemObj["title"]?.jsonPrimitive?.contentOrNull ?: ""
        val title = org.jsoup.parser.Parser.unescapeEntities(rawTitle, false)
        val url = itemObj["url"]?.jsonPrimitive?.contentOrNull ?: ""
        return if (title.isNotEmpty() && url.isNotEmpty()) {
            NewsItem(
                title = title,
                url = url,
                date = date
            )
        } else {
            null
        }
    }
}
