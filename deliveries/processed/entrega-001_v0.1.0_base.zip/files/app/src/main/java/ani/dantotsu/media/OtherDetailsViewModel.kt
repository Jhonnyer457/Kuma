package ani.dantotsu.media

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import ani.dantotsu.client
import ani.dantotsu.Mapper
import ani.dantotsu.connections.anilist.Anilist
import ani.dantotsu.connections.mal.MAL
import ani.dantotsu.connections.mal.JikanMediaData
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.tryWithSuspend
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import ani.dantotsu.media.anime.Anime
import ani.dantotsu.media.manga.Manga

class OtherDetailsViewModel : ViewModel() {
    companion object {
        private const val DUB_FEED_URL =
            "https://raw.githubusercontent.com/RockinChaos/AniSchedule/master/readable/dub-episode-feed-readable.json"
    }

    private val character: MutableLiveData<Character> = MutableLiveData(null)
    fun getCharacter(): LiveData<Character> = character
    suspend fun loadCharacter(m: Character) {
        if (character.value != null) return
        if (PrefManager.getVal(PrefName.RescueMode)) {
            tryWithSuspend {
                val jikanData = MAL.jikan.getCharacterFull(m.id)
                if (jikanData != null) {
                    m.description = jikanData.about

                    parseCharacterAboutFields(m, jikanData.about)

                    jikanData.images?.jpg?.largeImageUrl?.let { m.image = it }
                        ?: jikanData.images?.jpg?.imageUrl?.let { m.image = it }

                    val roles = arrayListOf<Media>()

                    jikanData.anime.forEach { role ->
                        role.anime?.let { animeEntry ->
                            val media = Media(
                                id = animeEntry.malId,
                                idMAL = animeEntry.malId,
                                name = animeEntry.title,
                                nameRomaji = animeEntry.title ?: "",
                                userPreferredName = animeEntry.title ?: "",
                                cover = animeEntry.images?.jpg?.largeImageUrl ?: animeEntry.images?.jpg?.imageUrl,
                                isAdult = false,
                                format = "TV",
                                anime = Anime(null, null, null)
                            )
                            media.relation = role.role
                            roles.add(media)
                        }
                    }

                    jikanData.manga.forEach { role ->
                        role.manga?.let { mangaEntry ->
                            val media = Media(
                                id = mangaEntry.malId,
                                idMAL = mangaEntry.malId,
                                name = mangaEntry.title,
                                nameRomaji = mangaEntry.title ?: "",
                                userPreferredName = mangaEntry.title ?: "",
                                cover = mangaEntry.images?.jpg?.largeImageUrl ?: mangaEntry.images?.jpg?.imageUrl,
                                isAdult = false,
                                format = "MANGA",
                                manga = Manga()
                            )
                            media.relation = role.role
                            roles.add(media)
                        }
                    }
                    roles.sortByDescending { it.idMAL }
                    m.roles = roles
                    
                    val voiceActors = arrayListOf<Author>()
                    jikanData.voices.forEach { voice ->
                        voice.person?.let { person ->
                            val vActor = Author(
                                id = person.malId,
                                name = person.name,
                                image = person.images?.jpg?.imageUrl,
                                role = voice.language
                            )
                            voiceActors.add(vActor)
                        }
                    }
                    m.voiceActor = voiceActors
                }
            }
            character.postValue(m)
            return
        }
        character.postValue(Anilist.query.getCharacterDetails(m))
    }

    private fun parseCharacterAboutFields(m: Character, about: String?) {
        if (about.isNullOrBlank()) return
        val lines = about.lines()
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.startsWith("Age:", ignoreCase = true) && m.age == null) {
                m.age = trimmed.substringAfter(":").trim()
            }
            if (trimmed.startsWith("Gender:", ignoreCase = true) && m.gender == null) {
                m.gender = trimmed.substringAfter(":").trim()
            }
            if (trimmed.startsWith("Birthday:", ignoreCase = true) && m.dateOfBirth == null) {
                val raw = trimmed.substringAfter(":").trim()
                if (raw.isNotBlank()) {
                    m.dateOfBirth = ani.dantotsu.connections.anilist.api.FuzzyDate()
                    m.description = about.replace(trimmed, "").trim()
                    try {
                        val parts = raw.replace(Regex("[^\\w\\s,]"), "").trim().split("\\s+".toRegex())
                        if (parts.isNotEmpty()) {
                            val months = mapOf(
                                "january" to 1, "february" to 2, "march" to 3, "april" to 4,
                                "may" to 5, "june" to 6, "july" to 7, "august" to 8,
                                "september" to 9, "october" to 10, "november" to 11, "december" to 12
                            )
                            val monthNum = months[parts[0].lowercase()]
                            val day = if (parts.size > 1) parts[1].filter { it.isDigit() }.toIntOrNull() else null
                            m.dateOfBirth = ani.dantotsu.connections.anilist.api.FuzzyDate(
                                month = monthNum,
                                day = day
                            )
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    private val studio: MutableLiveData<Studio> = MutableLiveData(null)
    fun getStudio(): LiveData<Studio> = studio
    suspend fun loadStudio(m: Studio) {
        if (studio.value != null) return
        if (PrefManager.getVal(PrefName.RescueMode)) {
            tryWithSuspend {
                val yearMedia = mutableMapOf<String, ArrayList<Media>>()
                val seenIds = mutableSetOf<Int>()
                var page = 1
                var hasNext = true

                while (hasNext && page <= 10) {
                    val resp = MAL.jikan.getProducerAnime(m.id.toIntOrNull() ?: 0, page) ?: break
                    resp.data.forEach { jikanData ->
                        if (!seenIds.contains(jikanData.malId)) {
                            seenIds.add(jikanData.malId)
                            val media = Media(jikanData, isAnime = true)
                            val status = jikanData.status?.uppercase() ?: ""
                            val year = jikanData.aired?.from?.take(4) ?: "TBA"
                            val title = if (status.contains("CANCEL")) "CANCELLED" else year
                            if (!yearMedia.containsKey(title)) yearMedia[title] = arrayListOf()
                            yearMedia[title]?.add(media)
                        }
                    }
                    hasNext = resp.pagination?.hasNextPage == true
                    if (hasNext) {
                        kotlinx.coroutines.delay(350)
                        page++
                    }
                }

                if (yearMedia.contains("CANCELLED")) {
                    val cancelled = yearMedia["CANCELLED"]!!
                    yearMedia.remove("CANCELLED")
                    yearMedia["CANCELLED"] = cancelled
                }
                m.yearMedia = yearMedia
            }
            studio.postValue(m)
            return
        }
        if (studio.value == null) studio.postValue(Anilist.query.getStudioDetails(m))
    }

    private val author: MutableLiveData<Author> = MutableLiveData(null)
    fun getAuthor(): LiveData<Author> = author
    private suspend fun loadAuthorFromJikan(m: Author) {
        tryWithSuspend {
            val jikanData = MAL.jikan.getPersonFull(m.id)
            if (jikanData != null) {
                applyJikanAuthorDetails(m, jikanData)
                m.yearMedia = populateJikanAuthorMedia(jikanData)
                m.character = parseJikanCharacters(jikanData.voices)
            }
        }
        author.postValue(m)
    }

    private fun applyJikanAuthorDetails(m: Author, jikanData: ani.dantotsu.connections.mal.JikanPersonFullData) {
        if (!jikanData.about.isNullOrBlank()) {
            m.about = jikanData.about
        }

        jikanData.images?.jpg?.largeImageUrl?.let { m.image = it }
            ?: jikanData.images?.jpg?.imageUrl?.let { m.image = it }

        if (!jikanData.birthday.isNullOrBlank()) {
            try {
                val isoFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
                val parsed = isoFormat.parse(jikanData.birthday.take(19))
                if (parsed != null) {
                    val displayFormat = java.text.SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
                    m.dateOfBirth = displayFormat.format(parsed)
                }
            } catch (_: Exception) {
                m.dateOfBirth = jikanData.birthday.substringBefore("T")
            }
        }
    }

    private fun populateJikanAuthorMedia(jikanData: ani.dantotsu.connections.mal.JikanPersonFullData): LinkedHashMap<String, ArrayList<Media>> {
        val yearMedia = mutableMapOf<String, ArrayList<Media>>()

        jikanData.anime.forEach { role ->
            role.anime?.let { animeEntry ->
                val positionKey = role.position?.ifBlank { "Other" } ?: "Other"
                val title = "$positionKey (Anime)"
                val list = yearMedia.getOrPut(title) { arrayListOf() }
                val media = Media(
                    id = animeEntry.malId,
                    idMAL = animeEntry.malId,
                    name = animeEntry.title,
                    nameRomaji = animeEntry.title ?: "",
                    userPreferredName = animeEntry.title ?: "",
                    cover = animeEntry.images?.jpg?.largeImageUrl ?: animeEntry.images?.jpg?.imageUrl,
                    isAdult = false,
                    format = "TV",
                    anime = Anime(null, null, null)
                )
                media.relation = role.position
                list.add(media)
            }
        }

        jikanData.manga.forEach { role ->
            role.manga?.let { mangaEntry ->
                val positionKey = role.position?.ifBlank { "Other" } ?: "Other"
                val title = "$positionKey (Manga)"
                val list = yearMedia.getOrPut(title) { arrayListOf() }
                val media = Media(
                    id = mangaEntry.malId,
                    idMAL = mangaEntry.malId,
                    name = mangaEntry.title,
                    nameRomaji = mangaEntry.title ?: "",
                    userPreferredName = mangaEntry.title ?: "",
                    cover = mangaEntry.images?.jpg?.largeImageUrl ?: mangaEntry.images?.jpg?.imageUrl,
                    isAdult = false,
                    format = "MANGA",
                    manga = Manga()
                )
                media.relation = role.position
                list.add(media)
            }
        }

        val voiceMediaMap = mutableMapOf<Int, Media>()
        jikanData.voices.forEach { voice ->
            voice.anime?.let { animeEntry ->
                val characterInfo = if (voice.character != null) {
                    "${voice.character.name ?: ""}${if (!voice.role.isNullOrBlank()) " (${voice.role})" else ""}"
                } else ""

                val existing = voiceMediaMap[animeEntry.malId]
                if (existing != null) {
                    if (characterInfo.isNotEmpty()) {
                        existing.relation = if (existing.relation.isNullOrBlank()) {
                            characterInfo
                        } else {
                            "${existing.relation} / $characterInfo"
                        }
                    }
                } else {
                    val media = Media(
                        id = animeEntry.malId,
                        idMAL = animeEntry.malId,
                        name = animeEntry.title,
                        nameRomaji = animeEntry.title ?: "",
                        userPreferredName = animeEntry.title ?: "",
                        cover = animeEntry.images?.jpg?.largeImageUrl ?: animeEntry.images?.jpg?.imageUrl,
                        isAdult = false,
                        format = "TV",
                        anime = Anime(null, null, null)
                    )
                    media.relation = characterInfo
                    voiceMediaMap[animeEntry.malId] = media
                }
            }
        }
        if (voiceMediaMap.isNotEmpty()) {
            yearMedia["Voice Roles (Anime)"] = ArrayList(voiceMediaMap.values)
        }

        yearMedia.forEach { (_, list) ->
            list.sortByDescending { it.idMAL }
        }

        val sortedYearMedia = linkedMapOf<String, ArrayList<Media>>()
        yearMedia.entries
            .sortedByDescending { it.value.size }
            .forEach { sortedYearMedia[it.key] = it.value }
        return sortedYearMedia
    }

    private fun parseJikanCharacters(voices: List<ani.dantotsu.connections.mal.JikanPersonVoiceRole>): ArrayList<Character> {
        val characters = arrayListOf<Character>()
        voices.forEach { voice ->
            voice.character?.let { charEntry ->
                val c = Character(
                    id = charEntry.malId,
                    name = charEntry.name,
                    image = charEntry.images?.jpg?.imageUrl ?: charEntry.images?.webp?.imageUrl,
                    banner = null,
                    role = voice.role ?: "",
                    isFav = false
                )
                characters.add(c)
            }
        }
        return characters
    }

    suspend fun loadAuthor(m: Author) {
        if (author.value != null) return
        if (PrefManager.getVal(PrefName.RescueMode)) {
            loadAuthorFromJikan(m)
            return
        }
        author.postValue(Anilist.query.getAuthorDetails(m))
    }

    private var cachedAllCalendarData: Map<String, MutableList<Media>>? = null
    private var cachedLibraryCalendarData: Map<String, MutableList<Media>>? = null
    private var cachedDubAnilistIds: Set<Int>? = null
    private var cachedDubMalIds: Set<Int>? = null
    private val calendar: MutableLiveData<Map<String, MutableList<Media>>> = MutableLiveData(null)
    fun getCalendar(): LiveData<Map<String, MutableList<Media>>> = calendar
    suspend fun loadCalendar(showOnlyLibrary: Boolean = false, showOnlyDubbed: Boolean = false) {
        val rescueMode: Boolean = PrefManager.getVal(PrefName.RescueMode)
        if (rescueMode) {
            loadCalendarFromJikan(showOnlyLibrary, showOnlyDubbed)
        } else {
            loadCalendarFromAnilist(showOnlyLibrary, showOnlyDubbed)
        }
    }

    private suspend fun loadCalendarFromAnilist(showOnlyLibrary: Boolean, showOnlyDubbed: Boolean) {
        if (cachedAllCalendarData == null || cachedLibraryCalendarData == null) {
            val curr = System.currentTimeMillis() / 1000
            val res = Anilist.query.recentlyUpdated(curr - 86400, curr + (86400 * 6))
            val df = DateFormat.getDateInstance(DateFormat.FULL)
            val tf = DateFormat.getTimeInstance(DateFormat.SHORT)
            val allMap = mutableMapOf<String, MutableList<Media>>()
            val libraryMap = mutableMapOf<String, MutableList<Media>>()
            val idMap = mutableMapOf<String, MutableList<Int>>()

            val userId = Anilist.userid ?: 0
            val userLibrary = Anilist.query.getMediaLists(true, userId)
            val libraryMediaIds = userLibrary.flatMap { it.value }.map { it.id }

            res.forEach {
                val v = it.relation?.split(",")?.map { i -> i.toLong() }!!
                val dateInfo = df.format(Date(v[1] * 1000))
                val timeInfo = tf.format(Date(v[1] * 1000))
                val list = allMap.getOrPut(dateInfo) { mutableListOf() }
                val libraryList = if (libraryMediaIds.contains(it.id)) {
                    libraryMap.getOrPut(dateInfo) { mutableListOf() }
                } else {
                    null
                }
                val idList = idMap.getOrPut(dateInfo) { mutableListOf() }
                it.relation = "Episode ${v[0]}\n$timeInfo"
                if (!idList.contains(it.id)) {
                    idList.add(it.id)
                    list.add(it)
                    libraryList?.add(it)
                }
            }

            cachedAllCalendarData = allMap
            cachedLibraryCalendarData = libraryMap
        }

        var cacheToUse: Map<String, MutableList<Media>> = if (showOnlyLibrary) {
            cachedLibraryCalendarData ?: emptyMap()
        } else {
            cachedAllCalendarData ?: emptyMap()
        }
        if (showOnlyDubbed) {
            cacheToUse = applyDubFilter(cacheToUse, rescueMode = false)
        }
        calendar.postValue(cacheToUse)
    }

    private suspend fun fetchWatchingMalData(): Pair<MutableSet<Int>, MutableMap<Int, Int>> {
        val watchingMalIds = mutableSetOf<Int>()
        val watchedEpisodesMap = mutableMapOf<Int, Int>()
        if (MAL.token != null) {
            tryWithSuspend {
                var offset = 0
                do {
                    val listResp = MAL.query.getUserAnimeList(
                        status = "watching", limit = 100, offset = offset
                    )
                    listResp?.data?.forEach { entry ->
                        watchingMalIds.add(entry.node.id)
                        watchedEpisodesMap[entry.node.id] =
                            entry.listStatus?.numEpisodesWatched ?: 0
                    }
                    offset += 100
                } while (listResp?.paging?.next != null)
            }
        }
        return Pair(watchingMalIds, watchedEpisodesMap)
    }

    private fun estimateAiredEpisodes(
        jikanData: JikanMediaData,
        cal: Calendar,
        watchedEpisodesMap: Map<Int, Int>
    ): Int? {
        val fromDateStr = jikanData.aired?.from ?: return null
        return try {
            val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            val startDate = isoFormat.parse(fromDateStr.take(19)) ?: return null
            val targetTime = cal.time.time
            val diff = targetTime - startDate.time
            if (diff < 0) return null
            val weeks = (diff / (7L * 24 * 60 * 60 * 1000)).toInt()
            var estimated = weeks + 1
            if (jikanData.episodes != null && estimated > jikanData.episodes) {
                estimated = jikanData.episodes
            }
            val watched = watchedEpisodesMap[jikanData.malId] ?: 0
            if (watched > estimated) {
                estimated = watched
            }
            estimated
        } catch (_: Exception) {
            null
        }
    }

    private fun parseBroadcastTime(
        jikanData: JikanMediaData,
        cal: Calendar,
        tf: DateFormat
    ): Pair<String, Int> {
        val bTime = jikanData.broadcast?.time
        val bTz = jikanData.broadcast?.timezone
        if (bTime.isNullOrBlank()) return Pair("", Int.MAX_VALUE)
        if (bTz.isNullOrBlank()) return Pair(bTime, Int.MAX_VALUE)

        return try {
            val parser = SimpleDateFormat("HH:mm", Locale.US).apply {
                timeZone = TimeZone.getTimeZone(bTz)
            }
            val parsedTime = parser.parse(bTime) ?: return Pair("$bTime $bTz", Int.MAX_VALUE)
            val targetCal = Calendar.getInstance(TimeZone.getTimeZone(bTz)).apply {
                time = cal.time
            }
            val timeCal = Calendar.getInstance(TimeZone.getTimeZone(bTz)).apply {
                time = parsedTime
            }
            targetCal.set(Calendar.HOUR_OF_DAY, timeCal.get(Calendar.HOUR_OF_DAY))
            targetCal.set(Calendar.MINUTE, timeCal.get(Calendar.MINUTE))

            tf.timeZone = TimeZone.getDefault()
            val timeStr = tf.format(targetCal.time)
            val localCal = Calendar.getInstance().apply {
                time = targetCal.time
            }
            val sortTime = localCal.get(Calendar.HOUR_OF_DAY) * 60 + localCal.get(Calendar.MINUTE)
            Pair(timeStr, sortTime)
        } catch (_: Exception) {
            Pair("$bTime $bTz", Int.MAX_VALUE)
        }
    }

    private fun mapJikanItemToMedia(
        jikanData: JikanMediaData,
        cal: Calendar,
        watchedEpisodesMap: Map<Int, Int>,
        tf: DateFormat
    ): Media {
        val media = Media(jikanData, isAnime = true)
        media.userProgress = watchedEpisodesMap[jikanData.malId]
        media.anime?.nextAiringEpisode = estimateAiredEpisodes(jikanData, cal, watchedEpisodesMap)
        val (timeStr, sortTime) = parseBroadcastTime(jikanData, cal, tf)
        val nextEp = watchedEpisodesMap[jikanData.malId]?.let { it + 1 }
        media.relation = if (nextEp != null) {
            "Episode $nextEp" + if (timeStr.isNotBlank()) "\n$timeStr" else ""
        } else {
            timeStr.ifBlank { null }
        }
        media.userUpdatedAt = sortTime.toLong()
        return media
    }

    private suspend fun fetchJikanScheduleForDay(
        dayName: String,
        cal: Calendar,
        watchedEpisodesMap: Map<Int, Int>,
        tf: DateFormat
    ): List<Media> {
        val jikan = MAL.jikan
        val allMedia = mutableListOf<Media>()
        val seenIds = mutableSetOf<Int>()
        var page = 1
        var hasNext = true
        while (hasNext) {
            val resp = jikan.getSchedules(filter = dayName, page = page, limit = 25) ?: break
            resp.data.forEach { jikanData ->
                if (seenIds.add(jikanData.malId)) {
                    allMedia.add(mapJikanItemToMedia(jikanData, cal, watchedEpisodesMap, tf))
                }
            }
            hasNext = resp.pagination?.hasNextPage == true
            kotlinx.coroutines.delay(350)
            page++
        }
        allMedia.sortBy { it.userUpdatedAt ?: Long.MAX_VALUE }
        return allMedia
    }

    private suspend fun buildJikanCalendarCache() {
        if (cachedAllCalendarData != null && cachedLibraryCalendarData != null) return

        val df = DateFormat.getDateInstance(DateFormat.FULL)
        val tf = DateFormat.getTimeInstance(DateFormat.SHORT)
        val dayNames = arrayOf(
            "sunday", "monday", "tuesday", "wednesday",
            "thursday", "friday", "saturday"
        )
        val allMap = mutableMapOf<String, MutableList<Media>>()
        val libraryMap = mutableMapOf<String, MutableList<Media>>()
        val (watchingMalIds, watchedEpisodesMap) = fetchWatchingMalData()

        for (offsetDay in -1..6) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, offsetDay)
            val dayName = dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]
            val dateStr = df.format(cal.time)

            val allMedia = fetchJikanScheduleForDay(dayName, cal, watchedEpisodesMap, tf).toMutableList()
            allMap[dateStr] = allMedia
            val libList = allMedia.filter { watchingMalIds.contains(it.id) }.toMutableList()
            if (libList.isNotEmpty()) {
                libraryMap[dateStr] = libList
            }
        }
        cachedAllCalendarData = allMap
        cachedLibraryCalendarData = libraryMap
    }

    private suspend fun loadCalendarFromJikan(showOnlyLibrary: Boolean, showOnlyDubbed: Boolean) {
        buildJikanCalendarCache()

        var cacheToUse: Map<String, MutableList<Media>> = if (showOnlyLibrary) {
            cachedLibraryCalendarData ?: emptyMap()
        } else {
            cachedAllCalendarData ?: emptyMap()
        }
        if (showOnlyDubbed) {
            cacheToUse = applyDubFilter(cacheToUse, rescueMode = true)
        }
        calendar.postValue(cacheToUse)
    }

    private suspend fun applyDubFilter(
        data: Map<String, MutableList<Media>>,
        rescueMode: Boolean
    ): Map<String, MutableList<Media>> {
        ensureDubDataLoaded()
        val dubAnilistIds = cachedDubAnilistIds ?: emptySet()
        val dubMalIds = cachedDubMalIds ?: emptySet()

        val filteredMap = linkedMapOf<String, MutableList<Media>>()
        data.forEach { (date, mediaList) ->
            val filteredList = mediaList.filter { media ->
                if (rescueMode) {
                    (media.idMAL != null && dubMalIds.contains(media.idMAL)) || dubMalIds.contains(media.id)
                } else {
                    dubAnilistIds.contains(media.id) || (media.idMAL != null && dubMalIds.contains(media.idMAL))
                }
            }.toMutableList()
            if (filteredList.isNotEmpty()) {
                filteredMap[date] = filteredList
            }
        }
        return filteredMap
    }

    private suspend fun ensureDubDataLoaded() {
        if (cachedDubAnilistIds != null && cachedDubMalIds != null) return

        val feedItems = tryWithSuspend {
            val response = client.get(DUB_FEED_URL)
            Mapper.json.decodeFromString<List<DubEpisodeFeedItem>>(response.text)
        } ?: emptyList()

        if (feedItems.isNotEmpty()) {
            cachedDubAnilistIds = feedItems.mapNotNull { it.id }.toSet()
            cachedDubMalIds = feedItems.mapNotNull { it.idMal }.toSet()
        }
    }
}

@Serializable
private data class DubEpisodeFeedItem(
    @SerialName("id") val id: Int? = null,
    @SerialName("idMal") val idMal: Int? = null,
)
