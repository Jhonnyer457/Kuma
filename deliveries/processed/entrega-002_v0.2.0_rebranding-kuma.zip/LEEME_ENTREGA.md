# Entrega 002 — v0.2.0
Rebranding Kuma. Sube este ZIP a deliveries/inbox/ (con la bandeja vacía).
