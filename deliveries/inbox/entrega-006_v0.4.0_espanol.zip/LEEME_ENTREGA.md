# Entrega 006 — v0.2.1
Diagnostico. Sube este ZIP a deliveries/inbox/.
